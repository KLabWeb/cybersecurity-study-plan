#!/usr/bin/env python3
"""pagination_check.py -- V30 readability gate on the RENDERED PDF.
Flags: heading stranded in the last 2 content lines of a page; a step title with no bullet on
its page; a page opening with a sentence fragment (orphan continuation); a near-blank page;
a bullet or resource entry that continues onto the next page. Usage: pagination_check.py [pdf]"""
import re, sys, subprocess, glob, os
pdf = sys.argv[1] if len(sys.argv) > 1 else sorted(glob.glob("Study_Plan_-_*.pdf"), key=os.path.getmtime)[-1]
def pages_text(path):
    try:
        out = subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True, check=True).stdout
        return out.rstrip("\f").split("\f")   # pdftotext ends with a trailing form feed
    except Exception:
        from pypdf import PdfReader
        return [p.extract_text() or "" for p in PdfReader(path).pages]
HDR = re.compile(r"^\s*Application Security Engineering .*August 2026\s*$")
PGNUM = re.compile(r"^\s*\d{1,2}\s*$")
STEP = re.compile(r"^\s*\d{2}\. [A-Z][A-Z +/&:—-]*[:·]")
KNOWN_HEADS = {"Learning Resources","Concepts and Their Use on the Job",
               "Projects & Writings","Application Strategy","First Two Weeks","Your Immediate Differentiators",
               "The Gap and How Long It Takes to Close","Core Groups","Conferences","Philadelphia AppSec Community",
               "Phase Timeline","Study Methodology","Note-Taking: Notes → Note Cards","Portfolio: Writeups & Project Site",
               "Local & Regional Events"}
def is_heading(l):
    t = l.strip()
    if t in KNOWN_HEADS or any(t.startswith(k+" ") for k in ("Projects & Writings","Pre-Study Schedule","AppSec Intro","Web & Network Foundations","Core Vulnerability Classes","Security Testing & Tooling","Cloud Security Fundamentals","Secure Code Review","CompTIA Security+ Certification","Interview Preparation")):
        return True
    return bool(STEP.match(l))
issues = []
pages = pages_text(pdf)
for i, pg in enumerate(pages, 1):
    lines = [l for l in pg.split("\n") if l.strip() and not HDR.match(l) and not PGNUM.match(l)]
    if i <= 2 or not lines: continue                     # cover + contents
    if len(lines) < 8: issues.append((i, "NEAR-BLANK page", f"{len(lines)} content lines: {lines[0].strip()[:60]!r}"))
    first = lines[0].strip()
    frag_is_single = len(lines) == 1 or is_heading(lines[1]) or lines[1].strip().startswith("\u2022")
    if frag_is_single and (re.match(r"^[a-z(\u2018\u2019']", first) or re.match(r"^[A-Za-z].*[.!?\u2019']\s*$", first)):
        issues.append((i, "ORPHAN fragment at top", first[:80]))
    for k, l in enumerate(lines):
        if is_heading(l) and k >= len(lines) - 2:
            issues.append((i, "HEADING stranded at page bottom", l.strip()[:80]))
        if STEP.match(l):
            rest = lines[k+1:]
            if not any(r.strip().startswith("•") for r in rest):
                issues.append((i, "STEP title without any bullet on its page", l.strip()[:80]))
    last = lines[-1].rstrip()
    if (last.strip().startswith("•") or re.match(r"^\s{4,}\S", last)) and not re.search(r"[.!?’)\]\"]\s*$", last) and i < len(pages) and pages[i].strip():
        nxt = [l for l in pages[i].split("\n") if l.strip() and not HDR.match(l) and not PGNUM.match(l)]
        if nxt and re.match(r"^\s*[a-z(]", nxt[0]) and (len(nxt) == 1 or is_heading(nxt[1]) or nxt[1].strip().startswith("\u2022")):
            issues.append((i, "BULLET/entry leaves a single line on the next page", last.strip()[:80]))
# V36: no bare web addresses in the rendered text (product names that are domains are allowed)
ALLOW = ("localhost", "169.254.169.254", "flaws.cloud", "flaws2.cloud", "interviewing.io")
full = "\n".join(pages)
for tok in sorted(set(re.findall(r"(?<![\w@/])((?:[a-z0-9-]+\.)+(?:com|org|net|io|dev|cloud|shop|wiki)(?:/[\w\-./#?=&%+]*)?)", full))):
    tok = tok.rstrip(".,;)")
    if not any(a in tok for a in ALLOW):
        pg = next((i for i, p in enumerate(pages, 1) if tok in p), "?")
        issues.append((pg, "BARE URL printed (should be a hyperlink)", tok[:80]))
# V36: unbalanced parentheses within a bullet (joined across wrapped lines)
for i, pg in enumerate(pages, 1):
    lines = [l for l in pg.split("\n") if l.strip() and not HDR.match(l) and not PGNUM.match(l)]
    para = []
    def flush():
        if para:
            txt = " ".join(x.strip() for x in para)
            if txt.count("(") != txt.count(")"):
                issues.append((i, "UNBALANCED parentheses in a bullet", txt[:80]))
    for l in lines:
        if l.strip().startswith("\u2022") or is_heading(l):
            flush(); para = [l]
        else:
            para.append(l)
    flush()
print(f"pagination_check: {pdf}, {len(pages)} pages, {len(issues)} issue(s)")
for p, kind, txt in issues: print(f"  p{p:<3} {kind:<40} {txt}")
sys.exit(1 if issues else 0)
