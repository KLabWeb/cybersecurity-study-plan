import re as _re
# -*- coding: utf-8 -*-
"""
APPLICATION SECURITY ENGINEERING — STUDY PLAN — CONTENT
Faithful reconstruction of Study_Plan_-_2026-05-26.pdf
"""

from reportlab.platypus import Spacer, PageBreak, Paragraph, KeepTogether, CondPageBreak
from reportlab.lib.units import inch
import re

DJ = '<font name="DejaVu">\u2192</font>'   # arrow that renders
LINK = "#3A7AB8"                            # URL hyperlink colour (matches source)
_URL_RE = re.compile(
    r'(?<![\w@])((?:[A-Za-z0-9-]+\.)+(?:com|org|net|io|dev|cloud|gov|edu)(?:/[^\s,;)\]<]*)?)')

_ANCHOR_RE = re.compile(r'<a\b[^>]*>.*?</a>', re.S)


def linkify(text):
    """Wrap bare web URLs in clickable links coloured like the source (no underline).
    Skips any span already inside an <a>...</a> tag so manually-authored links (and the
    URLs inside their href attributes) are never re-wrapped."""
    def repl(m):
        url = m.group(1); tail = ""
        while url and url[-1] in ".,;:":
            tail = url[-1] + tail; url = url[:-1]
        href = url if url.startswith(("http://", "https://")) else "https://" + url
        return f'<a href="{href}" color="{LINK}">{url}</a>{tail}'
    out, last = [], 0
    for am in _ANCHOR_RE.finditer(text):
        out.append(_URL_RE.sub(repl, text[last:am.start()]))  # linkify outside the anchor
        out.append(am.group(0))                                # keep the anchor verbatim
        last = am.end()
    out.append(_URL_RE.sub(repl, text[last:]))
    return "".join(out)


def build_content(story, S, banner, bi, nb, rule, grid_table,
                  avail, ACCENT, HIGHLIGHT, LIGHT_BG, WHITE,
                  MID_GRAY, DARK, GOLD, GREEN_MID, GREEN_DRK,
                  colors, SP, KeepTogether, Paragraph, ParagraphStyle,
                  Table, TableStyle, Spacer, PageBreak, HRFlowable,
                  TA_JUSTIFY, TA_CENTER, TA_RIGHT, inch, page_overrides=None):

    add  = story.append
    adds = story.extend

    def P(text, style):
        return Paragraph(linkify(text).replace("\u2192", DJ), style)

    def B(text, sub=False):
        return bi(linkify(text).replace("\u2192", DJ), sub)

    def H(title):                       # top-level section heading + rule
        add(CondPageBreak(1.3*inch))    # never strand a heading at a page bottom (V30)
        add(P(title, S["sub_head"])); adds(rule())

    def SS(title, reserve=1.4*inch):   # sub-sub heading + rule
        add(CondPageBreak(reserve))     # heading + rule + about two lines (V37d softened from 2.2)
        add(P(title, S["sshead"])); adds(rule())

    def step(num, label, rest, items):
        add(CondPageBreak(1.2*inch))
        head = P(f"<b>{num}. {label}:</b> {rest}", S["body"])
        if items:                       # keep the title with its first bullet (V30)
            add(KeepTogether([head, B(items[0])]))
            for it in items[1:]:
                add(B(it))
        else:
            add(head)
        add(SP(4))

    def concept(name, text):
        add(KeepTogether([P(f"<b>{name}</b>", S["bul"]), P(text, S["bulsm"])]))

    _LBL = {"meetup.com": "Meetup", "docs.semgrep.dev": "rule-writing docs", "cyclonedx.org": "CycloneDX"}
    def _url(dom):
        # the two AWS wargame sites are HTTP-only static sites
        return ("http://" if dom.startswith("flaws") else "https://") + dom
    def _lnk(text, dom):
        return f'<a href="{_url(dom)}" color="#3A7AB8">{text}</a>'
    _DOM = r'(?:[a-z0-9-]+\.)+[a-z]{2,}[^\s\u2014\u00b7)]*'
    def res(title, details):
        # V36: printed web addresses become hyperlinks on the entry name.
        m = _re.match(r'^(' + _DOM + r')((?:\s*\u00b7\s*' + _DOM + r')*)\s*\u2014\s*(.*)$', details, _re.S)
        if m:
            title = _lnk(title, m.group(1)); rest = m.group(3)
            for d in _re.findall(_DOM, m.group(2)):
                lbl = next((v for k, v in _LBL.items() if k in d), d.split("/")[0])
                rest += f" ({_lnk(lbl, d)})"
            details = rest
        else:
            m = _re.match(r'^(.*?)\s*\((' + _DOM + r')\)\s*\u2014\s*(.*)$', details, _re.S)
            if m:
                title = _lnk(title, m.group(2)); details = f"{m.group(1)} \u2014 {m.group(3)}"
        add(B(f"<b>{title}</b> \u2014 {details}"))

    # ════════════════════════════════════════════════════════════════════════
    #  TABLE OF CONTENTS
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(P("Contents", S["sub_head"])); adds(rule())

    toc = [
        ("What Is Application Security?", "3", []),
        ("Why AppSec Engineering", "4",
            ["The Case for This Path", "Your Structural Advantage"]),
        ("Why This Moment", "6", []),
        ("Target Role: Application Security Engineer", "8",
            ["What It Is \u2014 Conceptually", "What It Is \u2014 In Practice",
             "Day-to-Day Responsibilities", "Philadelphia & Remote Market"]),
        ("Plan Schedule Overview", "10", ["Phase Timeline"]),
        ("Study Methodology", "11",
            ["Local & Regional Events", "Note-Taking",
             "Portfolio: Writeups & Project Site"]),
        ("AppSec: Potential Pitfalls & Risk Assessment", "15", []),
        ("Study Plan Phase Summary", "16", []),
        ("0 \u2014 Pre-Study: Foundations", "16",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("I \u2014 AppSec Intro: A Dip into Offense", "19",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("II \u2014 Web & Network Foundations", "22",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("III \u2014 Core Vulnerability Classes", "27",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("IV \u2014 Security Testing & Tooling", "30",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("V \u2014 Cloud Security Fundamentals", "34",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("VI \u2014 Secure Code Review & Threat Modeling", "37",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("VII \u2014 CompTIA Security+ Certification", "40",
            ["Learning Resources", "Schedule", "Projects & Writings", "Concepts and Their Use on the Job"]),
        ("VIII \u2014 Interview Preparation & Interviewing", "42",
            ["Interview Preparation", "Application Strategy"]),
        ("IX \u2014 Expected First Days on the Job", "44",
            ["Your Immediate Differentiators"]),
        ("Appendix", "46",
            ["Philadelphia AppSec Community"]),
    ]
    _ov = page_overrides or {}
    for title, page, subs in toc:
        page = _ov.get(title, page)          # build may override with the actual scanned page
        add(P(f'<b>{title}</b><font color="#AAAAAA">{"."*max(2, 62-len(title))}</font>{page}',
              S["toc_entry"]))
        for sub in subs:
            add(P(f"\u2013 {sub}", S["toc_sub"]))
        add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  WHAT IS APPLICATION SECURITY?
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    H("What Is Application Security?")
    for para in [
        "Application security \u2014 AppSec \u2014 is the discipline of finding, fixing, and "
        "preventing security vulnerabilities in software. Where most of software engineering "
        "asks <i>does this work?</i>, application security asks <i>can this be broken?</i> The "
        "question sounds simple. The implications are not.",
        "Software has an attack surface: every input field, every API endpoint, every "
        "authentication flow, every dependency in your requirements.txt is a potential entry "
        "point for an adversary. AppSec engineers systematically map that surface, probe it for "
        "weaknesses, and work with development teams to close them \u2014 before attackers find "
        "them first.",
        "The discipline spans the entire software development lifecycle. In the design phase, it "
        "means threat modeling \u2014 drawing data flows and asking what happens when an attacker "
        "controls each input. During development, it means secure code review \u2014 reading code "
        "the way an attacker reads it, looking for injection points, broken authentication, "
        "insecure data handling. In testing, it means static analysis (SAST) that reads source "
        "code for vulnerability patterns, dynamic analysis (DAST) that probes a running "
        "application, and manual penetration testing that combines both with adversarial "
        "creativity.",
        "The OWASP Top 10 is the field\u2019s shared vocabulary for the most critical web "
        "application security risks. SQL injection, broken access control, cross-site scripting, "
        "security misconfigurations, software supply chain failures, and other key risks. These are not abstract "
        "academic concerns \u2014 they are the specific vulnerability classes that appear in real "
        "breaches against real companies, year after year. AppSec engineers know them the way a "
        "surgeon knows anatomy: not as a list to memorize, but as a framework for understanding "
        "how systems fail.",
        "This plan targets web application security specifically \u2014 the attack surface that "
        "lives at the HTTP layer, in APIs, in authentication flows, in the browser.",
    ]:
        add(P(para, S["body"])); add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  WHY APPSEC ENGINEERING
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    H("Why AppSec Engineering")
    SS("The Case for This Path")
    add(P("You spent five years building the attack "
          "surface that AppSec engineers protect. You know FastAPI microservices, React "
          "frontends, AWS infrastructure, Docker containers, legacy PHP codebases "
          "\u2014 the exact technology stack that "
          "AppSec work asks you to reason about adversarially.", S["body"]))
    SS("Your Structural Advantage")
    add(P("Most AppSec engineers come from one of two directions: former developers who learned security, or security professionals who learned development. You are in the first category, which means you understand not just what the vulnerability is but why developers write it. The code patterns that lead to SQL injection, authentication bypasses, and CORS misconfigurations are patterns that developers encounter every day. Recognizing them as vulnerabilities \u2014 rather than just implementation choices \u2014 is the shift this plan builds. That background is the primary qualification.", S["body"]))
    add(SP(2))
    add(P("Specific transferable skills from your resume:", S["body"]))
    add(B("<b>FastAPI microservices</b> \u2014 REST API security is a core AppSec domain. Hands-on API security knowledge built throughout this plan means arriving on day "
          "one prepared for the work."))
    add(B("<b>Python</b> \u2014 The primary scripting language for AppSec tooling. Custom Semgrep "
          "rules, vulnerability scanning automation, security utilities."))
    add(B("<b>React frontends</b> \u2014 Client-side vulnerabilities (XSS, CSRF, insecure "
          "storage) require understanding how the browser executes JavaScript. React experience "
          "provides a strong foundation for understanding client-side vulnerability patterns."))
    add(B("<b>AWS, Docker, Kubernetes</b> \u2014 Cloud and container security are AppSec-adjacent "
          "and increasingly part of the role. Your infrastructure knowledge is a differentiator."))
    add(B("<b>Legacy PHP, raw SQL, and NoSQL</b> \u2014 You have worked in legacy PHP, hand-rolled MySQL, and DynamoDB \u2014 exactly where SQL injection, IDOR, and NoSQL injection live. You have seen where those patterns come from."))
    add(B("<b>Architecture &amp; domain modeling</b> \u2014 You designed microservices and "
          "domain-driven services with deliberate separation of concerns and trust boundaries. "
          "Threat modeling is that same structural thinking turned toward attack: mapping data "
          "flows and asking where trust is assumed."))
    add(B("<b>Testing discipline</b> \u2014 You wrote unit, integration, and regression tests. "
          "AppSec testing follows the same deterministic logic: inputs, expected behavior, failure modes."))
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  WHY THIS MOMENT
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())                  # every top-level chapter starts on a new page (V37d middle ground)
    H("Why This Moment")
    add(P("The case for entering application security in 2026 rests on concrete numbers, not "
          "hype. Here is what the data actually shows.", S["body"]))
    SS("The breach problem is not going away.")
    add(P("IBM\u2019s Cost of a Data Breach Report (2025 edition) \u2014 the most cited annual benchmark in "
          "the industry \u2014 found that the average U.S. cost of a data "
          "breach reached a record $10.22 million in 2025, even as the global average fell "
          "slightly to $4.44 million driven by faster AI-assisted detection. The U.S. number is "
          "the highest ever recorded. Nearly two-thirds of the 600 organizations IBM studied said "
          "they were still recovering from their breach at the time of the report. Verizon\u2019s "
          "2025 Data Breach Investigations Report found that exploitation of vulnerabilities "
          "\u2014 the class of attack that AppSec engineers specifically exist to prevent \u2014 "
          "was present in 20% of all breaches studied; the 2026 edition reports that vulnerability "
          "exploitation has overtaken stolen credentials as the leading way attackers get in.", S["body"]))
    SS("The workforce gap is structural.")
    add(P("ISC2\u2019s recent Workforce Studies estimate a global cybersecurity workforce gap of "
          "roughly 4.8 million people. The U.S. Bureau of Labor Statistics projects 29% job growth in information "
          "security analysis from 2024 to 2034 \u2014 nearly ten times the average growth rate "
          "across all occupations. For application security "
          "specifically, Mordor Intelligence reports a 15% annual shortfall of AppSec engineers "
          "in the United States \u2014 demand growing faster than the supply of "
          "qualified people to fill it.", S["body"]))
    add(P("The shortage is not evenly distributed. ISC2 noted in 2025 that skills shortages now "
          "outweigh headcount shortages as the primary constraint \u2014 meaning companies are "
          "not just short on bodies, they are short on people who can actually do the work. AI is "
          "automating the lowest complexity tasks (Tier 1 alert triage, routine vulnerability "
          "scanning), which is compressing demand for those roles. What it is not automating is "
          "the judgment-intensive work: finding business logic flaws that automated scanners "
          "cannot detect, threat modeling a new microservice architecture, explaining a critical "
          "finding to a VP of Engineering in terms that result in a fix. That work requires a "
          "human who can read code, understand systems, and think adversarially. That is the work "
          "this plan prepares you for.", S["body"]))
    SS("The AppSec market is expanding fast.")
    add(P("Straits Research values the global application security market at $12.71 billion in 2025 "
          "and projects $42.29 billion by 2034, about 14% annual growth. Application security "
          "testing is one of its fastest-growing segments. Mid-level Application Security "
          "Engineer postings commonly list roughly $130,000\u2013$180,000, and Product Security "
          "Engineer postings are among the faster-growing security titles.", S["body"]))
    add(SP(4))
    add(nb("<b>The structural argument:</b> IBM\u2019s data shows that organizations with severe "
           "security staffing shortages face $1.76 million higher breach costs than those that "
           "are adequately staffed. Companies are not hiring AppSec engineers because it is a "
           "nice-to-have. They are hiring because the cost of not having them is measurable, "
           "large, and growing."))

    # ════════════════════════════════════════════════════════════════════════
    #  TARGET ROLE
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())                  # every top-level chapter starts on a new page (V37d middle ground)
    H("Target Role: Application Security Engineer")
    SS("What It Is \u2014 Conceptually")
    add(P("Web application development and application security share the same foundation: HTTP, "
          "APIs, authentication flows, browser security models, database queries. Every endpoint "
          "in a web application is an AppSec concern. Every authentication flow is a potential "
          "bypass. Every React component that renders user input is an XSS candidate. Developers "
          "who learn AppSec understand the systems being defended \u2014 they are adding an "
          "adversarial lens to knowledge they already hold.", S["body"]))
    add(P("The shift is perspective. Where a developer asks <i>does this feature work "
          "correctly?</i>, an AppSec engineer asks <i>what happens when an attacker controls this "
          "input?</i> The underlying knowledge of the system is identical. The adversarial lens "
          "is the discipline.", S["body"]))
    SS("What It Is \u2014 In Practice")
    add(B("<b>Secure code review</b> (analogous to: pull request review, but adversarial) \u2014 "
          "Reading code to identify vulnerability patterns: SQL queries built by string "
          "concatenation, tokens stored in localStorage, endpoints missing authorization checks, "
          "user data rendered without sanitization."))
    add(B("<b>Penetration testing / DAST</b> (analogous to: integration testing, but "
          "adversarial) \u2014 Running Burp Suite against a staging environment, intercepting "
          "HTTP requests, modifying parameters, observing whether the application behaves "
          "securely."))
    add(B("<b>SAST tooling</b> (analogous to: adding a linter to CI/CD) \u2014 Integrating "
          "Semgrep into the pipeline. Writing custom rules that catch company-specific "
          "vulnerability patterns. Triaging scan results: true positives from false positives."))
    add(B("<b>Threat modeling</b> (analogous to: architecture review, but adversarial) \u2014 "
          "Given a proposed system design, enumerate the ways it could be attacked. STRIDE: "
          "Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation "
          "of Privilege."))
    add(B("<b>Vulnerability management</b> (analogous to: bug triage) \u2014 Prioritizing "
          "findings by severity and business impact. Writing clear reports developers can act on. "
          "Tracking remediation. Verifying fixes."))
    add(SP(2))
    SS("Day-to-Day Responsibilities")
    for t in [
        "Secure code review on high-risk PRs and new features \u2014 auth, payments, file "
        "upload, API endpoints",
        "Running and maintaining SAST tooling in CI/CD \u2014 Semgrep rules, false positive "
        "triage, new rule development",
        "Manual penetration testing of web applications and APIs \u2014 Burp Suite, "
        "methodology-driven, OWASP-aligned",
        "Threat modeling new system designs \u2014 STRIDE analysis, data flow diagrams, risk "
        "documentation",
        "Vulnerability reporting and remediation tracking \u2014 clear writeups, severity "
        "ratings, developer liaison",
        "Security training and developer education \u2014 lunch-and-learns, secure coding "
        "guidelines, champions programs",
        "Dependency and supply chain security \u2014 SCA scanning, CVE monitoring, patch "
        "prioritization",
    ]:
        add(B(t))
    add(SP(4))
    SS("Philadelphia & Remote Market")
    add(P("AppSec has strong remote availability \u2014 a large share of postings offer "
          "remote or hybrid flexibility. Local Philly demand is moderate but real, "
          "anchored by healthcare, financial services, and enterprise tech.", S["body"]))
    add(SP(2))
    add(SP(6))
    add(nb("Start applying at Week 16 for AI-native startups and security-conscious tech companies. Target Philadelphia legal AI and healthtech in parallel \u2014 these companies hire locally and a full-stack background is immediately relevant."))

    # ════════════════════════════════════════════════════════════════════════
    #  PLAN SCHEDULE OVERVIEW
    # ════════════════════════════════════════════════════════════════════════
    add(CondPageBreak(5*inch))      # short chapter: follow a brief tail, else start fresh
    H("Plan Schedule Overview")
    add(P("This plan is calibrated for 6\u20138 months at 25 study hours per week. 6 "
          "months is the optimistic case; 8 months is the outer bound; 7 months is the realistic "
          "midpoint. The hardest phase is not technical \u2014 it is "
          "mental: shifting from builder to adversarial thinker.", S["body"]))
    add(SP(2))
    sched = [
        [P("<b>Day Type</b>", S["th"]), P("<b>Days/Week</b>", S["th"]),
         P("<b>Hours</b>", S["th"]), P("<b>Notes</b>", S["th"])],
        [P("Long Study", S["tc"]), P("5", S["tcc"]), P("5 hrs", S["tcc"]),
         P("Reading, labs, implementation, tool practice, note card review, writeups", S["tc"])],
        [P("Day Off", S["tc"]), P("2", S["tcc"]), P("\u2014", S["tcc"]),
         P("No study, no work. Required for retention &amp; sanity.", S["tc"])],
    ]
    add(grid_table(sched, [1.5*inch, 0.85*inch, 0.85*inch, avail-3.2*inch]))
    add(SP(10))
    add(CondPageBreak(3.4*inch))     # keep the timeline chart with its heading (V30)
    SS("Phase Timeline")
    cols = ["0","I","II","III","IV","V","VI","VII","VIII","IX"]
    names = ["Pre-\nStudy","AppSec\nIntro","Web &\nNetwork","Core\nVulns","Testing &\nTooling",
             "Cloud\nSecurity","Code\nReview","Sec+\nCert","Interview\nPrep","First\nDays"]
    weeks = ["Wks 1–3","Wk 4","Wks 5–8","Wks 9–15","Wks 16–22",
             "Wk 23","Wks 24–26","Wks 27–30","Wks 31–34","Wk 35+"]
    tl_colors = ["#2C3E50","#1B4F72","#1A5276","#154360","#0E6655","#145A32",
                 "#6E2F1A","#6E2F3E","#2E4057","#212F3C"]
    romst = ParagraphStyle("tlrom", parent=S["pcc"], fontSize=10.5, leading=13,
                           fontName="Helvetica-Bold", textColor=WHITE, alignment=TA_CENTER)
    namst = ParagraphStyle("tlnam", parent=S["pcc"], fontSize=7, leading=8.5,
                           alignment=TA_CENTER, textColor=WHITE)
    wkst  = ParagraphStyle("tlwk", parent=S["pcc"], fontSize=7, leading=8.5,
                           alignment=TA_CENTER, textColor=WHITE)
    tdata = [
        [Paragraph(c, romst) for c in cols],
        [Paragraph(n.replace("\n","<br/>"), namst) for n in names],
        [Paragraph(w, wkst) for w in weeks],
    ]
    cw = avail/10.0
    tt = Table(tdata, colWidths=[cw]*10, rowHeights=[24, 38, 24])
    ts = [
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 2), ("BOTTOMPADDING", (0,0), (-1,-1), 2),
        ("LEFTPADDING", (0,0), (-1,-1), 1), ("RIGHTPADDING", (0,0), (-1,-1), 1),
    ]
    for ci, hexc in enumerate(tl_colors):
        ts.append(("BACKGROUND", (ci,0), (ci,-1), colors.HexColor(hexc)))
    tt.setStyle(TableStyle(ts))
    add(tt)
    add(SP(8))
    add(nb("<b>Timeline:</b> 6 months is the optimistic case; 8 months is the outer bound; 7 "
           "months is the realistic midpoint. The first 1\u20133 weeks are pre-study before "
           "security content begins. Start applying at Week 16 for startups and AppSec-adjacent "
           "roles. Security+ lands on your resume at Week 30, strengthening the main application "
           "push that follows."))

    # ════════════════════════════════════════════════════════════════════════
    #  STUDY METHODOLOGY
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())                  # every top-level chapter starts on a new page (V37d middle ground)
    H("Study Methodology")
    add(P("The methods below apply to every phase. Following them consistently is the difference "
          "between completing labs and actually owning the material.", S["body"]))
    SS("Local &amp; Regional Events")
    add(P("Studying is not only reading and labs \u2014 attending local and regional security "
          "events is part of the work, both to rebuild the sense of being part of the industry "
          "after heads-down solo study and because referrals come from people who have met you. A "
          "few worth knowing: the OWASP Philadelphia chapter (the most directly relevant group), "
          "Philly 2600 (the lowest-pressure entry point), and OWASP Global AppSec USA (city "
          "changes yearly; 2026 is San Francisco). Start showing up early \u2014 even one finished PortSwigger lab is "
          "enough to bring and talk about. See the Appendix section \u201c<a href=\"#philly_appsec\" "
          "color=\"#3A7AB8\">Philadelphia AppSec Community</a>\u201d for the full list of groups and "
          "conferences.", S["body"]))
    add(SP(2))
    SS("Note-Taking: Notes \u2192 Note Cards")
    add(P("Two outputs for every chapter or lab section: working notes during study, note cards "
          "derived from them afterward. Notes are for comprehension; note cards are for "
          "retention.", S["body"]))
    add(B("<b>During study:</b> Detailed working notes in your own words. For security concepts: "
          "what the vulnerability is, why the code is exploitable, how an attacker uses it, how "
          "to fix it. Questions you cannot answer yet."))
    add(B("<b>After each section:</b> Extract note cards. One concept per card. Front: "
          "vulnerability name. Back: what it is, how to identify it in code, how to fix it. If "
          "you cannot explain the fix without looking, you do not own the concept."))
    add(B("<b>Everything in Phases II\u2013V gets full note cards</b> \u2014 this is the material you will use daily on the job."))
    add(SP(2))
    SS("Portfolio: Writeups & Project Site")
    add(P("AppSec portfolios are built differently from software engineering portfolios. What "
          "distinguishes an AppSec candidate is documented offensive work: vulnerability "
          "writeups, lab solutions, CTF walkthroughs, threat model documents. A well-written writeup "
          "shows someone finding a vulnerability, understanding why it exists, exploiting it, and "
          "explaining the fix, in a way a resume line cannot.", S["body"]))
    add(B("<b>Writeup format:</b> one format for every writeup, taught in Phase I step 04 and used from Phase III on: "
          "(1) finding, (2) risk rating with CVSS, (3) summary, (4) technical details and evidence, "
          "(5) impact, (6) remediation, (7) code-review pattern \u2014 what a reviewer looks for in "
          "source to catch this class. The GitHub version follows this structure; the LinkedIn "
          "version can be a narrative rewrite of it (800\u20131,200 words)."))
    add(B("<b>Target:</b> the thirteen writeups scheduled before Week 16 (Phases I\u2013III), then the "
          "Juice Shop assessment report and the threat model before the main application push. Quality over quantity."))
    add(B("<b>GitHub:</b> Commit from Day 1 \u2014 the very first commit is this study plan and its "
          "build script. Keep everything in public repositories \u2014 the plan, notes, "
          "tooling-phase scripts, custom Semgrep rules, automation tools, and lab artifacts \u2014 "
          "building a continuous commit history from the start. Every README explains the "
          "methodology and what the artifact demonstrates \u2014 not just usage instructions."))

    # ════════════════════════════════════════════════════════════════════════
    #  PITFALLS & RISK ASSESSMENT
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    H("AppSec: Potential Pitfalls & Risk Assessment")
    concept("AI Replacing AppSec Engineers \u2014 Real but Limited",
            "AI-assisted SAST tools (GitHub Copilot Autofix, Snyk Code, Semgrep with AI triage) are improving and will automate more routine vulnerability scanning over time. The roles being automated are the lowest-end scan-and-report functions, not the manual code review, threat modeling, and developer consultation that constitutes senior AppSec work. Arriving with a portfolio of demonstrated manual security work is what automation cannot supply.")
    concept("Entry-Level Hiring Compression",
            "AI tools are handling some work that junior security analysts used to do. The mitigation is the same as it has always been in security hiring: arrive with a portfolio of real work rather than a list of certifications. Someone who can walk through a stored XSS chain and connect it to a real bypass they identified during code review stands out on portfolio alone.")
    concept("Certifications Are Not the Portfolio",
            "Sec+ is a recognized baseline credential in enterprise and regulated hiring. The plan treats Sec+ as the baseline and the portfolio as the evidence of skill.")
    concept("Moderate Philly Market",
            "Philadelphia\u2019s AppSec market is real but not as deep as New York, DC, or San Francisco. The mitigation is remote \u2014 a large share of AppSec postings offer remote or hybrid. Philadelphia is a base, not a constraint. The local network at OWASP and BSides matters most for referrals to companies not on job boards.")
    concept("Scope Creep into Red Team",
            "AppSec engineers frequently perform application-level penetration testing as part of the role \u2014 Burp Suite, manual web app testing, OWASP methodology. This is expected and built into the plan. The drift to avoid is into full red team or network penetration testing, which is a distinct specialization requiring different skills (Active Directory, network exploitation, infrastructure pivoting). Red team is typically a destination role requiring demonstrated AppSec or pentest experience first \u2014 not a direct entry point from developer. Master the AppSec role first.")
    add(SP(4))
    add(nb("<b>Net assessment:</b> The risks are real. None negate the market opportunity. The "
           "plan as designed \u2014 hands-on lab work over certifications, manual security skill "
           "over automated tooling familiarity, full-stack deployment capability \u2014 is "
           "structured to be resilient to the most likely downside scenarios."))

    # ----- STUDY PLAN PHASE SUMMARY -----
    add(PageBreak())
    H("Study Plan Phase Summary")
    add(SP(4))
    add(P("This plan turns a working software engineer into an entry-level AppSec engineer over roughly six to eight months. Rather than front-loading theory, it follows a deliberate arc: shore up the engineering base, get hands dirty with offense early, then build depth and professional tooling on top of that foundation.", S["body"]))
    add(SP(6))
    add(P("It opens by refreshing the fundamentals a developer already half-knows — Python and FastAPI, HTTP, Docker, a working local lab (Phase 0) — and immediately follows with a first taste of the attacker mindset (Phase I), so security feels concrete from the start rather than abstract. It then fills the web and network gaps most developers skipped on the way to shipping features (Phase II).", S["body"]))
    add(SP(6))
    add(P("The middle of the plan is the heart of the offensive skill set: going deep on the core vulnerability classes — injection, XSS, broken authentication and access control, SSRF, and the rest — by exploiting each one hands-on in deliberately vulnerable labs (Phase III), then layering on the professional toolchain (Burp Suite, plus SAST, DAST, dependency and secrets scanning) and earning the Burp Suite Certified Practitioner certification, a hands-on web-exploitation credential (Phase IV). A light thread of AI/LLM security — prompt injection, output handling, tool-calling risk — runs through these phases as well.", S["body"]))
    add(SP(6))
    add(P("The back half pivots toward the work an AppSec engineer actually does day to day — cloud security basics (Phase V) and secure code review and threat modeling (Phase VI) — rounded out by CompTIA Security+ for breadth and as the baseline credential enterprise and regulated employers recognize (Phase VII).", S["body"]))
    add(SP(6))
    add(P("It closes with focused interview preparation (Phase VIII) and the job search itself (Phase IX). Applications begin in parallel from Week 16, though — well before the curriculum is finished — because a growing portfolio of writeups, with BSCP preparation under way, is what actually opens doors.", S["body"]))
    add(SP(10))
    for _line in [
        "<b>Phase 0 — Pre-Study: Foundations</b> (Wks 1–3). <b>Purpose:</b> quickly refresh and expand the engineering base before security content — Python/FastAPI, HTTP, Docker, a working lab. <b>Resources:</b> FastAPI docs, HTTP (Notes + MDN), Docker (Notes). <b>Achievement:</b> a complete FastAPI app built from scratch and a running local lab.",
        "<b>Phase I — AppSec Intro: A Dip into Offense</b> (Wk 4). <b>Purpose:</b> first taste of the attacker mindset — how web vulnerabilities are found and exploited. <b>Resources:</b> <i>Real-World Bug Hunting</i> (Ch 1–5), PortSwigger Web Security Academy, TryHackMe, OWASP WebGoat. <b>Achievement:</b> first hands-on exploitation (WebGoat and PortSwigger) and the SQL injection essay published.",
        "<b>Phase II — Web & Network Foundations</b> (Wks 5–8). <b>Purpose:</b> deep HTTP, web, and authentication foundations plus Burp basics. <b>Resources:</b> <i>Alice and Bob Learn Application Security</i>, <i>WAHH</i>, Burp Suite docs, PortSwigger Authentication path. <b>Achievement:</b> Burp fluency, HTTP/auth/session mastery, and the PortSwigger Authentication, JWT, and OAuth labs cleared.",
        "<b>Phase III — Core Vulnerability Classes</b> (Wks 9–15). <b>Purpose:</b> master the core web vulnerability classes hands-on at practitioner depth. <b>Resources:</b> PortSwigger topic paths and their apprentice/practitioner labs, <i>Hacking APIs</i>, the OWASP Top 10, and the OWASP Top 10 for LLM Applications. <b>Achievement:</b> practitioner labs across the OWASP classes and the OWASP LLM Top 10, plus an OWASP Top 10 writeup series.",
        "<b>Phase IV — Security Testing & Tooling</b> (Wks 16–22). <b>Purpose:</b> tooling fluency — Burp mastery, SAST, DAST, SCA, and secrets scanning — and the BSCP certification. <b>Resources:</b> Burp docs, PortSwigger BSCP practice exams, Semgrep, Bandit, ZAP, Snyk, TruffleHog, Gitleaks. <b>Achievement:</b> passed the Burp Suite Certified Practitioner (BSCP) exam, completed a full Juice Shop security assessment, and secured a small LLM-backed API.",
        "<b>Phase V — Cloud Security Fundamentals</b> (Wk 23). <b>Purpose:</b> AWS security basics — shared responsibility, IAM, and common misconfigurations. <b>Resources:</b> flaws&#46;cloud, flaws2&#46;cloud, AWS IAM docs. <b>Achievement:</b> every level of the flaws&#46;cloud and flaws2&#46;cloud AWS security challenges completed, with one combined writeup, and the Phase 0 container image scanned and hardened.",
        "<b>Phase VI — Secure Code Review & Threat Modeling</b> (Wks 24–26). <b>Purpose:</b> the core AppSec craft — manual secure code review and threat modeling. <b>Resources:</b> OWASP Code Review Guide, OWASP ASVS, <i>Threat Modeling: Designing for Security</i>. <b>Achievement:</b> a documented code review and a threat model project.",
        "<b>Phase VII — CompTIA Security+ Certification</b> (Wks 27–30). <b>Purpose:</b> earn the baseline credential recognized in enterprise and regulated hiring; main application push. <b>Resources:</b> the <i>Get Certified Get Ahead: SY0-701</i> study guide and Professor Messer practice exams. <b>Achievement:</b> passed CompTIA Security+ (SY0-701).",
        "<b>Phase VIII — Interview Preparation & Interviewing</b> (Wks 31–34). <b>Purpose:</b> convert skills and portfolio into offers — interview prep, story framing, application strategy. <b>Resources:</b> <i>Impractical Python Projects</i>, a cybersecurity interview question bank, GitHub Security Lab, and mock interview platforms. <b>Achievement:</b> a polished portfolio and interview narrative, plus active interviewing.",
        "<b>Phase IX — Expected First Days on the Job</b> (Wk 35+). <b>Purpose:</b> start strong in the new sub-field and role and know your immediate differentiators. <b>Resources:</b> your accumulated notes and reference books. <b>Achievement:</b> a first-two-weeks plan, a clear grasp of your immediate differentiators, and early on-the-job wins.",
    ]:
        add(P(_line, S["bulsm"])); add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE 0 — PRE-STUDY
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("0", "Pre-Study: Foundations", "Weeks 1–3 \u00b7 Before Security Content Begins"))
    add(SP(10))
    add(P("Three parallel tracks before security content begins. The FastAPI track is the main "
          "one \u2014 1\u20133 weeks to close out the official docs and build a complete project "
          "from scratch. The others are a few days each, run in parallel. All of this is active, "
          "hands-on work. By the end of Week 3, AppSec content starts immediately.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("FastAPI Official Documentation", "fastapi.tiangolo.com \u2014 Official docs, "
        "self-contained. Read start to finish.")
    res("Existing HTTP Notes", "Personal notes (HTML intro + Odin HTTP). Cover request-response, "
        "methods, status codes, URL anatomy, headers, DNS, TCP/IP basics.")
    res("MDN Web Docs \u2014 Using HTTP Cookies", "developer.mozilla.org/en-US/docs/Web/HTTP/Guides/"
        "Cookies \u2014 Specifically for Secure, HttpOnly, and SameSite cookie attributes. The "
        "one HTTP topic not covered in existing notes.")
    res("Existing Docker Notes", "Personal notes and note cards covering containers, images, Dockerfiles, "
        "networking, volumes, Compose, Swarm, and Stack. More comprehensive than any online "
        "tutorial.")
    res("DigitalOcean \u2014 Install and Use Docker", "digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-22-04 "
        "\u2014 a step-by-step, command-by-command walkthrough of the container lifecycle.")
    res("OWASP WebGoat", "github.com/WebGoat/WebGoat \u2014 Deliberately insecure web application "
        "covering OWASP Top 10 vulnerability classes with structured hands-on exploitation "
        "modules. Runs via Docker.")
    add(SP(4))
    SS("Pre-Study Schedule \u2014 Weeks 1–3")
    step("01", "SETUP", "Git & GitHub Hygiene \u00b7 Day 1", [
        "GitHub profile already exists with past projects. Before new portfolio work begins: "
        "confirm profile is public, bio is current, location is set to Philadelphia, PA.",
        "Review existing pinned repos \u2014 anything from the web dev years that still reflects "
        "well is worth keeping pinned. Anything that does not, unpin.",
        "Create a new repository for the FastAPI project. Commit as you build \u2014 clean "
        "messages, logical history. This repo is a portfolio artifact from day one and will be "
        "the most recent, actively developed project on the profile.",
        "Set up LinkedIn in parallel: headline and About section state the deliberate transition "
        "into application security as of August 2026. Certifications and portfolio links get added "
        "as they are earned and built.",
    ])
    step("02", "REVIEW", "HTTP & Cookies \u00b7 Days 1\u20133", [
        "<b>HTTP:</b> Review existing HTTP notes (PDF, .odt, and note cards). These "
        "cover the request-response model, methods (GET, POST, PUT, PATCH, DELETE), status codes "
        "(2xx, 3xx, 4xx, 5xx), URL anatomy, headers, DNS, and TCP/IP basics.",
        "<b>Cookies:</b> Cookies are not covered in the existing notes. Read <a href=\"https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Cookies\" color=\"#3A7AB8\">MDN \u2018Using HTTP "
        "cookies\u2019</a> specifically for the "
        "security attributes: Secure (only sent over HTTPS), HttpOnly (inaccessible to "
        "JavaScript), and SameSite (controls cross-site request behavior). These three attributes "
        "appear throughout security review work.",
        "<b>SQL:</b> SQL is strong from prior study \u2014 joins, normalization, indexing. Do a "
        "fast review using existing SQL note cards.",
    ])
    step("03", "READ + BUILD", "FastAPI Documentation \u2014 Complete \u00b7 Weeks 1–3", [
        "<a href=\"https://fastapi.tiangolo.com/\" color=\"#3A7AB8\">The official docs</a> cover Dependencies, Security, Middleware, CORS, Request Body, and Response "
        "Model \u2014 exactly the sections most relevant to AppSec work. Finishing the docs "
        "builds the complete mental model needed to audit production web codebases.",
        "<b>Starting point:</b> Start from the beginning. Re-read your notes from the covered "
        "sections (intro, path params, query params) first, then continue through the remaining "
        "tutorial sections. Slow down at Dependencies, Security, Middleware, and CORS \u2014 those "
        "four sections warrant the most detailed notes.",
        "<b>Build a personal FastAPI project as part of the reading:</b> Five years of adding to "
        "others\u2019 APIs is solid experience. Building one end-to-end \u2014 from blank file to "
        "deployed container \u2014 completes the picture. Design something small but complete: "
        "5\u20136 endpoints, JWT authentication implemented via FastAPI\u2019s Security module, at "
        "least one dependency-injected auth check, a SQL database connection. The goal is to own a "
        "codebase fully from the ground up, which makes it the best candidate for security "
        "analysis work later in the plan.",
    ])
    step("04", "LEARN + PRACTICE", "Docker \u00b7 Days 2\u20134", [
        "Review your existing Docker notes and note cards to refresh the fundamentals \u2014 containers and images, "
        "the run / stop / remove lifecycle, and port mapping.",
        "Work through DigitalOcean\u2019s <a href=\"https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-22-04\" color=\"#3A7AB8\">How to Install "
        "and Use Docker</a> guide for a command-by-command walkthrough of the container lifecycle: pull an image, run "
        "a container, list with docker ps, then stop and remove it.",
        "<b>Practice:</b> pull and run <a href=\"https://github.com/WebGoat/WebGoat\" color=\"#3A7AB8\">OWASP "
        "WebGoat</a> in a container \u2014 publish it to a port, open it in the browser, then stop and remove it. "
        "Standing up a vulnerable target app in a container is the Docker skill you will actually use as an AppSec "
        "engineer, and you will repeat it for Juice Shop and other target apps later.",
    ])
    SS("Projects & Writings \u2014 Pre-Study")
    add(P("<b>Project: FastAPI API \u2014 Built From Scratch</b>", S["bul"]))
    add(P("A complete FastAPI application: 5\u20136 endpoints, JWT auth, dependency-injected auth "
          "checks, SQL database. Committed to GitHub with clean history. First portfolio artifact.",
          S["bulsm"]))
    add(P("<b>Project: Dockerized FastAPI App</b>", S["bul"]))
    add(P("Dockerfile for the FastAPI project. Built into an image, run as a container.", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("FastAPI security internals",
            "How FastAPI implements authentication and authorization via the Security module and Depends(). Where JWT validation happens. How middleware intercepts requests. How CORS is configured at the framework level. <b>On the job:</b> These are the layers you audit when reviewing application code for security issues.")
    concept("Cookie security attributes",
            "Secure, HttpOnly, and SameSite are not just configuration options — they are security controls. <b>On the job:</b> Their absence or misconfiguration is a finding in any security review.")
    concept("Docker as a tool in AppSec",
            "Containers provide isolation but also create attack surfaces: exposed ports, over-permissioned images, secrets in environment variables. <b>On the job:</b> Standing up a vulnerable target app in a container, as with WebGoat here, is how you run every target environment in this plan and most assessment work.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE I — APPSEC INTRO
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("I", "AppSec Intro: A Dip into Offense", "Week 4"))
    add(SP(10))
    add(P("From outside, AppSec can look inaccessible without years of CTF experience. It is not, "
          "and this phase exists to demonstrate that directly \u2014 before any systematic study "
          "begins.", S["body"]))
    add(P("The goal is not to become a penetration tester in one week. It is to arrive at the "
          "Web & Network Foundations phase having touched real vulnerability classes with your "
          "hands, developed genuine questions about why they work the way they do, and "
          "established the foundational mental model: every input is a potential attack vector, "
          "and your job is to think about what happens when an attacker controls it.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("PortSwigger Web Security Academy", "portswigger.net/web-security \u2014 The most widely "
        "recommended AppSec learning resource among practitioners. Interactive labs, structured "
        "learning paths, every major vulnerability class covered. Built by the team that makes "
        "Burp Suite. Primary hands-on platform for the entire plan.")
    res("OWASP WebGoat", "github.com/WebGoat/WebGoat \u2014 A deliberately insecure application "
        "for learning. Runs locally via Docker. Structured modules per vulnerability class.")
    res("TryHackMe", "tryhackme.com \u2014 Browser-based, beginner-friendly, guided rooms. The "
        "<a href=\"https://tryhackme.com/path/outline/jrpenetrationtester\" color=\"#3A7AB8\">"
        "\u2018Jr Penetration Tester\u2019</a> path covers "
        "<a href=\"https://tryhackme.com/room/burpsuitebasics\" color=\"#3A7AB8\">Burp Suite: The Basics</a>, web "
        "vulnerabilities, and penetration testing methodology. "
        "<a href=\"https://tryhackme.com/room/httpindetail\" color=\"#3A7AB8\">HTTP in Detail</a> is a standalone room.")
    res("“<i>Real-World Bug Hunting</i>”", "Peter Yaworski, No Starch Press, 2019 (nostarch.com) \u2014 A "
        "highly accessible introduction to web vulnerabilities. Real bug bounty reports, plain "
        "English, organized by vulnerability class.")
    add(SP(4))
    SS("AppSec Intro \u2014 Week 4")
    step("01", "EXPLORE", "TryHackMe Orientation \u00b7 Week 4", [
        "Complete two short <a href=\"https://tryhackme.com/path/outline/jrpenetrationtester\" color=\"#3A7AB8\">TryHackMe</a> rooms \u2014 "
        "<a href=\"https://tryhackme.com/room/httpindetail\" color=\"#3A7AB8\">HTTP in Detail</a> and "
        "<a href=\"https://tryhackme.com/room/burpsuitebasics\" color=\"#3A7AB8\">Burp Suite: The Basics</a>",
        "These are short and designed for orientation, not mastery",
    ])
    step("02", "EXPLORE", "PortSwigger Academy Orientation \u00b7 Week 4", [
        "<a href=\"https://portswigger.net/web-security\" color=\"#3A7AB8\">Create a free PortSwigger account</a>",
        "Skim the <a href=\"https://portswigger.net/web-security/sql-injection\" color=\"#3A7AB8\">SQL "
        "injection</a> material to get oriented, then complete the first 3\u20134 Apprentice & Practitioner level "
        "<a href=\"https://portswigger.net/web-security/all-labs#sql-injection\" color=\"#3A7AB8\">labs</a>",
        "Skim the <a href=\"https://portswigger.net/web-security/cross-site-scripting\" color=\"#3A7AB8\">"
        "cross-site scripting</a> material to get oriented, then complete the first 2 Apprentice-level "
        "<a href=\"https://portswigger.net/web-security/all-labs#cross-site-scripting\" color=\"#3A7AB8\">"
        "labs</a> (reflected and stored)",
        "Reading the official solution is completely fine in this phase. Phase I is orientation, not "
        "mastery \u2014 the goal is to see how an attack actually works and lose the sense that it is "
        "magic, not to invent it unaided. If a lab stumps you, follow the walkthrough. You will learn "
        "these vulnerability classes properly, and solve them without help, in Phases II\u2013III.",
    ])
    step("03", "READ", "“<i>Real-World Bug Hunting</i>” Ch. 1\u20135 \u00b7 Week 4", [
        "<a href=\"https://nostarch.com/bughunting\" color=\"#3A7AB8\">Chapter 1</a> covers bug bounty and HTTP basics; Chapters 2\u20135 are each a vulnerability "
        "class \u2014 open redirect, HTTP parameter pollution, CSRF, and HTML injection / content "
        "spoofing \u2014 illustrated with real disclosed bug bounty reports",
        "Read actively: when a report describes a finding in a Python or REST API context, pause "
        "and think about what the vulnerable pattern looks like in code \u2014 this builds the "
        "adversarial mental model",
    ])
    step("04", "LEARN", "Writing Pentest Reports \u00b7 Week 4", [
        "Complete the free TryHackMe room "
        "<a href=\"https://tryhackme.com/room/vulnerabilities101\" color=\"#3A7AB8\">"
        "Vulnerabilities 101</a> (about 20 minutes). The goal is Task 3, Scoring Vulnerabilities "
        "(CVSS & VPR): how a CVSS score is built from its metrics",
        "Complete the free TryHackMe room "
        "<a href=\"https://tryhackme.com/room/writingpentestreports\" color=\"#3A7AB8\">"
        "Writing Pentest Reports</a> \u2014 its write-up structure has eight parts: title, risk "
        "rating, summary, background, technical details and evidence, impact, remediation advice, "
        "references",
        "The plan\u2019s writeup format keeps six of those (the finding as title, CVSS as the risk "
        "rating, summary, technical details and evidence, impact, remediation) and adds one the room "
        "does not cover \u2014 the <b>code-review pattern</b>: two to "
        "four lines on what a reviewer looks for in source to catch this class (the vulnerable "
        "construct, the safe construct that replaces it, and where it tends to hide). Sources for "
        "it: the \u2018How to prevent\u2019 section of the PortSwigger topic page and the class\u2019s "
        "<a href=\"https://cheatsheetseries.owasp.org/\" color=\"#3A7AB8\">OWASP Cheat Sheet</a>",
        "Practise the full seven-part format once on a WebGoat lesson you have finished (SQL Injection "
        "intro is the easiest) so the format is familiar before Phase III",
        "First portfolio use of the format is the Phase III vulnerability-class writeups; the WebGoat "
        "lessons in the next step are practice, logged as notes only",
    ])
    step("05", "PROJECT", "WebGoat \u2014 First Exploitation \u00b7 Week 4", [
        "Ensure local <a href=\"https://github.com/WebGoat/WebGoat\" color=\"#3A7AB8\">WebGoat</a> still executes as expected in local Docker",
        "Complete these WebGoat lessons: SQL Injection (intro), Cross Site Scripting, Cross Site "
        "Scripting (stored), Authentication Bypasses, and Insecure Direct Object References (IDOR)",
        "For each lesson: exploit it, then keep a short notes-only log \u2014 the payload used, what it did, "
        "and one line on the root cause in the Java source. These are practice notes, not portfolio "
        "writeups: the lessons hand you the vulnerability, so a formal report would overstate the work",
        "Then write the essay \u2018What SQL Injection Taught Me About Trusting Input\u2019 (900\u20131,200 "
        "words): a plain-English account of what SQL injection is, why it works, and one thing that "
        "surprised you in the WebGoat and PortSwigger labs. Publish on LinkedIn when polished",
    ])
    SS("Projects & Writings \u2014 AppSec Intro")
    add(P("<b>Notes: WebGoat Practice Log</b>", S["bul"]))
    add(P("For each WebGoat lesson completed, a short entry in the notes repo: payload, effect, "
          "and root cause in the code. Practice notes, not a portfolio finding \u2014 the lessons "
          "hand you the vulnerability. The formal vulnerability-class writeups begin in Phase III; the essay below is the first published piece.", S["bulsm"]))
    add(P("<b>Writing: What SQL Injection Taught Me About Trusting Input (900\u20131,200 words)</b>",
          S["bul"]))
    add(P("Plain-English explanation of what SQL injection is, why it works, and one thing that "
          "surprised you. Publish on LinkedIn when polished. Framing: \u2018I have been building "
          "APIs for five years. Here is what I learned when I tried to break one.\u2019", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("The OWASP Top 10",
            "Introduced as a taxonomy. You have seen SQL injection and XSS in practice. The full Top 10 is a structured catalog of the most critical web vulnerability classes. Mastery of each class comes through dedicated study. <b>On the job:</b> This is the vocabulary of every code review and architecture conversation. When a developer asks why their code is flagged, you explain which OWASP category it falls into and why it matters.")
    concept("Injection as a class",
            "Any time user input reaches an interpreter without proper sanitization, injection is possible. SQL injection is the canonical example. Command injection, LDAP injection, and template injection follow the same logic. <b>On the job:</b> When reviewing an API endpoint that accepts user input, your first question is always: does this input reach an interpreter? A database query? A shell command? A template renderer? This question catches vulnerabilities automated tools miss.")
    concept("The attacker’s mindset",
            "The mental shift from ‘does this work?’ to ‘what happens when I control this input?’ This is the foundational perspective change. You have started making it.")
    concept("HTTP as the attack surface",
            "Every web vulnerability lives in the HTTP layer — parameters, headers, cookies, request bodies. Understanding HTTP is the substrate for every vulnerability class in this plan. <b>On the job:</b> Every Burp Suite session, every manual pentest, every DAST scan result is an HTTP transaction. Reading raw HTTP requests and responses fluently is required for the work.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE II — WEB & NETWORK FOUNDATIONS
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("II", "Web & Network Foundations", "Weeks 5–8"))
    add(SP(10))
    add(P("This phase builds the technical foundation for AppSec work. Every major vulnerability "
          "class lives inside HTTP, authentication protocols, browser security models, or API "
          "design patterns. The phase reframes these layers from an adversarial perspective "
          "\u2014 not just how they work, but why they fail. It closes with the defender\u2019s view of "
          "AppSec (Alice and Bob) and cryptography fundamentals.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("“<i>Alice and Bob Learn Application Security</i>”", "Tanya Janca (SheHacksPurple), Wiley, 2020 "
        "(wiley.com) \u2014 Covers threat modeling, secure code review, SDLC "
        "security, and how to work with developers. Covers the defender-side, program-building "
        "angle that pure offensive resources miss.")
    res("“<i>The Web Application Hacker’s Handbook</i>”", "Dafydd Stuttard and Marcus Pinto, Wiley, "
        "2011 (wiley.com) \u2014 Foundational reference written by the creator of Burp Suite. Ch. "
        "1\u20133 cover web application security, core defense mechanisms, and web application technologies. Ch. 6 covers "
        "authentication, Ch. 7 session management, Ch. 8 access controls. Some content is aging "
        "but these chapters remain the clearest treatment available.")
    res("PortSwigger Web Security Academy", "portswigger.net/web-security \u2014 Primary lab "
        "platform for this phase. Covers authentication "
        "attacks, access control vulnerabilities, and SQL injection \u2014 all with interactive "
        "labs.")
    res("MDN Web Docs", "developer.mozilla.org \u2014 The authoritative reference for HTTP, "
        "cookies, CORS, CSP, and the browser security model. Covers each security header, its "
        "syntax, and its security purpose in depth.")
    res("OWASP SSRF Prevention Cheat Sheet", "cheatsheetseries.owasp.org/cheatsheets/"
        "Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html \u2014 Covers the two SSRF cases, "
        "allowlist and resolved-address validation, IMDSv2 on AWS, and deny-lists as a last resort.")
    res("TryHackMe \u2018Pre-Security\u2019 path \u2014 Network Fundamentals module",
        "tryhackme.com/module/network-fundamentals \u2014 Primary resource for the networking week. Covers OSI model, TCP/IP, "
        "ports, and how packets travel in about two interactive hours. Not Net+, not CCNA \u2014 "
        "precisely scoped for AppSec-relevant networking.")
    res("TryHackMe \u2018Pre-Security\u2019 path \u2014 Putting It All Together room",
        "tryhackme.com/room/puttingitalltogether \u2014 Covers how all the components of a web request fit together: DNS, "
        "HTTP, load balancers, CDNs, databases, WAFs, and how each layer relates to security decisions.")
    res("OWASP Cryptographic Storage Cheat Sheet", "cheatsheetseries.owasp.org/cheatsheets/"
        "Cryptographic_Storage_Cheat_Sheet.html \u2014 Primary reference for the cryptography "
        "week. Covers which algorithms are acceptable and which are broken, key management, and "
        "storage patterns.")
    res("OWASP Transport Layer Security Cheat Sheet", "cheatsheetseries.owasp.org/cheatsheets/"
        "Transport_Layer_Security_Cheat_Sheet.html \u2014 TLS configuration, certificate "
        "management, and common misconfigurations. Companion to the crypto week.")
    res("hashcat", "hashcat.net/wiki \u2014 Password cracking tool used in the cryptography week "
        "to crack an MD5 hash and make weak hashing concrete. The wiki\u2019s Dictionary attack and "
        "Example hashes pages give the exact commands for an MD5 wordlist attack.")
    res("bcrypt (Python library)", "pypi.org/project/bcrypt \u2014 Python library for bcrypt "
        "password hashing. Used in the cryptography week to implement correct password hashing in "
        "Python. Simple API: hash a password, verify a password.")
    res("OpenID Connect \u2014 How Connect Works", "openid.net/developers/how-connect-works \u2014 The OpenID "
        "Foundation\u2019s overview of how OIDC adds an identity layer on top of OAuth 2.0.")
    res("OWASP SAML Security Cheat Sheet", "cheatsheetseries.owasp.org/cheatsheets/SAML_Security_Cheat_Sheet.html "
        "\u2014 What breaks in SAML single sign-on (signature wrapping, replay, weak validation) and how to review it.")
    add(SP(4))
    SS("Web & Network Foundations \u2014 Weeks 5–8")
    step("01", "READ", "HTTP Deep Dive \u00b7 Week 5", [
        "Read <a href=\"https://www.wiley.com/en-us/The+Web+Application+Hacker%27s+Handbook%3A+Finding+and+Exploiting+Security+Flaws%2C+2nd+Edition-p-9781118026472\" color=\"#3A7AB8\"><i>WAHH</i></a> Ch. 1\u20133 (web application security, core defense mechanisms, web application "
        "technologies) as foundational context",
        "You installed Burp and learned its basics in Phase I. Now go deeper via the official documentation \u2014 "
        "<a href=\"https://portswigger.net/burp/documentation/desktop/tools/proxy\" color=\"#3A7AB8\">Proxy</a>, <a href=\"https://portswigger.net/burp/documentation/desktop/tools/repeater\" color=\"#3A7AB8\">Repeater</a>, and "
        "<a href=\"https://portswigger.net/burp/documentation/desktop/tools/intruder\" color=\"#3A7AB8\">Intruder</a> \u2014 the primary tools you will use throughout this phase",
        "Read <a href=\"https://portswigger.net/web-security/cors\" color=\"#3A7AB8\">CORS misconfigurations</a>, "
        "<a href=\"https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP\" color=\"#3A7AB8\">CSP</a>, <a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html\" color=\"#3A7AB8\">TLS</a>, <a href=\"https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Methods\" color=\"#3A7AB8\">HTTP methods</a>, and "
        "<a href=\"https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status\" color=\"#3A7AB8\">status codes</a> for their security implications",
        "<b>Full notes + note cards:</b> CORS misconfigurations, CSP, TLS, HTTP methods, and status codes with security implications",
    ])
    step("02", "READ + LABS", "Input Handling Fundamentals \u00b7 Week 5", [
        "Read the PortSwigger <a href=\"https://portswigger.net/web-security/sql-injection\" color=\"#3A7AB8\">SQL injection</a> learning path, then work the apprentice-level <a href=\"https://portswigger.net/web-security/all-labs#sql-injection\" color=\"#3A7AB8\">labs</a> to internalize the "
        "input-validation root cause \u2014 the practitioner labs follow in Phase III",
        "<b>Full notes + note cards:</b> SQL injection root cause, parameterized queries, "
        "injection taxonomy",
    ])
    step("03", "READ + LABS", "Authentication & Session Management \u00b7 Weeks 5\u20136", [
        "Read <a href=\"https://www.wiley.com/en-us/The+Web+Application+Hacker%27s+Handbook%3A+Finding+and+Exploiting+Security+Flaws%2C+2nd+Edition-p-9781118026472\" color=\"#3A7AB8\"><i>WAHH</i></a> Ch. 6 (Attacking Authentication) and Ch. 7 (Attacking Session Management)",
        "Complete the PortSwigger <a href=\"https://portswigger.net/web-security/authentication\" color=\"#3A7AB8\">Authentication</a> learning path \u2014 all apprentice and "
        "practitioner <a href=\"https://portswigger.net/web-security/all-labs#authentication\" color=\"#3A7AB8\">labs</a>",
        "Complete the <a href=\"https://portswigger.net/web-security/jwt\" color=\"#3A7AB8\">JWT</a> learning path, then its <a href=\"https://portswigger.net/web-security/all-labs#jwt\" color=\"#3A7AB8\">labs</a> \u2014 unverified signature, flawed signature verification, weak signing key, jwk / jku injection, and <i>algorithm confusion</i>; then the <a href=\"https://portswigger.net/web-security/oauth\" color=\"#3A7AB8\">OAuth</a> learning path and its <a href=\"https://portswigger.net/web-security/all-labs#oauth-authentication\" color=\"#3A7AB8\">labs</a> \u2014 implicit-flow bypass, forced profile linking, and <i>account hijacking via redirect_uri</i>",
        "Read how <a href=\"https://openid.net/developers/how-connect-works/\" color=\"#3A7AB8\">OpenID Connect</a> layers identity on OAuth 2.0 and the "
        "<a href=\"https://cheatsheetseries.owasp.org/cheatsheets/SAML_Security_Cheat_Sheet.html\" color=\"#3A7AB8\">OWASP SAML Security Cheat Sheet</a>; no labs, one page of notes each. "
        "OAuth, OIDC, and SAML are the three protocols an authentication review meets",
        "<b>Full notes + note cards:</b> Password enumeration, session fixation, JWT algorithm confusion, OAuth redirect URI manipulation",
    ])
    step("04", "READ + LABS", "Access Control & APIs \u00b7 Week 7", [
        "Read <a href=\"https://www.wiley.com/en-us/The+Web+Application+Hacker%27s+Handbook%3A+Finding+and+Exploiting+Security+Flaws%2C+2nd+Edition-p-9781118026472\" color=\"#3A7AB8\"><i>WAHH</i></a> Ch. 8 (Attacking Access Controls)",
        "Read the PortSwigger <a href=\"https://portswigger.net/web-security/access-control\" color=\"#3A7AB8\">Access control</a> and <a href=\"https://portswigger.net/web-security/api-testing\" color=\"#3A7AB8\">API testing</a> learning paths, then work the "
        "apprentice-level Access control <a href=\"https://portswigger.net/web-security/all-labs#access-control-vulnerabilities\" color=\"#3A7AB8\">labs</a> and API testing <a href=\"https://portswigger.net/web-security/all-labs#api-testing\" color=\"#3A7AB8\">labs</a> to build the foundational mental model \u2014 the practitioner labs follow in Phase III",
        "<b>Full notes + note cards:</b> IDOR, horizontal/vertical privilege escalation, mass "
        "assignment, excessive data exposure",
    ])
    step("05", "PROJECT", "Authentication Audit Checklist \u00b7 Week 7", [
        "Write a 1\u20132 page authentication audit checklist from scratch \u2014 no templates",
        "Every item should come from a concept in your notes",
        "For each item: what you check, how you check it (manually and with what tool), and what "
        "a finding looks like",
        "Run the checklist against the FastAPI app you built in Phase 0 \u2014 it implements JWT "
        "authentication via <a href=\"https://fastapi.tiangolo.com/tutorial/security/\" color=\"#3A7AB8\">FastAPI\u2019s Security module</a>, so it is the ideal first audit "
        "target. Record any findings in the seven-part report format from Phase I step 04",
        "Push to GitHub as Markdown. First real security artifact in the portfolio.",
    ])
    step("06", "STUDY", "Networking Fundamentals for AppSec \u00b7 Week 7", [
        "Complete the TryHackMe \u2018Pre-Security\u2019 path \u2014 <a href=\"https://tryhackme.com/module/network-fundamentals\" color=\"#3A7AB8\">Network Fundamentals module</a>. "
        "Take notes.",
        "Review existing notes for the URL-to-response flow.",
        "Read the <a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html\" color=\"#3A7AB8\">OWASP SSRF Prevention Cheat Sheet</a>, then the one-page \u2018DNS Rebinding\u2019 section in WAHH Ch. 13 for the mechanism the concept below relies on.",
        "Complete the TryHackMe \u2018Pre-Security\u2019 path \u2014 <a href=\"https://tryhackme.com/room/puttingitalltogether\" color=\"#3A7AB8\">Putting It All Together room</a>.",
        "<b>Full notes + note cards:</b> OSI layers 3/4/7 with one AppSec example each; TCP vs "
        "UDP with one security implication each; the URL request flow; common ports; private IP "
        "ranges; what a firewall, load balancer, and reverse proxy each do.",
    ])
    step("07", "WRITE", "Authentication Writeup + LinkedIn Post \u00b7 Week 7", [
        "Publish 800\u20131,200 word LinkedIn article: \u2018Five ways JWT authentication breaks \u2014 "
        "including the one I found in my own API\u2019",
        "Lead with the finding from your own authentication audit (step 05), then the four remaining "
        "flaws from the PortSwigger JWT labs. If the audit found nothing, use the five lab flaws and "
        "retitle to \u2018Five ways JWT authentication breaks \u2014 and what I look for in code now\u2019",
        "Frame it as a developer who learned to break what they built",
    ])
    step("08", "READ", "“<i>Alice and Bob Learn Application Security</i>” \u00b7 Week 8", [
        "Read “<a href=\"https://www.wiley.com/en-us/Alice+and+Bob+Learn+Application+Security-p-9781119687351\" color=\"#3A7AB8\"><i>Alice and Bob Learn Application Security</i></a>” Ch. 1\u20135 and Ch. 7: security "
        "fundamentals, security requirements, secure design, secure code, and common pitfalls (Ch. 1\u20135), and "
        "what an AppSec program does day-to-day (Ch. 7)",
        "Read during this week \u2014 this is the defender and program-building perspective that "
        "PortSwigger and <i>WAHH</i> do not cover",
        "<b>Key insight:</b> AppSec is not just finding vulnerabilities \u2014 it is building "
        "processes so developers stop introducing them",
        "<b>Full notes + note cards:</b> SDLC security touchpoints, developer security hygiene "
        "checklist, what an AppSec program actually does day-to-day",
    ])
    step("09", "STUDY", "Cryptography Fundamentals \u00b7 Week 8", [
        "Review existing sys design notes on auth and basic security before any new reading. The "
        "goal this week is the AppSec angle: how cryptographic primitives fail, what broken "
        "implementations look like in code, and how to flag them in a security review.",
        "Read the <a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html\" color=\"#3A7AB8\">OWASP Cryptographic Storage Cheat Sheet</a> and the "
        "<a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Security_Cheat_Sheet.html\" color=\"#3A7AB8\">OWASP Transport Layer Security Cheat Sheet</a>. Take notes.",
        "<b>Hands-on:</b> <a href=\"https://www.freecodecamp.org/news/hacking-with-hashcat-a-practical-guide/\" color=\"#3A7AB8\">Crack an MD5 hash with hashcat</a>. "
        "<a href=\"https://pypi.org/project/bcrypt/\" color=\"#3A7AB8\">Implement bcrypt password hashing in Python</a>. "
        "These make the concepts concrete.",
        "<b>Full notes + note cards:</b> One card per algorithm type covered in the cheat sheets. "
        "Front: name and use case. Back: when to use it, what breaks it, what a broken "
        "implementation looks like in code.",
    ])
    SS("Projects & Writings \u2014 Web & Network Foundations")
    add(P("<b>Project: Authentication Audit Checklist</b>", S["bul"]))
    add(P("A 1\u20132 page checklist written from your own notes, run against the Phase 0 FastAPI app, findings recorded in the seven-part format. Pushed to GitHub as Markdown. First real security artifact in the portfolio.", S["bulsm"]))
    add(P("<b>Writing: \u2018Five ways JWT authentication breaks \u2014 including the one I found in my own API\u2019 (800\u20131,200 words)</b>", S["bul"]))
    add(P("LinkedIn article leading with the audit finding, then four flaws from the PortSwigger JWT labs. Framed as a developer who learned to break what they built.", S["bulsm"]))
    add(P("<b>Notes: full notes and note cards</b>", S["bul"]))
    add(P("HTTP security headers, authentication and session attacks, access control, input validation, cryptography, and networking for AppSec \u2014 the Phase II card deck.", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("HTTP security model",
            "Every HTTP header that has security implications, what it does, and what happens when it is misconfigured. The substrate of every web vulnerability. <b>On the job:</b> When reviewing a PR that sets cookies or configures CORS, you check HttpOnly, Secure, SameSite, and Access-Control-Allow-Origin as a reflex.")
    concept("Authentication and session security",
            "How authentication protocols work and how they fail. JWT algorithm confusion is a recurring real-world finding. <b>On the job:</b> JWT configuration is the first thing you check: algorithm whitelisted? Signature verified? Claims validated? Three questions catch the most common JWT vulnerabilities.")
    concept("Access control",
            "IDOR, privilege escalation, horizontal vs. vertical access control flaws. Ranked A01 in the OWASP Top 10:2025. <b>On the job:</b> When reviewing an API endpoint that returns data based on a user-supplied ID, you ask: is the user’s authorization checked against the requested resource, or just their authentication? This question catches most IDOR.")
    concept("API security",
            "REST API-specific vulnerability patterns — broken object-level authorization (IDOR), mass assignment, and excessive data exposure — and why APIs widen the attack surface beyond traditional server-rendered applications.")
    concept("Input validation",
            "The root cause of injection vulnerabilities. Every injection class shares the same root cause: unsanitized user input reaching an interpreter.")
    concept("Cryptography fundamentals",
            "Hashing vs. encryption vs. encoding. Which algorithms are broken (MD5, SHA-1 for passwords, DES, RC4) and which are correct (bcrypt, AES-GCM, RSA). How to identify weak crypto in a code review without being a cryptographer. <b>On the job:</b> When you see a password hash, you check whether it is bcrypt/Argon2 (correct) or MD5/SHA-1 (flag immediately). When you see encrypted data, you check for AES-GCM (correct) vs AES-ECB (flag). When you see a secret, you check whether it is hardcoded or pulled from a secret manager. These are reflex checks that take seconds once the vocabulary is owned.")
    concept("Networking fundamentals for AppSec",
            "OSI layers 3 (Network/IP), 4 (Transport/TCP-UDP), and 7 (Application/HTTP) and why AppSec lives at layer 7. TCP vs UDP and one security implication of each. The steps of a URL request from DNS query to HTTP response. Common ports and the services on them. Private IP ranges (10.x, 172.16\u2013172.31.x, 192.168.x), localhost (127.0.0.1), and the AWS metadata endpoint (169.254.169.254). Standard web app network architecture: internet → firewall → load balancer → app server → database. What a firewall, load balancer, and reverse proxy each do and what security question to ask about each. <b>On the job:</b> When asked ‘where does TLS terminate?’ in an architecture review, you can answer and explain the security implication. When reviewing a deployment configuration, you check for unexpected open ports. When a threat model shows a service making outbound HTTP calls, you ask whether SSRF mitigations are in place and whether private IP ranges are blocked. When a design review describes traffic from an EC2 instance to 169.254.169.254 and asks if it is concerning, the answer is yes — SSRF against the metadata endpoint.")
    concept("Networking as an attack surface",
            "DNS rebinding exploits the gap between DNS validation and the TCP connection, bypassing SSRF protections. SSRF against private IP ranges and the AWS metadata endpoint (169.254.169.254) is a common high-severity finding in cloud-hosted applications. Where TLS terminates in an architecture tells you whether internal traffic is encrypted; HTTP statelessness is why cookies exist and therefore an attack surface; and unexpected open ports in a deployment configuration are a finding. These are the specific networking behaviors AppSec engineers encounter in real work, not networking-engineering concepts.")
    concept("AppSec program thinking (Janca)",
            "AppSec is not just finding bugs — it is building the processes, training, and SDLC integration that stop bugs from being introduced. The developer’s perspective on the defensive side of the role.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE III — CORE VULNERABILITY CLASSES
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("III", "Core Vulnerability Classes", "Weeks 9–15"))
    add(SP(10))
    add(P("Phase III is the technical core of the plan. The OWASP Top 10 is the field’s shared "
          "vocabulary for the most critical web application security risks. Every code review uses "
          "them as a checklist. Every penetration "
          "test methodology is organized around them. This phase goes deep on each class — not "
          "survey knowledge, but genuine understanding of root cause, exploitation mechanics, and "
          "remediation. Complete the labs each step names; expert labs are stretch goals.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("PortSwigger Web Security Academy", "portswigger.net/web-security — Primary lab platform "
        "for this phase. Interactive labs covering every major vulnerability class: injection, XSS, "
        "CSRF, SSRF, XXE, access control, business logic, deserialization, file upload, path "
        "traversal, and API testing.")
    res("OWASP Top 10 (Web)", "owasp.org/projects/top-ten — The ten most critical web "
        "application vulnerabilities, 2025 edition. Each entry includes a description, example attack scenarios, "
        "and prevention guidance.")
    res("OWASP API Security Top 10", "api-security.owasp.org — The API-specific "
        "companion to the web Top 10. Covers BOLA (Broken Object Level Authorization), broken "
        "authentication, BOPLA (Broken Object Property Level Authorization, which merges the older "
        "mass assignment and excessive data exposure categories), BFLA (Broken Function Level "
        "Authorization), and SSRF as they manifest in REST APIs.")
    res("OWASP Testing Guide v4.2", "owasp.org/projects/web-security-testing-guide — The "
        "methodology reference. For each vulnerability class, it describes how to test "
        "systematically.")
    res("“<i>Alice and Bob Learn Application Security</i>”", "Tanya Janca (SheHacksPurple), Wiley, 2020 "
        "(wiley.com) — Ch. 6 (testing and deployment) and Ch. 8 (securing modern applications and "
        "systems: APIs, microservices, serverless) are read in step 06. Ch. 1–5 and 7 were read in Phase II.")
    res("“<i>Hacking APIs</i>”", "Corey Ball, No Starch Press, 2022 (nostarch.com) — REST API security "
        "testing. Ch. 1–3 and Ch. 6–9 cover API reconnaissance, endpoint discovery, and "
        "authentication testing.")
    res("OWASP Top 10 for LLM Applications", "genai.owasp.org/llm-top-10 \u2014 the standard risk list for "
        "LLM-backed apps: prompt injection, improper output handling, excessive agency, and sensitive "
        "information disclosure.")
    res("Semgrep", "semgrep.dev \u00b7 docs.semgrep.dev/writing-rules/overview \u2014 Open-source SAST tool. First "
        "used here to write one rule for the SQL injection pattern exploited in step 01; the full SAST work is in Phase IV.")
    add(SP(4))
    SS("Core Vulnerability Classes — Weeks 9–15")
    step("01", "READ + LABS: Injection Classes", "Weeks 9\u201310", [
        "<b>Buy Burp Suite Professional now</b> (~$499/yr) \u2014 the out-of-band labs in this phase need <a href=\"https://portswigger.net/burp/documentation/desktop/tools/collaborator\" color=\"#3A7AB8\">Burp Collaborator</a>, which is Pro-only. Buying at the start of Phase III lets you do every lab here in place instead of skipping the Collaborator-based ones, and you use Pro continuously from here through the BSCP exam. See <a href=\"https://portswigger.net/burp/pro\" color=\"#3A7AB8\">Burp Suite Professional</a>.",
        "Re-read your Phase II <a href=\"https://portswigger.net/web-security/sql-injection\" color=\"#3A7AB8\">SQL injection</a> notes (the learning path stays linked if you need it), then complete the "
        "practitioner <a href=\"https://portswigger.net/web-security/all-labs#sql-injection\" color=\"#3A7AB8\">labs</a> \u2014 the UNION-based and blind (boolean- and time-based) techniques, plus the out-of-band labs (Burp Collaborator \u2014 you now have Pro)",
        "Work through the PortSwigger <a href=\"https://portswigger.net/web-security/os-command-injection\" color=\"#3A7AB8\">OS command injection</a> and <a href=\"https://portswigger.net/web-security/server-side-template-injection\" color=\"#3A7AB8\">Server-side template injection</a> learning paths, then their labs \u2014 the OS command injection <a href=\"https://portswigger.net/web-security/all-labs#os-command-injection\" color=\"#3A7AB8\">labs</a> (the simple case plus blind time-delay and output-redirection, and out-of-band exfiltration via Collaborator) and the basic SSTI <a href=\"https://portswigger.net/web-security/all-labs#server-side-template-injection\" color=\"#3A7AB8\">labs</a> only (enough to recognize SSTI in review; skip the engine-specific gadget exploitation)",
        "<b>Defense side of the same bug:</b> install the <a href=\"https://semgrep.dev/\" color=\"#3A7AB8\">Semgrep</a> CLI and "
        "<a href=\"https://docs.semgrep.dev/writing-rules/overview\" color=\"#3A7AB8\">write one rule</a> that catches the SQL injection pattern you just "
        "exploited (a string-built query reaching a cursor); run it against your Phase 0 app and a WebGoat source file. This is your first custom rule; "
        "the Phase IV one is the second",
        "<b>For each lab:</b> exploit it, then keep the same notes-only log as the WebGoat step \u2014 the "
        "payload used, what it did, and one line on the root cause. The portfolio writeups for this phase "
        "are the Top 10 series and the SSRF piece in step 02",
    ])
    step("02", "PROJECT: OWASP Top 10 Writeup Series", "Throughout Weeks 9\u201315", [
        "One 800–1,200 word writeup per <a href=\"https://owasp.org/projects/top-ten/\" color=\"#3A7AB8\">OWASP Top 10</a> category, published progressively throughout "
        "this phase",
        "Not academic summaries — each in the standard seven-part report format from Phase I step 04, "
        "plus a real-world example. Use the 2025 edition. For the four categories with lab evidence from Phases II\u2013III "
        "(A01 Broken Access Control, which now includes SSRF, A04 Cryptographic Failures, A05 Injection, "
        "A07 Authentication Failures) the evidence is your lab exploitation; for the six without one "
        "(A02 Security Misconfiguration, A03 Software Supply Chain Failures, A06 Insecure Design, A08 "
        "Software or Data Integrity Failures, A09 Security Logging and Alerting Failures, A10 Mishandling "
        "of Exceptional Conditions) the evidence is a documented real-world case (for example Log4Shell for A03, "
        "the 2021 Codecov breach for A08) and the code-review pattern carries the weight",
        "Write an eleventh, standalone SSRF piece from the step 04 labs in the same format \u2014 SSRF "
        "lost its own Top 10 slot in 2025 but remains a distinct class with its own exploitation "
        "mechanics and defenses",
        "These eleven writeups are the backbone of your AppSec portfolio",
    ])
    step("03", "READ + LABS: Cross-Site Scripting", "Week 11", [
        "Complete the PortSwigger <a href=\"https://portswigger.net/web-security/cross-site-scripting\" color=\"#3A7AB8\">Cross-site scripting</a> learning path, then the <a href=\"https://portswigger.net/web-security/all-labs#cross-site-scripting\" color=\"#3A7AB8\">labs</a> covering reflected, stored, and DOM XSS, the DOM-sink variants, and the exploitation labs (Exploiting cross-site scripting to steal cookies, Exploiting XSS to bypass CSRF defenses); skip the long tail of "
        "near-identical context-encoding and filter-bypass permutations",
        "<b>XSS in React:</b> React’s JSX escaping prevents many reflected XSS vectors by default. The "
        "key exception is <a href=\"https://react.dev/reference/react-dom/components/common\" color=\"#3A7AB8\">dangerouslySetInnerHTML</a>, which bypasses JSX escaping entirely and is a "
        "standard code review finding.",
        "<b>Key:</b> XSS to account takeover chains — cookie theft, CSRF token theft, keylogging",
    ])
    step("04", "READ + LABS: CSRF, SSRF, XXE", "Week 11", [
        "Complete the PortSwigger <a href=\"https://portswigger.net/web-security/csrf\" color=\"#3A7AB8\">CSRF</a>, <a href=\"https://portswigger.net/web-security/ssrf\" color=\"#3A7AB8\">SSRF</a>, and <a href=\"https://portswigger.net/web-security/xxe\" color=\"#3A7AB8\">XXE</a> learning paths, then their labs \u2014 the CSRF <a href=\"https://portswigger.net/web-security/all-labs#cross-site-request-forgery-csrf\" color=\"#3A7AB8\">labs</a> in full (each is a distinct broken-defense pattern), the apprentice and practitioner SSRF <a href=\"https://portswigger.net/web-security/all-labs#server-side-request-forgery-ssrf\" color=\"#3A7AB8\">labs</a> (skip the two expert labs \u2014 Shellshock and the whitelist-filter bypass), and the core XXE <a href=\"https://portswigger.net/web-security/all-labs#xml-external-entity-xxe-injection\" color=\"#3A7AB8\">labs</a> (file retrieval, SSRF, and one blind example \u2014 all apprentice and practitioner)",
        "<b>SSRF:</b> API endpoints that fetch user-supplied URLs are the primary SSRF surface",
        "<a href=\"https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-instance-metadata.html\" color=\"#3A7AB8\">Cloud metadata service</a> attacks (169.254.169.254) are the canonical SSRF exploitation "
        "target",
    ])
    step("05", "READ + LABS: Access Control & Business Logic", "Week 12", [
        "Review your Phase II <a href=\"https://portswigger.net/web-security/access-control\" color=\"#3A7AB8\">Access control</a> notes, then complete the remaining practitioner "
        "<a href=\"https://portswigger.net/web-security/all-labs#access-control-vulnerabilities\" color=\"#3A7AB8\">labs</a> \u2014 the URL-, method-, and Referer-based bypasses and multi-step gaps",
        "Work through the PortSwigger <a href=\"https://portswigger.net/web-security/logic-flaws\" color=\"#3A7AB8\">Business logic vulnerabilities</a> learning path, then its apprentice and practitioner <a href=\"https://portswigger.net/web-security/all-labs#business-logic-vulnerabilities\" color=\"#3A7AB8\">labs</a> \u2014 each is a distinct logic flaw, and this is the class your developer background most directly advantages, so cover it well",
        "Business logic is the vulnerability class automated tools miss entirely — developer "
        "background is the structural advantage here",
    ])
    step("06", "READ + LABS: API Security Deep Dive", "Weeks 12\u201315", [
        "Read the <a href=\"https://api-security.owasp.org/\" color=\"#3A7AB8\">OWASP API Security Top 10</a> in full",
        "Key additions over the web Top 10: BOLA (Broken Object Level Authorization = IDOR for "
        "APIs), BFLA (Broken Function Level Authorization), and BOPLA, the 2023 merge of mass "
        "assignment and excessive data exposure",
        "Read “<a href=\"https://nostarch.com/hacking-apis\" color=\"#3A7AB8\"><i>Hacking APIs</i></a>” Ch. 1–3 (how web applications and APIs work, and the common API "
        "vulnerability classes) and Ch. 6–9 (API discovery and reconnaissance, endpoint analysis, "
        "authentication attacks, and fuzzing)",
        "Read \u201c<a href=\"https://www.wiley.com/en-us/Alice+and+Bob+Learn+Application+Security-p-9781119687351\" color=\"#3A7AB8\"><i>Alice and Bob Learn Application Security</i></a>\u201d Ch. 6 (testing and deployment) and "
        "Ch. 8 (securing modern applications and systems \u2014 APIs, microservices, serverless); the "
        "chapters not covered in Phase II",
        "Review your Phase II <a href=\"https://portswigger.net/web-security/api-testing\" color=\"#3A7AB8\">API testing</a> notes, then complete the remaining "
        "<a href=\"https://portswigger.net/web-security/all-labs#api-testing\" color=\"#3A7AB8\">labs</a>: <a href=\"https://portswigger.net/web-security/api-testing/lab-exploiting-mass-assignment-vulnerability\" color=\"#3A7AB8\">mass assignment</a>, <a href=\"https://portswigger.net/web-security/api-testing/lab-exploiting-unused-api-endpoint\" color=\"#3A7AB8\">the unused endpoint</a>, and both server-side parameter pollution labs (<a href=\"https://portswigger.net/web-security/api-testing/server-side-parameter-pollution/lab-exploiting-server-side-parameter-pollution-in-query-string\" color=\"#3A7AB8\">query string</a>, practitioner; <a href=\"https://portswigger.net/web-security/api-testing/server-side-parameter-pollution/lab-exploiting-server-side-parameter-pollution-in-rest-url\" color=\"#3A7AB8\">REST URL</a>, expert-level)",
        "Work through it treating your own past API work as the mental target: would the APIs "
        "you built have been vulnerable?",
    ])
    step("07", "READ + LABS: Deserialization, File Upload, Path Traversal", "Week 13", [
        "Complete the PortSwigger <a href=\"https://portswigger.net/web-security/deserialization\" color=\"#3A7AB8\">Insecure deserialization</a>, <a href=\"https://portswigger.net/web-security/file-upload\" color=\"#3A7AB8\">File upload</a>, and <a href=\"https://portswigger.net/web-security/file-path-traversal\" color=\"#3A7AB8\">Path traversal</a> learning paths, then their labs \u2014 the deserialization <a href=\"https://portswigger.net/web-security/all-labs#insecure-deserialization\" color=\"#3A7AB8\">labs</a> concept set only (modifying serialized data, using application functionality, one gadget-chain example; skip the extra language-specific gadget chains), the apprentice and practitioner file upload <a href=\"https://portswigger.net/web-security/all-labs#file-upload-vulnerabilities\" color=\"#3A7AB8\">labs</a> in full, including the expert web-shell-via-race-condition lab (solved with the free Turbo Intruder extension), and the path traversal <a href=\"https://portswigger.net/web-security/all-labs#path-traversal\" color=\"#3A7AB8\">labs</a> in full (each is a distinct filter bypass)",
        "Less common than injection and XSS but high-severity in enterprise codebases when present",
    ])
    step("08", "READ + LABS: Web LLM Attacks (PortSwigger)", "Week 15", [
        "<a name=\"p3_llm_attacks\"/>Securing LLM-backed features is a fast-growing AppSec differentiator, and it builds directly on your API background",
        "<a href=\"https://portswigger.net/web-security/llm-attacks\" color=\"#3A7AB8\">Web LLM attacks</a> learning path, then the <a href=\"https://portswigger.net/web-security/all-labs#web-llm-attacks\" color=\"#3A7AB8\">labs</a> \u2014 Exploiting LLM APIs with excessive agency, Exploiting vulnerabilities in LLM APIs, Indirect prompt injection, and Exploiting insecure output handling in LLMs",
    ])
    step("09", "READ: OWASP Top 10 for LLM Applications", "Week 15", [
        "Now that you have exploited the web-facing LLM classes hands-on, read the <a href=\"https://genai.owasp.org/llm-top-10/\" color=\"#3A7AB8\">OWASP Top 10 for LLM Applications</a> straight through as the framework that names and organizes them",
        "Map what you did to the list, in order: prompt injection (LLM01), sensitive information disclosure (LLM02), improper output handling (LLM05), and excessive agency (LLM06) are the classes you attacked; the rest (supply chain, data and model poisoning, system prompt leakage, vector and embedding weaknesses, misinformation, and unbounded consumption) are the broader categories to recognize",
    ])
    SS("Projects & Writings \u2014 Core Vulnerability Classes")
    add(P("<b>Writing: OWASP Top 10 Writeup Series (ten pieces, 800\u20131,200 words each)</b>", S["bul"]))
    add(P("One seven-part writeup per 2025 category, published progressively through the phase; lab evidence for four categories, a documented real-world case for six. The backbone of the portfolio.", S["bulsm"]))
    add(P("<b>Writing: Standalone SSRF writeup</b>", S["bul"]))
    add(P("An eleventh piece in the same format from the SSRF labs \u2014 the class kept its own writeup after leaving the 2025 Top 10.", S["bulsm"]))
    add(P("<b>Notes: injection lab log</b>", S["bul"]))
    add(P("Payload, effect, and root cause for every SQL, OS command, and template injection lab. Practice notes, not portfolio pieces.", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("Injection — complete taxonomy",
            "SQL, command, template, LDAP, NoSQL. Root cause: unsanitized user input reaching an interpreter. Fix: parameterized queries. <b>On the job:</b> Every database query, every shell command, every template render gets the same question: does user input reach this without sanitization? One question catches the whole class.")
    concept("XSS — all three types",
            "Reflected, stored, DOM. Root cause: user input rendered as HTML without encoding. Fix: context-appropriate output encoding. <b>On the job:</b> React escapes JSX output by default, which prevents many reflected XSS vectors. The three things to check in a React code review: dangerouslySetInnerHTML usage (bypasses JSX escaping entirely), third-party component XSS vectors, and any server-rendered template output that feeds into the React tree.")
    concept("CSRF and SSRF",
            "CSRF exploits browser trust. SSRF exploits server trust to reach internal resources. Fix: SameSite cookies for CSRF; URL allowlists for SSRF. <b>On the job:</b> Any endpoint accepting a URL parameter is flagged immediately. Does it fetch that URL server-side? Is the response returned to the user? Is there a URL allowlist? Three questions.")
    concept("Access control flaws",
            "The most common finding in production AppSec work. Fix: verify the authenticated user is authorized for the specific resource on every request.")
    concept("Business logic vulnerabilities",
            "Not detectable by automated tools. Requires understanding intended behavior. The developer background is the advantage. <b>On the job:</b> This is the vulnerability class that threat modeling catches before it ships. STRIDE analysis of a data flow diagram surfaces the business logic assumptions that could be violated.")
    concept("Securing LLM-backed features",
            "The LLM-specific classes — prompt injection, improper output handling, excessive agency, and sensitive information disclosure — sit on top of the classic vulnerabilities you already review, and map onto skills you have: injection is injection, output handling is untrusted-input handling, excessive agency is least privilege. <b>On the job:</b> An increasingly common AppSec task; review an LLM-backed endpoint with the same questions you ask of any endpoint that takes untrusted input and calls tools.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE IV — SECURITY TESTING & TOOLING
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("IV", "Security Testing & Tooling", "Weeks 16–22"))
    add(SP(10))
    add(P("Phase IV moves from knowing vulnerability classes to operating the professional "
          "toolchain used to find them systematically. Burp Suite is the primary tool. SAST "
          "(static analysis of source code, via Semgrep) and DAST (dynamic testing of the running app) are the automation layer. The goal is to reach a level of tool "
          "fluency where tooling becomes leverage, not a learning distraction — you use Burp Suite "
          "to find vulnerabilities faster, not to compensate for not understanding them.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("Burp Suite Documentation", "portswigger.net/burp/documentation — Official documentation "
        "for all Burp Suite tools: <a href=\"https://portswigger.net/burp/documentation/desktop/tools/proxy\" color=\"#3A7AB8\">Proxy</a>, <a href=\"https://portswigger.net/burp/documentation/desktop/tools/repeater\" color=\"#3A7AB8\">Repeater</a>, <a href=\"https://portswigger.net/burp/documentation/desktop/tools/intruder\" color=\"#3A7AB8\">Intruder</a>, <a href=\"https://portswigger.net/burp/documentation/desktop/tools/sequencer\" color=\"#3A7AB8\">Sequencer</a>, and <a href=\"https://portswigger.net/burp/vulnerability-scanner\" color=\"#3A7AB8\">Scanner</a>.")
    res("Semgrep Documentation", "docs.semgrep.dev — Primary for general SAST. A widely used "
        "open-source SAST tool. Sufficient for "
        "the entire plan.")
    res("Bandit Documentation", "bandit.readthedocs.io/en/latest/ — Python-specific SAST tool. Detects "
        "insecure subprocess calls, eval() usage, weak SSL contexts, hardcoded passwords, insecure "
        "pickle and yaml usage.")
    res("GitHub code scanning (CodeQL)", "docs.github.com/en/code-security/code-scanning \u2014 GitHub\u2019s built-in "
        "SAST, powered by CodeQL, enabled per repository with a default setup. Used once in this plan as the second "
        "SAST engine next to Semgrep. <a href=\"https://codeql.github.com/docs/\" color=\"#3A7AB8\">CodeQL query docs</a>.")
    res("DVWA (Damn Vulnerable Web Application)", "github.com/digininja/DVWA \u2014 Deliberately insecure PHP/MariaDB "
        "practice application, run locally via Docker Compose (localhost:4280). The second DAST target "
        "alongside WebGoat; set up in step 04 and scanned with ZAP in step 05.")
    res("ZAP Documentation", "zaproxy.org/docs — the free, open-source DAST tool (formerly an OWASP project): an intercepting proxy plus an automated scanner that crawls a running app and runs active and passive checks for common web vulnerabilities. A free alternative to Burp Scanner, with a baseline scan that wires easily into CI.")
    res("Snyk Documentation", "docs.snyk.io — Software composition analysis (SCA) — finding "
        "vulnerabilities in third-party dependencies. Available with a free tier.")
    res("Syft and CycloneDX", "github.com/anchore/syft \u00b7 cyclonedx.org \u2014 Syft generates a software bill "
        "of materials (SBOM) from an image or source tree; CycloneDX is the SBOM standard it emits. Used once "
        "in this plan, in the Snyk step.")
    res("PortSwigger Web Security Academy", "portswigger.net/web-security — Primary resource for "
        "Burp Suite mastery and BSCP preparation. The Burp Suite learning path and BSCP practice "
        "exams live here. The BSCP exam is practical and hands-on, not multiple-choice: two "
        "applications, three stages each (user account, admin interface, read /home/carlos/secret), in four hours. The "
        "practice exam is one application in two hours, half the real format, and a pass is direct evidence of hands-on web "
        "exploitation skill.")
    res("Phase 0 FastAPI app", "Your own repository — the SAST scan target for Semgrep\u2019s Python "
        "ruleset and Bandit (Bandit is Python-only), and the codebase your custom Semgrep rule "
        "is written against.")
    res("OWASP WebGoat", "github.com/WebGoat/WebGoat — Deliberately insecure Java application. "
        "Used here only as a running DAST target for ZAP.")
    res("OWASP Juice Shop", "owasp.org/projects/juice-shop — Deliberately insecure modern web "
        "application. The primary target for this phase’s full security assessment: Burp Suite "
        "manual testing, ZAP DAST scan, Semgrep SAST, Snyk SCA. Runs via Docker or Node.")
    res("Pwning OWASP Juice Shop", "pwning.owasp-juice.shop \u2014 The official companion guide. Groups every "
        "Juice Shop challenge by vulnerability class and has full solutions in its appendix; the "
        "structure for the Phase IV full assessment.")
    res("TruffleHog", "github.com/trufflesecurity/trufflehog — Secrets scanner that searches full "
        "git history for leaked credentials, including credentials committed and later deleted.")
    res("Gitleaks", "github.com/gitleaks/gitleaks — Lightweight secrets scanner. Runs as a "
        "pre-commit hook and CI gate. Scans the repo history by default; as a pre-commit hook it scans only the staged "
        "diff, fast enough for every PR.")
    add(SP(4))
    SS("Security Testing & Tooling — Weeks 16–22")
    step("01", "LEARN + LABS: Burp Suite Mastery", "Week 16", [
        "Proxy, Repeater, and Intruder are already yours from Phase II \u2014 review those notes; no need to re-read the docs",
        "The two Community-edition tools you haven't used: <a href=\"https://portswigger.net/burp/documentation/desktop/tools/decoder\" color=\"#3A7AB8\">Decoder</a> (encode/decode/hash inline) and <a href=\"https://portswigger.net/burp/documentation/desktop/tools/comparer\" color=\"#3A7AB8\">Comparer</a> (visual diff of two messages)",
        "<b>Decoder:</b> <a href=\"https://portswigger.net/web-security/sql-injection/lab-sql-injection-with-filter-bypass-via-xml-encoding\" color=\"#3A7AB8\">SQL injection with filter bypass via XML encoding</a> (<a href=\"https://portswigger.net/web-security/all-labs#sql-injection\" color=\"#3A7AB8\">SQL injection</a>) \u2014 encode the payload as XML/HTML entities to bypass the WAF",
        "<b>Comparer:</b> <a href=\"https://portswigger.net/web-security/authentication/password-based/lab-username-enumeration-via-different-responses\" color=\"#3A7AB8\">Username enumeration via different responses</a> (<a href=\"https://portswigger.net/web-security/all-labs#authentication\" color=\"#3A7AB8\">Authentication</a>) \u2014 spot the one login response that differs",
        "<b>Both:</b> <a href=\"https://portswigger.net/web-security/sql-injection/blind/lab-conditional-responses\" color=\"#3A7AB8\">Blind SQL injection with conditional responses</a> (<a href=\"https://portswigger.net/web-security/all-labs#sql-injection\" color=\"#3A7AB8\">SQL injection</a>) \u2014 read the admin password one true/false answer at a time",
        "<b>By end of Week 16:</b> fluent with Decoder and Comparer, and comfortable with Proxy match-and-replace and Repeater tab groups",
    ])
    step("02", "LEARN + LABS: Semgrep & Bandit — SAST Tooling", "Week 16", [
        "Semgrep is already installed from Phase III. <a href=\"https://docs.semgrep.dev/getting-started/quickstart-ce\" color=\"#3A7AB8\">Run semgrep scan with its default Registry rules</a> and <a href=\"https://bandit.readthedocs.io/en/latest/\" color=\"#3A7AB8\">Bandit</a> "
        "against your own Phase 0 FastAPI app \u2014 a tool run and a results triage, not code work "
        "on the app",
        "<a href=\"https://docs.semgrep.dev/semgrep-code/findings\" color=\"#3A7AB8\">Triage the results</a>: distinguish true positives from false positives",
        "<a name=\"art_semgrep\"/><a href=\"https://docs.semgrep.dev/writing-rules/overview\" color=\"#3A7AB8\">Write a second custom Semgrep rule</a> targeting a different Python injection pattern — for example, an "
        "endpoint passing request parameters directly to a database query",
        "<a href=\"https://docs.semgrep.dev/semgrep-ci/sample-ci-configs\" color=\"#3A7AB8\">Integrate Semgrep into a GitHub Actions workflow</a> (sample repo is fine)",
        "Enable <a href=\"https://docs.github.com/en/code-security/code-scanning/enabling-code-scanning/configuring-default-setup-for-code-scanning\" color=\"#3A7AB8\">GitHub code scanning (CodeQL default setup)</a> "
        "on the FastAPI repo, let it run once, and read the results next to Semgrep\u2019s: same codebase, two engines, note what each catches "
        "that the other does not. <a href=\"https://codeql.github.com/docs/\" color=\"#3A7AB8\">CodeQL</a>, SonarQube, and Semgrep are the SAST names that recur in "
        "postings; knowing one deeply and one by contact is enough",
        "<a href=\"https://github.com/PyCQA/bandit\" color=\"#3A7AB8\">Bandit</a>: install bandit with pip. <a href=\"https://bandit.readthedocs.io/en/latest/\" color=\"#3A7AB8\">Run against a sample Python project</a> and against "
        "some code in old projects. Look for: B101 (assert usage), B102 (exec usage), "
        "B105/B106/B107 (hardcoded password), B201 (Flask debug mode), B301 (pickle), B501–B504 "
        "(SSL/TLS issues). The finding IDs become vocabulary you use in code review conversations",
        "Run both tools against the same Python codebase and compare results. Bandit catches "
        "Python-specific antipatterns that Semgrep misses without custom rules. Semgrep catches "
        "logic-level patterns that Bandit’s fixed ruleset cannot express. Together with the Gitleaks and Snyk "
        "gates this is a DevSecOps pipeline: every pull request is scanned, and a failing security check blocks the merge.",
    ])
    step("03", "LEARN: Secrets Scanning — TruffleHog & Gitleaks", "Week 16", [
        "Hardcoded secrets (API keys, passwords, tokens committed to repos) are one of the most "
        "common real-world breach vectors. Several well-known breaches began with a credential "
        "committed to a repository",
        "<a href=\"https://github.com/trufflesecurity/trufflehog\" color=\"#3A7AB8\">TruffleHog</a>: install and run against a sample repo. Uses hundreds of credential detectors and verifies "
        "each hit against the issuing service, so results are live secrets rather than regex noise. Can scan full git history, not just current code",
        "<a href=\"https://github.com/gitleaks/gitleaks\" color=\"#3A7AB8\">Gitleaks</a>: install and run as a CI <a href=\"https://pre-commit.com/\" color=\"#3A7AB8\">pre-commit hook</a>. Lightweight and fast, well-suited for "
        "blocking commits before they land",
        "Integrate both into a <a href=\"https://docs.github.com/en/actions\" color=\"#3A7AB8\">GitHub Actions workflow</a>: Gitleaks on every pull request (scanning "
        "only the changed lines), TruffleHog for scheduled full-history scans",
        "<b>In code review:</b> you are now looking for hardcoded strings that look like keys, passwords, "
        "or tokens — in source code, config files, Dockerfiles, and environment variable defaults",
        "<b>Full notes + note cards:</b> When to use TruffleHog vs Gitleaks, what a false positive looks "
        "like, what to do when a live secret is found (rotation procedure, not just deletion)",
    ])
    step("04", "SETUP: DVWA \u2014 Second DAST Target", "Week 16", [
        "<b><a href=\"https://github.com/digininja/DVWA\" color=\"#3A7AB8\">DVWA</a></b> (Damn Vulnerable Web Application) is a second deliberately insecure practice app, written "
        "in PHP \u2014 same purpose as WebGoat, different codebase. Scanning two targets in the next step "
        "shows tooling work across more than one application",
        "Install via Docker Compose from the official repository: <a href=\"https://github.com/digininja/DVWA#docker\" color=\"#3A7AB8\">clone digininja/DVWA</a>, "
        "change into the folder, run <b>docker compose up -d</b>. It serves on "
        "<a href=\"http://localhost:4280\" color=\"#3A7AB8\">http://localhost:4280</a> (not port 80). Give the containers a moment to start",
        "First run: log in with the <a href=\"https://github.com/digininja/DVWA#default-credentials\" color=\"#3A7AB8\">default credentials</a> (admin / password), "
        "open <b>Setup DVWA</b> from the menu and click <a href=\"https://github.com/digininja/DVWA#database-setup\" color=\"#3A7AB8\"><b>Create / Reset Database</b></a>. "
        "Set the security level to <b>Low</b> under DVWA Security so the scanner in the next step has findings to report",
        "Confirm both practice apps are reachable side by side: WebGoat (from Phase 0) and DVWA. "
        "Budget 15\u201330 minutes; the <a href=\"https://github.com/digininja/DVWA#troubleshooting\" color=\"#3A7AB8\">troubleshooting section</a> covers the common start-up errors",
    ])
    step("05", "LEARN: ZAP — DAST Basics", "Week 16", [
        "Run <a href=\"https://www.zaproxy.org/\" color=\"#3A7AB8\">ZAP</a> against both local practice apps \u2014 WebGoat (Phase 0) and DVWA (previous step) \u2014 and compare the two reports",
        "Understand the difference between DAST (testing a running application) and SAST (testing "
        "source code)",
        "<b>Triage ZAP results:</b> true positive, false positive, needs investigation",
    ])
    step("06", "APPLY: Begin Job Applications", "Week 16 onward", [
        "With Phases I\u2013III complete and thirteen published writeups, begin applying now \u2014 do not wait for curriculum completion; applications ramp into the main push at Week 30",
        "Targets, profile, and framing: see \u201c<a href=\"#application_strategy\" color=\"#3A7AB8\">Application Strategy</a>\u201d in Phase VIII",
    ])
    step("07", "DOCUMENT: Save Exam-Ready Proof-of-Concept Exploits", "Throughout Weeks 16–20", [
        "PortSwigger publishes full PoC / solution code for every lab. As you clear each practitioner lab this phase, save its working exploit into one personal, searchable notes file \u2014 the BSCP is open to your own notes (see <a href=\"https://portswigger.net/web-security/certification/how-to-prepare\" color=\"#3A7AB8\">PortSwigger\u2019s prep guidance</a>).",
        "Digital notes are ideal \u2014 the exam is fully open-book (your own notes, the web, third-party tools, and Burp extensions are all allowed) and you sit it in your own browser alongside Burp, so keep everything in one searchable file (Markdown or plain text) or a notes app rather than on paper. Make payloads copy-paste-ready, and pre-load your payload lists and useful extensions into Burp before you start.",
        "Pre-adapt the high-value PoCs for exam conditions: turn XSS print()/alert() payloads into cookie-stealers, parameterize your SQLi and SSRF payloads, and keep Collaborator / OOB templates ready to paste.",
        "Organize them by vulnerability class so you can pull the right template in seconds under exam time pressure",
    ])
    step("08", "LABS: Out-of-Band (OOB) Exploitation with Burp Collaborator", "Week 17", [
        "<b>Requires <a href=\"https://portswigger.net/burp/pro\" color=\"#3A7AB8\">Burp Suite Professional</a></b> \u2014 Burp Collaborator is Pro-only, and nearly every blind / out-of-band variant on the BSCP routes through it. You first used Collaborator in Phase III (Pro from the start); this step is a focused OOB drill to lock in exam fluency \u2014 re-confirm each one fast.",
        "<b>Blind SQL injection:</b> re-read your notes on <a href=\"https://portswigger.net/web-security/sql-injection/blind\" color=\"#3A7AB8\">blind SQL injection</a> (the learning path stays linked), then the out-of-band <a href=\"https://portswigger.net/web-security/all-labs#sql-injection\" color=\"#3A7AB8\">labs</a> \u2014 <i>Blind SQL injection with out-of-band interaction</i> and <i>Blind SQL injection with out-of-band data exfiltration</i> (practitioner)",
        "<b>Blind XXE:</b> re-read your notes on <a href=\"https://portswigger.net/web-security/xxe/blind\" color=\"#3A7AB8\">blind XXE</a> (the learning path stays linked), then the out-of-band <a href=\"https://portswigger.net/web-security/all-labs#xml-external-entity-xxe-injection\" color=\"#3A7AB8\">labs</a> \u2014 <i>Blind XXE with out-of-band interaction</i> and <i>Exploiting blind XXE to exfiltrate data using a malicious external DTD</i>",
        "<b>Blind OS command injection:</b> from the <a href=\"https://portswigger.net/web-security/os-command-injection\" color=\"#3A7AB8\">OS command injection</a> learning path, the out-of-band <a href=\"https://portswigger.net/web-security/all-labs#os-command-injection\" color=\"#3A7AB8\">labs</a> \u2014 <i>Blind OS command injection with out-of-band interaction</i> and <i>... with out-of-band data exfiltration</i>",
        "Carry the same Collaborator technique into blind SSTI detection and any asynchronous sink \u2014 fire a DNS/HTTP callback to confirm the bug, then exfiltrate data through it",
        "<b>For each lab:</b> exploit it, then save the Collaborator payload and working exploit into your exam notes",
    ])
    step("09", "LEARN: Snyk — Dependency Scanning", "Week 17", [
        "Install and authenticate the <a href=\"https://docs.snyk.io/developer-tools/snyk-cli/getting-started-with-the-snyk-cli\" color=\"#3A7AB8\">Snyk CLI</a>, then run <i>snyk test</i> in a sample Python project with known-vulnerable dependencies (for example an outdated requirements.txt) to produce a software-composition report listing each flagged package, its CVE, and the safe upgrade",
        "Understand what SCA (software composition analysis) is and what it does not catch",
        "Log4Shell was a dependency vulnerability, not an application vulnerability — SCA catches "
        "these",
        "Wire <i>snyk test</i> into CI alongside Semgrep and Gitleaks so newly disclosed dependency CVEs fail the build — the remediation is almost always a version bump",
        "Generate an SBOM for the FastAPI app with <a href=\"https://github.com/anchore/syft\" color=\"#3A7AB8\">Syft</a> (<a href=\"https://cyclonedx.org/\" color=\"#3A7AB8\">CycloneDX</a> format) "
        "and feed it to <i>snyk test</i> or Grype; an SBOM is the inventory a supply-chain review starts from",
    ])
    step("10", "PROJECT: Secure a Small LLM-Backed API", "Week 17", [
        "Add one small LLM-backed endpoint to your Phase 0 <a href=\"https://fastapi.tiangolo.com/tutorial/\" color=\"#3A7AB8\">FastAPI</a> app \u2014 a /summarize or "
        "support-reply route that calls a hosted model API (for example the <a href=\"https://platform.claude.com/docs/en/get-started\" color=\"#3A7AB8\">Anthropic</a> or OpenAI "
        "API). This is the flagship AI portfolio piece; it builds directly on your API background",
        "Before attacking it, sketch a one-page <a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Threat_Modeling_Cheat_Sheet.html\" color=\"#3A7AB8\">STRIDE</a> pass on the new endpoint: the trust boundaries between user, model, and any tool the model can call. "
        "A warm-up for the full threat model in Phase VI",
        "Run the same three attack classes you practised in your <a href=\"#p3_llm_attacks\" color=\"#3A7AB8\">Phase III Web LLM Attacks step</a> "
        "against your own endpoint: prompt injection (<a href=\"https://genai.owasp.org/llmrisk/llm01-prompt-injection/\" color=\"#3A7AB8\">LLM01</a>); improper output handling (<a href=\"https://genai.owasp.org/llmrisk/llm052025-improper-output-handling/\" color=\"#3A7AB8\">LLM05</a>) \u2014 show the "
        "XSS or SQL injection that trusting model output enables, then fix it with encoding and "
        "parameterization; and excessive agency (<a href=\"https://genai.owasp.org/llmrisk/llm062025-excessive-agency/\" color=\"#3A7AB8\">LLM06</a>) \u2014 least privilege plus an approval step for any "
        "tool the model can call",
        "Write it up in your standard report format and push it to GitHub; label each finding with its "
        "<a href=\"https://genai.owasp.org/llm-top-10/\" color=\"#3A7AB8\">OWASP LLM Top 10</a> ID (LLM01, LLM05, and so on). One focused \u2018securing an LLM API\u2019 "
        "writeup is a strong, current portfolio piece",
        "Scope: this is securing an LLM <i>application</i>, not machine learning \u2014 stay on the AppSec slice",
    ])
    step("11", "READ + LABS: Remaining BSCP Topics", "Weeks 17\u201318", [
        "<b>Topics the exam can draw from that earlier phases skipped \u2014 close them before sitting the exam.</b> For each: read the learning path, then do the apprentice and practitioner labs.",
        "<a href=\"https://portswigger.net/web-security/request-smuggling\" color=\"#3A7AB8\">HTTP request smuggling</a> learning path, then the <a href=\"https://portswigger.net/web-security/all-labs#http-request-smuggling\" color=\"#3A7AB8\">labs</a> \u2014 <i>basic CL.TE</i> and <i>basic TE.CL</i>, <i>obfuscating the TE header</i>, and <i>Exploiting HTTP request smuggling to capture other users\u2019 requests</i> (a BSCP favorite)",
        "<a href=\"https://portswigger.net/web-security/host-header\" color=\"#3A7AB8\">HTTP Host header attacks</a> learning path, then the <a href=\"https://portswigger.net/web-security/all-labs#http-host-header-attacks\" color=\"#3A7AB8\">labs</a> \u2014 <i>basic password reset poisoning</i>, <i>Host header authentication bypass</i>, <i>web cache poisoning via ambiguous requests</i>, and <i>routing-based SSRF</i>",
        "<a href=\"https://portswigger.net/web-security/web-cache-poisoning\" color=\"#3A7AB8\">Web cache poisoning</a> learning path, then the <a href=\"https://portswigger.net/web-security/all-labs#web-cache-poisoning\" color=\"#3A7AB8\">labs</a> \u2014 <i>unkeyed header</i>, <i>unkeyed cookie</i>, <i>multiple headers</i>, and <i>targeted poisoning using an unknown header</i>",
    ])
    step("12", "LEARN + LABS: Targeted Scanning & Content Discovery", "Week 18", [
        "<b>Requires <a href=\"https://portswigger.net/burp/pro\" color=\"#3A7AB8\">Burp Suite Professional</a></b> (the Scanner and Engagement tools are Pro-only). The exam is time-boxed, so you scan smart, not broad \u2014 this is an explicit BSCP skill.",
        "Read <a href=\"https://portswigger.net/web-security/essential-skills/using-burp-scanner-during-manual-testing\" color=\"#3A7AB8\">using Burp Scanner during manual testing</a>, then the <a href=\"https://portswigger.net/web-security/all-labs#essential-skills\" color=\"#3A7AB8\">labs</a> \u2014 <i>Discovering vulnerabilities quickly with targeted scanning</i> and <i>Scanning non-standard data structures</i>. Right-click a single request \u2192 <i>Do active scan</i> to audit just that request in seconds instead of crawling the whole site.",
        "<b>Content discovery:</b> use Burp\u2019s <a href=\"https://portswigger.net/burp/documentation/desktop/tools/engagement-tools\" color=\"#3A7AB8\">Engagement tools</a> \u2192 <i>Discover content</i> to enumerate hidden directories, files, and parameters (for example a hidden /admin) \u2014 a recurring first move on exam apps. Practice it on labs you have already solved.",
        "<b>Build the habit:</b> hand every new request to the Scanner while you test manually, and run content discovery before assuming an app\u2019s surface is fully mapped",
    ])
    step("13", "DRILL: PortSwigger\u2019s Recommended Reinforcement Labs", "Week 18", [
        "Beyond one practitioner lab per topic, <a href=\"https://portswigger.net/web-security/certification/how-to-prepare\" color=\"#3A7AB8\">PortSwigger recommends 8 specific skill-reinforcement labs</a> before the exam. Make sure each is solid \u2014 several are already covered in earlier steps; this is the consolidated checklist.",
        "<b>XSS:</b> <i>Exploiting cross-site scripting to steal cookies</i> \u2014 from <a href=\"https://portswigger.net/web-security/cross-site-scripting\" color=\"#3A7AB8\">Cross-site scripting</a>, the <a href=\"https://portswigger.net/web-security/all-labs#cross-site-scripting\" color=\"#3A7AB8\">labs</a>; exfiltrate a real session cookie (not just an alert()), which is what the exam rewards (reinforces Phase III step 03)",
        "<b>Authentication:</b> <i>Brute-forcing a stay-logged-in cookie</i> \u2014 from <a href=\"https://portswigger.net/web-security/authentication\" color=\"#3A7AB8\">Authentication</a>, the <a href=\"https://portswigger.net/web-security/all-labs#authentication\" color=\"#3A7AB8\">labs</a>; decode the cookie in Decoder, then brute-force it with Intruder",
        "<b>SSRF:</b> <i>SSRF with blacklist-based input filter</i> \u2014 from <a href=\"https://portswigger.net/web-security/ssrf\" color=\"#3A7AB8\">SSRF</a>, the <a href=\"https://portswigger.net/web-security/all-labs#server-side-request-forgery-ssrf\" color=\"#3A7AB8\">labs</a>; the practitioner filter-bypass variant from Phase III step 04 (<a href=\"https://portswigger.net/web-security/ssrf/lab-ssrf-with-blacklist-filter\" color=\"#3A7AB8\">lab</a>); re-confirm it cold",
        "Already done elsewhere \u2014 re-confirm you can solve each cold: <i>Forced OAuth profile linking</i> (Phase II), <i>Exploiting HTTP request smuggling to capture other users\u2019 requests</i> (step 11), <i>Blind SQL injection with out-of-band data exfiltration</i> (step 08), <i>SQL injection with filter bypass via XML encoding</i> (step 01), and <i>Discovering vulnerabilities quickly with targeted scanning</i> (step 12)",
        "Save the working PoC for each into your exam notes \u2014 you may refer to your own notes during the exam",
    ])
    step("14", "PROJECT: Burp Suite Certified Practitioner Prep", "Weeks 18\u201319", [
        "Requires <a href=\"https://portswigger.net/burp/pro\" color=\"#3A7AB8\">Burp Suite Professional</a> (bought at the start of Phase III); the <a href=\"https://portswigger.net/web-security/certification\" color=\"#3A7AB8\">BSCP exam</a> itself is ~$99 per attempt",
        "Pass the <a href=\"https://portswigger.net/web-security/certification/practice-exam\" color=\"#3A7AB8\">BSCP practice exam</a> in under 2 hours \u2014 and do it more than once \u2014 before booking the real exam. It is one application in two hours, half the real exam, so consistently passing it under time is the strongest signal you are ready",
    ])
    step("15", "DRILL: Fluency \u2014 Re-Solve Cold", "Week 19", [
        "For each major class, take one practitioner lab you have already solved and re-solve it cold \u2014 no notes, no solution \u2014 in 15 minutes or less.",
        "Work through roughly 20 labs this way (about one per class). If a lab runs past 15 minutes or you reach for your notes, that class is not yet exam-fluent \u2014 drill it again.",
        "This is the gap between having seen a vulnerability and being able to exploit it under time pressure with no hints \u2014 which is exactly what the exam tests",
    ])
    step("16", "DRILL: Mystery Labs \u2014 Cold Recognition", "Week 19", [
        "The exam gives you no vulnerability hints \u2014 you must recognize the class from behavior alone. The <a href=\"https://portswigger.net/web-security/mystery-lab-challenge\" color=\"#3A7AB8\">mystery lab challenge</a> spins up a random lab with its title and description hidden, the closest practice for that.",
        "Solve at least 5 mystery labs cold \u2014 no hints, working only from recon \u2014 before booking the exam. Time each one; the goal is fast, confident classification.",
        "If a class keeps stumping you, go back to that topic\u2019s labs and notes, then return to the mystery challenge",
    ])
    step("17", "DRILL: Exam Stamina \u2014 Six Labs in One Block", "Week 19", [
        "<a href=\"https://portswigger.net/web-security/certification/exam-hints-and-guidance\" color=\"#3A7AB8\">The real exam</a> is a single continuous 4-hour session \u2014 two applications, three stages each, and a pass needs every stage. Rehearse that endurance before you book it.",
        "Take six practitioner labs you have not memorized and solve them back-to-back in one timed 4-hour block \u2014 own notes only, Burp Pro, Collaborator live, no long breaks.",
        "Track time per lab and practice triage: if one runs past budget, bank partial progress, move on, and circle back \u2014 the time management is as much the test as the exploitation",
    ])
    step("18", "PROJECT: Full Security Assessment of Juice Shop", "Weeks 19\u201321", [
        "<a name=\"art_juiceshop\"/>Conduct a full security assessment of <a href=\"https://owasp.org/projects/juice-shop/\" color=\"#3A7AB8\">OWASP Juice Shop</a> using: Burp Suite (manual), ZAP "
        "(DAST), Semgrep with its JavaScript/TypeScript rulesets (SAST), Snyk (dependencies), TruffleHog/Gitleaks (secrets)",
        "Work through it systematically using the official companion guide <a href=\"https://pwning.owasp-juice.shop\" color=\"#3A7AB8\">Pwning OWASP Juice Shop</a>, which groups every challenge by vulnerability class \u2014 injection, broken authentication, XSS, broken access control, and more \u2014 so you can map each finding to an OWASP category; its appendix has full step-by-step solutions if you get stuck",
        "Reuse the systematic methodology and the seven-part report format from Phase I step 04, as used in your Phase III vulnerability-class writeups \u2014 this project is where the full workflow comes together: recon, tooling, manual exploitation, false-positive triage, and professional reporting",
        "Produce a written vulnerability report: executive summary, findings table (vuln, "
        "severity, CVSS, evidence, recommendation), detailed finding writeups",
        "Export the finished report as a polished, shareable standalone PDF \u2014 the document "
        "you can share with anyone who asks what your assessment work looks like",
        "This is the most important portfolio artifact in the plan — it demonstrates the complete "
        "AppSec workflow from tool setup to professional reporting",
    ])
    step("19", "EXAM: Burp Suite Certified Practitioner", "Weeks 20–22", [
        "Take the <a href=\"https://portswigger.net/web-security/certification\" color=\"#3A7AB8\">BSCP exam</a>. The exam consists of two applications, each completed in three "
        "stages: access a user account, reach the admin interface, read /home/carlos/secret. 4 hours.",
        "If unsuccessful on the first attempt, review the topics where the attempt failed and "
        "retake. PortSwigger sets no limit on attempts (each attempt costs $99).",
    ])
    SS("Projects & Writings \u2014 Security Testing & Tooling")
    add(P("<b>Project: Full Security Assessment of OWASP Juice Shop</b>", S["bul"]))
    add(P("Burp manual testing, ZAP, Semgrep, Snyk, and secrets scanning against one target, written up as a professional vulnerability report (executive summary, findings table, detailed findings) and exported as a standalone PDF. The most important artifact in the plan.", S["bulsm"]))
    add(P("<b>Project: Secure a Small LLM-Backed API</b>", S["bul"]))
    add(P("An LLM-backed endpoint added to the Phase 0 FastAPI app, attacked for prompt injection, improper output handling, and excessive agency, then fixed; writeup labelled with OWASP LLM Top 10 IDs.", S["bulsm"]))
    add(P("<b>Project: Custom Semgrep rule and CI security workflow</b>", S["bul"]))
    add(P("One custom Semgrep rule for a Python injection pattern, plus a GitHub Actions workflow running Semgrep, Gitleaks, TruffleHog, and Snyk.", S["bulsm"]))
    add(P("<b>Notes: exam proof-of-concept file</b>", S["bul"]))
    add(P("Every working practitioner-lab exploit, organised by vulnerability class and copy-paste-ready for the open-book BSCP exam.", S["bulsm"]))
    add(P("<b>Certification: Burp Suite Certified Practitioner</b>", S["bul"]))
    add(P("Passed exam; the credential that proves hands-on web-exploitation skill.", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("Burp Suite as an extension of manual thinking",
            "Burp Suite intercepts and replays HTTP traffic. It does not find vulnerabilities — it makes manual exploitation efficient. Understanding of what to look for drives the tool, not the reverse. <b>On the job:</b> Nearly every web pentest engagement runs through Burp Suite or an equivalent proxy. Every time you need to understand what a web application is actually sending and receiving, it is open. The AppSec engineer’s equivalent of a developer’s debugger.")
    concept("SAST vs. DAST vs. SCA vs. Secrets Scanning",
            "Four distinct scanning approaches that catch different vulnerability classes. SAST reads code, misses runtime behavior. DAST tests a running app, misses code paths not exercised. SCA finds known CVEs in dependencies. Secrets scanning finds exposed credentials in code and history. A real AppSec program uses all four — plus Python-specific tools like Bandit for Python shops. <b>On the job:</b> Integrating Semgrep into a company’s CI/CD pipeline, writing rules for company-specific vulnerability patterns, and triaging results is a common AppSec responsibility. The custom rule you built is the portfolio demonstration.")
    concept("False positive triage",
            "Automated tools have noise. Distinguishing real findings from false positives without dismissing everything is where security judgment matters more than tool knowledge.")
    concept("Professional vulnerability reporting",
            "Severity rating (CVSS), evidence documentation, clear remediation guidance. The output of AppSec work is a finding that a developer can act on — not just a list of things that are broken. <b>On the job:</b> Every engagement produces a report. The format you learned in the Juice Shop assessment is the format used in production. Clear findings, actionable remediations, evidence-backed.")
    concept("Secrets management",
            "Hardcoded credentials are a separate vulnerability class from application logic flaws. The fix is not deletion from current code — it is rotation of the exposed credential plus integration of a secret manager (HashiCorp Vault, AWS Secrets Manager) and pre-commit scanning to prevent recurrence. <b>On the job:</b> Gitleaks runs as a pre-commit hook and a CI gate. TruffleHog runs on a schedule against full git history. When a developer accidentally commits an API key, you have a runbook: alert the developer, rotate the credential immediately (assume it is already compromised), add the pattern to the blocklist. This is day-one operational work at many companies.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE V — CLOUD SECURITY FUNDAMENTALS
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("V", "Cloud Security Fundamentals", "Week 23"))
    add(SP(10))
    add(P("Modern AppSec work happens in the cloud. S3 misconfiguration and IAM over-permissioning "
          "are among the most frequently reported cloud misconfigurations, and "
          "credible threat modeling requires understanding the cloud attack surface an application "
          "runs on. This phase covers the AppSec-relevant subset — not Terraform or multi-cloud "
          "architecture, but enough to identify misconfigurations in code and architecture "
          "reviews, understand SSRF chains that target cloud metadata, and discuss findings with "
          "infrastructure teams.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("AWS Security CTF: Attacker Path", "flaws.cloud — Six levels covering real-world AWS "
        "misconfigurations: S3 bucket exposure, credential leakage, IAM misuse, and SSRF via the "
        "EC2 metadata service. Each level explains the vulnerability and its fix.")
    res("AWS Security CTF: Attacker & Defender", "flaws2.cloud — Companion to flaws.cloud with two "
        "separate paths: attacker path (exploit misconfigurations in Lambda and ECS Fargate) and defender path "
        "(incident response on the same app: analyze the attack logs with jq and Athena).")
    res("AWS Shared Responsibility Model", "aws.amazon.com/compliance/shared-responsibility-model "
        "— Official AWS documentation. Defines what AWS secures (infrastructure) versus what the "
        "customer secures (IAM, S3 policies, application code, data encryption).")
    res("AWS IAM Documentation", "docs.aws.amazon.com/iam/ — Official AWS documentation. The IAM "
        "concepts section covers users, roles, groups, policies, and the principle of least "
        "privilege.")
    res("FreeCodeCamp Cloud Security Fundamentals in AWS", "freecodecamp.org — Beginner-friendly "
        "guide covering IAM users and policies, S3 bucket configurations, MFA, and the AWS Shared "
        "Responsibility Model with hands-on examples.")
    res("Trivy", "trivy.dev/latest/docs \u2014 Open-source scanner for container images: known "
        "vulnerabilities in OS and language packages, Dockerfile misconfigurations, and secrets baked "
        "into layers. Used to scan the Phase 0 FastAPI image.")
    res("OWASP Docker Security Cheat Sheet", "cheatsheetseries.owasp.org/cheatsheets/"
        "Docker_Security_Cheat_Sheet.html \u2014 The hardening checklist for images and containers: "
        "non-root users, pinned base images, capability drops, secrets handling, read-only filesystems.")
    res("OWASP Kubernetes Security Cheat Sheet", "cheatsheetseries.owasp.org/cheatsheets/"
        "Kubernetes_Security_Cheat_Sheet.html \u2014 Read once for the vocabulary (pods, RBAC, network "
        "policies); no cluster work in this plan.")
    add(SP(4))
    SS("Cloud Security Fundamentals — Week 23")
    step("01", "READ: AWS Foundations: Shared Responsibility & IAM", "Week 23", [
        "Read the <a href=\"https://aws.amazon.com/compliance/shared-responsibility-model/\" color=\"#3A7AB8\">AWS Shared Responsibility Model</a> page completely. Write a one-paragraph summary "
        "in your own words: what AWS is responsible for, what you are responsible for, and what "
        "the boundary looks like for a web application running on EC2 behind an S3 bucket",
        "Read the IAM concepts in the <a href=\"https://docs.aws.amazon.com/IAM/latest/UserGuide/\" color=\"#3A7AB8\">AWS IAM documentation</a>: what a user is, what a role is, what "
        "a policy is, how they attach, what least privilege means in practice",
        "Read the <a href=\"https://www.freecodecamp.org/news/learn-cloud-security-fundamentals-in-aws-a-guide-for-beginners/\" color=\"#3A7AB8\">FreeCodeCamp Cloud Security Fundamentals in AWS</a> guide — beginner-friendly, "
        "hands-on, covers IAM and S3 configuration with real console examples",
        "<b>Full notes + note cards:</b> AWS Shared Responsibility boundary; IAM user vs. role vs. group; "
        "what a policy document looks like (JSON structure, Effect/Action/Resource); what least "
        "privilege means and why wildcard permissions (s3:*) are a finding",
    ])
    step("02", "LABS: flaws.cloud — Levels 1–6", "Week 23", [
        "Create a free AWS account if you do not have one. The CTF runs against real AWS "
        "infrastructure — you need the <a href=\"https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-getting-started.html\" color=\"#3A7AB8\">AWS CLI installed and configured</a> with a free-tier account",
        "<a href=\"http://flaws.cloud\" color=\"#3A7AB8\">Complete all six levels</a>. Exploit each level fully before reading the solution",
        "<b>After all six levels:</b> one combined writeup in the standard seven-part report format from "
        "Phase I step 04, one finding per level; the code-review pattern becomes a configuration-review "
        "checklist (IAM policies, bucket policies, instance metadata settings)",
    ])
    step("03", "LABS: flaws2.cloud — Attacker & Defender Paths", "Week 23", [
        "<b>Two distinct paths:</b> attacker (exploit serverless and container misconfigurations) and defender "
        "(investigate the same attack from the logs).",
        "<a href=\"http://flaws2.cloud\" color=\"#3A7AB8\">Complete both paths</a>. The defender path is the AppSec-relevant half — it teaches you to read what "
        "an attack left behind in the logs, which is how a finding is confirmed on the job",
        "<b>Key concepts reinforced:</b> IAM role scoping for Lambda and ECS tasks, container metadata "
        "credential exposure, and log analysis with CloudTrail, jq, and Athena",
    ])
    step("04", "LEARN + PRACTICE: Container Security Basics", "Week 23", [
        "Read the <a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Docker_Security_Cheat_Sheet.html\" color=\"#3A7AB8\">OWASP Docker Security Cheat Sheet</a>, "
        "then scan the image of your Phase 0 FastAPI app with <a href=\"https://trivy.dev/latest/docs/\" color=\"#3A7AB8\">Trivy</a> "
        "(image vulnerabilities, misconfigurations, exposed secrets) and triage the findings the same way as the SAST results in Phase IV",
        "Fix one finding in the Dockerfile (pin the base image, drop a capability, or confirm the non-root user) and rebuild; "
        "keep the before/after scan output in the notes repo",
        "Skim the <a href=\"https://cheatsheetseries.owasp.org/cheatsheets/Kubernetes_Security_Cheat_Sheet.html\" color=\"#3A7AB8\">OWASP Kubernetes Security Cheat Sheet</a> "
        "once for the vocabulary (pods, RBAC, network policies); no cluster work in this plan",
        "<b>Full notes + note cards:</b> image scanning vs runtime security; least privilege in containers; where secrets must not live "
        "(image layers, environment defaults); IMDS access from a container",
    ])
    SS("Projects & Writings \u2014 Cloud Security Fundamentals")
    add(P("<b>Writing: flaws.cloud assessment writeup</b>", S["bul"]))
    add(P("One combined seven-part writeup covering all six levels, one finding per level, with a configuration-review checklist for IAM policies, bucket policies, and instance metadata settings.", S["bulsm"]))
    add(P("<b>Notes: AWS security note cards</b>", S["bul"]))
    add(P("Shared responsibility boundary, IAM users vs roles vs policies, S3 public-access controls, IMDSv2, and the flaws2 defender-path log analysis.", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("AWS Shared Responsibility Model",
            "AWS secures the physical infrastructure. You secure what runs on it: IAM configurations, S3 policies, application code, data encryption. Misunderstanding this boundary is the root cause of many cloud breaches.")
    concept("IAM — Identity and Access Management",
            "Users, roles, groups, and policies. A role is what an AWS service or EC2 instance assumes to perform actions. A policy is a JSON document defining what actions are allowed or denied on which resources. Least privilege means a role should have exactly the permissions it needs and nothing more. Over-permissioned roles are the most common IAM finding. <b>On the job:</b> When a team presents a new service design, you ask: what IAM role does this service run as? What permissions does that role have? Could an attacker compromise this service and use its IAM role to access something they should not? Reading an IAM policy JSON, an S3 bucket policy, or a Lambda configuration and spotting the problem is the AppSec-specific cloud skill: auditing infrastructure, not writing it.")
    concept("S3 bucket misconfiguration",
            "S3 buckets store data. Public read access means anyone on the internet can read the contents. Authenticated AWS user access means any AWS account holder worldwide can read it. Both are common misconfigurations. Bucket policies, ACLs, and Block Public Access settings all interact — understanding which one controls what is the skill. <b>On the job:</b> When reviewing a deployment configuration or an IaC pull request, you check: is Block Public Access enabled at the bucket level? Are there wildcard permissions? Are access logs enabled on buckets containing sensitive data? These are 5-minute checks that catch high-severity findings.")
    concept("EC2 instance metadata service (IMDS)",
            "169.254.169.254 is accessible from within an EC2 instance and returns IAM credentials, instance ID, and configuration. SSRF against this endpoint gives an attacker the instance’s IAM credentials. IMDSv2 requires a token header that prevents simple SSRF exploitation. Whether IMDSv2 is enforced is a standard AppSec checklist item. <b>On the job:</b> When you see an endpoint that accepts a URL and fetches it server-side, your first question is now: can this reach 169.254.169.254? Is IMDSv2 enforced on the EC2 instances this service runs on? Is there a URL allowlist? flaws.cloud Level 5 is the exact attack chain you are looking for.")
    concept("Credential exposure in git history",
            "AWS keys committed to a git repository — even if deleted in a later commit — are permanently visible in history. TruffleHog scans history. The fix is to rotate the exposed credential, not just delete it from current code, plus pre-commit scanning to prevent recurrence. <b>On the job:</b> When reviewing any code that configures AWS clients, check: are credentials hardcoded? Are they pulled from environment variables (better but still risky) or from a secrets manager or IAM role (correct)?")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE VI — SECURE CODE REVIEW & THREAT MODELING
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("VI", "Secure Code Review & Threat Modeling", "Weeks 24–26"))
    add(SP(10))
    add(P("Phase VI builds the two highest-leverage AppSec skills — the ones that appear earliest "
          "in a job. Secure code review is the daily work "
          "of most AppSec engineers at software companies. Threat modeling is how AppSec influence "
          "scales beyond individual code reviews to affect system design. The developer "
          "perspective that threat modeling requires — understanding how systems are built and "
          "where trust boundaries exist — is built through the pre-study and Phases I–IV before "
          "this phase begins. OWASP ASVS is introduced here as the verification standard that "
          "gives code review a systematic checklist — turning ad-hoc review into structured, "
          "repeatable methodology.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("OWASP Code Review Guide v2.0", "owasp.org/projects/code-review-guide — The <a href=\"https://raw.githubusercontent.com/OWASP/www-project-code-review-guide/master/assets/OWASP_Code_Review_Guide_v2.pdf\" color=\"#3A7AB8\">methodology "
        "reference</a> for secure code review.")
    res("OWASP Application Security Verification Standard (ASVS) v5.0.0",
        "owasp.org/projects/asvs — Approximately 350 "
        "testable security requirements across 17 chapters covering authentication, access "
        "control, input validation, cryptography, API security, and configuration. Level 1 is "
        "the first layer of defense; Level 2 covers standard security practice.")
    res("“<i>Threat Modeling: Designing for Security</i>”", "Adam Shostack, Wiley, 2014 (wiley.com) — The "
        "standard text on threat modeling. Ch. 1–3 cover a first threat model, data flow diagrams, "
        "and STRIDE; Ch. 4–5 cover attack trees and attack libraries.")
    res("GitHub Security Lab", "securitylab.github.com — Published CVE research on real "
        "open-source projects. Covers vulnerability discovery, exploitation mechanics, and "
        "coordinated disclosure.")
    res("OWASP Threat Dragon", "owasp.org/projects/threat-dragon — Threat modeling tool. Used "
        "for the threat modeling project in this phase.")
    add(SP(4))
    SS("Secure Code Review & Threat Modeling — Weeks 24–26")
    step("01", "READ + PRACTICE: Secure Code Review Methodology", "Weeks 24\u201325", [
        "Read the <a href=\"https://raw.githubusercontent.com/OWASP/www-project-code-review-guide/master/assets/OWASP_Code_Review_Guide_v2.pdf\" color=\"#3A7AB8\">OWASP Code Review Guide, Introduction through Reviewing by Vulnerability</a> (methodology, code review techniques, "
        "vulnerability-specific review guidance)",
        "Conduct a scoped code review of a real open-source Python web application (Django, Flask, or FastAPI) from GitHub — not "
        "WebGoat, but a real project at real scale. Scope it to one subsystem, for example authentication and session "
        "handling, roughly 2,000 lines, and budget about 8 hours",
        "<b>Apply the systematic methodology:</b> trace user input, verify authentication, check "
        "authorization, audit crypto, check dependencies",
    ])
    step("02", "READ + PROJECT: Threat Modeling", "Weeks 24–26", [
        "<a name=\"art_threatmodel\"/>Read “<a href=\"https://www.wiley.com/en-us/Threat+Modeling%3A+Designing+for+Security-p-9781118809990\" color=\"#3A7AB8\"><i>Threat Modeling: Designing for Security</i></a>” Ch. 1–5",
        "Build a complete threat model for the API built during pre-study, including the LLM endpoint "
        "added in Phase IV. A system built from scratch end-to-end is the right target: every layer "
        "is known, every trust boundary can be reasoned about.",
        "Use <a href=\"https://owasp.org/projects/threat-dragon/\" color=\"#3A7AB8\">OWASP Threat Dragon</a> for the data flow diagram. Apply STRIDE to each component",
        "<b>Produce a threat model document:</b> DFD, trust boundaries, threat enumeration, risk rating, "
        "mitigations",
    ])
    step("03", "STUDY: OWASP ASVS — Verification Standard", "Week 26", [
        "Read the <a href=\"https://raw.githubusercontent.com/OWASP/ASVS/v5.0.0/5.0/OWASP_Application_Security_Verification_Standard_5.0.0_en.pdf\" color=\"#3A7AB8\">ASVS v5.0.0 Level 1 and Level 2 requirements</a>. Do not try to memorize — learn the "
        "structure and the categories",
        "Map each ASVS chapter to the vulnerability classes studied in this plan — input validation and output encoding, authentication, access control, and cryptography each get their own chapter, so you can pin any finding to a specific numbered requirement",
        "Build a lightweight personal ASVS checklist: 20–30 of the highest-signal Level 2 "
        "requirements you would check first in any code review",
        "This checklist becomes a portfolio artifact: a reusable, standards-backed review tool",
    ])
    step("04", "PRACTICE: Code Review Under Time Pressure", "Week 26", [
        "Real code review is time-boxed — a PR waits on you; interview exercises use the same 30–45 minute format",
        "Use <a href=\"https://securitylab.github.com/\" color=\"#3A7AB8\">GitHub Security Lab</a>’s published CVE <a href=\"https://securitylab.github.com/advisories/\" color=\"#3A7AB8\">writeups</a> as answer keys: read the vulnerable code "
        "before the writeup, try to identify the vulnerability, then compare",
        "Do five of these across different vulnerability classes",
        "<b>Target:</b> 30 minutes from cold code to written vulnerability identification",
    ])
    SS("Projects & Writings — Secure Code Review & Threat Modeling")
    add(P("<b>Project: Open-Source Code Review</b>", S["bul"]))
    add(P("Documented security review of a real open-source Python application. Findings in "
          "standard format, pushed to GitHub. Includes scope, methodology, findings, and "
          "remediation recommendations.", S["bulsm"]))
    add(P("<b>Project: Threat Model Document</b>", S["bul"]))
    add(P("Full STRIDE threat model of a system built end-to-end in this plan. DFD, trust boundaries, "
          "threat enumeration, risk ratings, mitigations. Pushed to GitHub. An unusual portfolio "
          "artifact that shows design-time security thinking, not only exploitation. The target is your Phase 0 FastAPI app including the LLM endpoint added in Phase IV, so STRIDE has to cover prompt injection and output handling as well as the classic web threats.", S["bulsm"]))
    add(P("<b>Checklist: Personal ASVS Review Checklist</b>", S["bul"]))
    add(P("20–30 of the highest-signal ASVS Level 2 requirements, ordered as you would check them in a code review. Pushed to GitHub as Markdown; a reusable, standards-backed review tool.", S["bulsm"]))
    add(P("<b>Writing: ‘Threat Modeling the Billing System I Built’ (1,000–1,500 words)</b>",
          S["bul"]))
    add(P("Use your ActiveCampaign billing microservice as the subject. Walk through what a threat "
          "model of that system would have looked like, what STRIDE would have identified, and how "
          "the architecture would have been different had AppSec been involved in the design. The "
          "most personal piece in the portfolio: a threat model of a system you actually built.",
          S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("Secure code review as methodology",
            "Not reading code and hoping to notice something bad — systematic input tracing, authentication verification, authorization checking, cryptography auditing. Replicable and teachable. <b>On the job:</b> When a developer asks you to review a PR, you apply the methodology: trace inputs, check auth, check authz, check crypto, check dependencies. Faster and repeatable when systematic.")
    concept("OWASP ASVS as a verification framework",
            "~350 testable security requirements organized by domain. Level 1 is the first layer of defense against common attacks. Level 2 is a comprehensive view of standard security practice. Using ASVS during code review means you can say ‘this fails ASVS V2.1.1’ rather than ‘this seems wrong’ — a finding a developer can look up and act on.")
    concept("STRIDE threat modeling",
            "Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege. A threat category for every component of a data flow diagram. <b>On the job:</b> When a team presents a new microservice design, you build a DFD on the whiteboard, identify trust boundaries, and run STRIDE. One threat model at design time can prevent many vulnerability findings after code is written.")
    concept("Trust boundaries",
            "The lines in a DFD where data crosses from less-trusted to more-trusted context. Every trust boundary is a potential vulnerability surface.")
    concept("Time-pressured code review",
            "Cold code, 30–45 minutes, a written or spoken identification of the flaw. The same format as a PR review under deadline and as the AppSec interview exercise; practice makes both feel routine.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE VII — COMPTIA SECURITY+
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("VII", "CompTIA Security+ Certification", "Weeks 27–30"))
    add(SP(10))
    add(P("CompTIA Security+ is a baseline credential. It is required or preferred "
          "as required or preferred in many AppSec job postings, especially at enterprise companies and in "
          "regulated industries. It confirms broad security literacy; the portfolio demonstrates "
          "hands-on AppSec skill. It is achievable in 3–4 weeks with the foundational knowledge "
          "built throughout this plan.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("“<i>CompTIA Security+ Get Certified Get Ahead: SY0-701 Study Guide</i>”", "Joe Shelley and Darril "
        "Gibson, Certification Experts LLC, 2023 (getcertifiedgetahead.com) — Covers "
        "all SY0-701 exam objectives across eleven chapters with real-world examples and "
        "exam topic review sections.")
    res("Professor Messer Practice Exams", "professormesser.com — Paid practice exams for the "
        "Security+ SY0-701 exam. Same format and structure as the actual exam.")
    add(SP(4))
    SS("CompTIA Security+ Certification — Weeks 27–30")
    step("01", "READ + MEMORIZE: Study Guide", "Weeks 27–30", [
        "Read “<a href=\"https://www.getcertifiedgetahead.com/\" color=\"#3A7AB8\"><i>CompTIA Security+ Get Certified Get Ahead: SY0-701 Study Guide</i></a>” cover to cover. The "
        "exam has five domains: General Security Concepts, Threats/Vulnerabilities/Mitigations, "
        "Security Architecture, Security Operations, and Security Program Management & Oversight",
        "Most technical content from the first three domains will be review from earlier phases. "
        "Focus study time on governance, compliance, and program management domains — these are "
        "the least familiar material",
        "<b>Full notes, then granular cards:</b> label and study note cards in book order \u2014 one card per concept (title on the front, 1\u20135 bullets on the back), roughly 160\u2013200 cards, with extra cards where a topic is dense. Prioritize the high-yield memorization sets: ports and protocols, cryptography and PKI, attack types, security control types, and the governance, compliance, and framework material (your least-familiar domain)",
        "<b>Memorize (grouped spaced review):</b> memorize cards in groups of seven with full front-to-back recall, fold each group into a growing cumulative review pile, and re-drill the whole pile each time you add a new memorized 7 card group to it (pruning only over-learned cards). Budget real time \u2014 at ~180 cards this is a multi-day make-and-memorize effort, not an afterthought",
    ])
    step("02", "PRACTICE: Practice Exams", "Weeks 29\u201330", [
        "Take a full <a href=\"https://www.professormesser.com/sy0-701-certification-course/\" color=\"#3A7AB8\">Professor Messer</a> practice exam cold. Score it and identify weak domains",
        "Study weak domains specifically from the study guide via note cards and additional learning, if required. Retake. Repeat until score 85\u201390% over 2\u20133 practice exams in a row",
    ])
    step("03", "EXAM: CompTIA Security+ SY0-701", "Week 30", [
        "<b>Delivery:</b> schedule through Pearson VUE and take it in person at a <a href=\"https://www.pearsonvue.com/us/en/comptia.html\" color=\"#3A7AB8\">Philadelphia test center</a> (nearest: Temple University, North Broad Street) \u2014 about $439 (2026), valid for three years",
        "<b>Scheduling:</b> book the soonest available seat once you are consistently at 85\u201390% on practice exams \u2014 do not delay and let fresh memorization fade; specific dates fill, so reserve the nearest one the moment you hit target",
        "<b>Retakes:</b> no cap \u2014 no wait for the first retake, then a 14-day wait after any further fail, full price each; once you pass you cannot retake the same exam code without CompTIA’s consent",
    ])
    step("04", "APPLY: Main Application Push", "Week 30 onward", [
        "With Security+ now on your resume, intensify the application push that began in Phase IV "
        "\u2014 widen to more startups and AppSec-adjacent roles",
        "<b>Daily target:</b> 1\u20132 applications a day, each with a cover letter tailored to the specific role, the resume tailored as needed, and both checked against an ATS scanner \u2014 budget roughly 1\u20132 hours per application for that personalization",
        "See \u201c<a href=\"#application_strategy\" color=\"#3A7AB8\">Application Strategy</a>\u201d in Phase VIII for the full targeting, profile, and framing playbook",
    ])
    SS("Projects & Writings \u2014 CompTIA Security+ Certification")
    add(P("<b>Certification: CompTIA Security+ (SY0-701)</b>", S["bul"]))
    add(P("Passed exam, valid for three years; the vendor-neutral baseline that confirms shared "
          "vocabulary with SOC, infrastructure, and GRC colleagues before AppSec-specific work begins.", S["bulsm"]))
    add(P("<b>Notes: Security+ note-card deck</b>", S["bul"]))
    add(P("One card per concept in book order, memorized in grouped spaced review; reused in Phase VIII "
          "for interview drilling.", S["bulsm"]))
    add(SP(4))
    SS("Concepts and Their Use on the Job")
    concept("Security+ exam domains",
            "All five SY0-701 domains: General Security Concepts, Threats/Vulnerabilities/Mitigations, Security Architecture, Security Operations, Security Program Management & Oversight. <b>On the job:</b> Security+ signals baseline security literacy to enterprise companies and regulated industries, where it is a common requirement. The portfolio carries the hands-on evidence.")
    concept("Governance and compliance",
            "Risk management frameworks, regulatory compliance (HIPAA, PCI-DSS, SOC 2), security policy and procedure, security awareness training. <b>On the job:</b> AppSec engineers work with compliance teams. Knowing what PCI-DSS requires for web applications, what HIPAA means for data handling, and how risk frameworks are structured makes cross-team conversations productive.")
    concept("Cryptography fundamentals",
            "Symmetric and asymmetric encryption, hashing algorithms, PKI, certificate lifecycle, TLS/SSL configuration.")
    concept("Network security",
            "Firewalls, IDS/IPS, VPN, network segmentation, wireless security.")
    concept("Identity and access management",
            "Authentication protocols, MFA, SSO, directory services, privileged access management.")
    concept("Incident response",
            "IR lifecycle phases, forensics fundamentals, log analysis, chain of custody.")
    concept("Shared vocabulary with the wider security team",
            "Cryptography, network security, and authentication fundamentals from Security+ are the common ground with SOC, infrastructure, and GRC colleagues. The certification confirms that baseline before AppSec-specific work begins.")
    add(SP(2))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE VIII — INTERVIEW PREPARATION & INTERVIEWING
    # ════════════════════════════════════════════════════════════════════════
    def qa(q, a):
        add(KeepTogether([
            P(f"<b>Q: {q}</b>", S["bul"]),
            P(f"<b>Key points:</b> {a}", S["bulsm"]),
        ]))
        add(SP(2))

    add(PageBreak())
    add(banner("VIII", "Interview Preparation & Interviewing", "Weeks 31–34"))
    add(SP(10))
    add(P("AppSec interviews test security knowledge, adversarial reasoning, and communication, and rarely algorithm puzzles. This phase runs interview preparation alongside the ongoing job search: rehearsing behavioral answers, drilling technical note cards, practicing the live technical formats \u2014 secure code review, light scripting, and system design \u2014 and running mock interviews so that the watched, timed setting is familiar before the first real interview.", S["body"]))
    add(SP(2))
    SS("Learning Resources")
    res("\u201c<i>Impractical Python Projects</i>\u201d", "Lee Vaughan, No Starch Press, 2018 (nostarch.com) \u2014 project-based Python practice for writing correct scripts quickly without an IDE\u2019s assistance")
    res("GitHub Security Lab", "securitylab.github.com \u2014 vulnerability research and published <a href=\"https://securitylab.github.com/advisories/\" color=\"#3A7AB8\">CVE write-ups</a> used as source material for secure code review practice")
    res("Security interview question bank", "github.com/jassics/security-interview-questions \u2014 a curated set of cybersecurity interview questions to build a technical note card deck from")
    res("Mock interview platforms", "<a href=\"https://www.tryexponent.com/\" color=\"#3A7AB8\">Aced (formerly Exponent)</a> (security engineering courses) and <a href=\"https://interviewing.io/\" color=\"#3A7AB8\">interviewing.io</a> (behavioral and observed coding practice)")
    add(SP(2))
    SS("Interview Preparation & Interviewing \u2014 Weeks 31–34")
    step("01", "REHEARSE: Behavioral Questions", "Weeks 31–34", [
        "Write out full answers to the standard behavioral questions, memorize them, and rehearse them aloud until your delivery sounds natural rather than recited.",
        "Rehearse AppSec-specific prompts as well: handling a developer who disputes a finding, prioritizing a backlog of vulnerabilities, explaining risk to a non-technical stakeholder, and so forth.",
    ])
    step("02", "MEMORIZE: Technical Note Cards", "Weeks 31–34", [
        "Build note cards organized by topic: the OWASP Top 10 and the individual web vulnerability classes, the Security+ domains, PortSwigger attack techniques, and defensive and secure-coding patterns.",
        "Alongside cards drawn from your own study, create a deck from a reputable existing set of cybersecurity interview questions at <a href=\"https://github.com/jassics/security-interview-questions\" color=\"#3A7AB8\">a curated public question bank</a>, rewriting the answers in your own words.",
        "Use the same grouped spaced review as Phase VII step 01: groups of seven, cumulative review pile, periodic re-reads of finished topics.",
    ])
    step("03", "PRACTICE: Secure Code Review", "Weeks 31–34", [
        "Practice a clear, spoken routine until it becomes automatic: read the code, name the vulnerability class, explain how it is exploited, and recommend the fix.",
        "Work through some of <a href=\"https://securitylab.github.com/\" color=\"#3A7AB8\">GitHub Security Lab</a>\u2019s published CVE <a href=\"https://securitylab.github.com/advisories/\" color=\"#3A7AB8\">write-ups</a> on unfamiliar code, at about five reviews each week.",
        "Practice naming the vulnerability class immediately from a code sample \u2014 for example: user input passed into a query without sanitizing it (injection); a React component using dangerouslySetInnerHTML (cross-site scripting); a JSON Web Token whose signature algorithm is accepted as \u2018none\u2019 (authentication bypass); a user identifier read from a request parameter with no authorization check (insecure direct object reference); or a URL fetched by the server without validation (server-side request forgery).",
    ])
    step("04", "PRACTICE: Light Scripting & System Design", "Weeks 31–34", [
        "Refresh your ability to write correct Python quickly without IDE hints; some companies include a short coding session (ex. CoderPad) \u2014 a small script to parse a log, fix a function, or automate a check, rather than an algorithm puzzle. <a href=\"https://nostarch.com/impracticalpythonprojects\" color=\"#3A7AB8\"><i>Impractical Python Projects</i></a> is good practice, and your development background covers most of this.",
        "Practice the security system-design format: sketch a small architecture \u2014 for example the trust boundaries of an authentication flow or a microservice \u2014 mark where data crosses each trust boundary, apply the STRIDE model to enumerate the threats, and rehearse walking through it aloud. This is verbal whiteboard practice, not a written deliverable.",
    ])
    step("05", "PRACTICE: Mock Interviews", "Weeks 31–34", [
        "Run at least one full mock interview each week, covering behavioral questions and a code review, through <a href=\"https://www.tryexponent.com/courses?query=security%20engineering\" color=\"#3A7AB8\">Aced (formerly Exponent)</a> (its security engineering courses) or <a href=\"https://interviewing.io/\" color=\"#3A7AB8\">interviewing.io</a>, so that a real interview is never the first time you perform under observation.",
        "Build up on your own first \u2014 untimed, then timed, then recorded and reviewed against your own answers \u2014 before booking the weekly mock interviews above.",
        "When you do not immediately know an answer, narrate your reasoning aloud and state what you do know and how you would investigate it, so that a pause becomes a spoken plan rather than silence.",
    ])
    add(SP(2))
    add(CondPageBreak(4.5*inch))    # Application Strategy fits one page; start fresh if less than that remains (V40)
    SS("<a name=\"application_strategy\"/>Application Strategy")
    add(B("<b>Start applying at Week 16:</b> security-conscious startups are viable targets from Week 16 with Phases I\u2013III complete, BSCP preparation under way, thirteen published writeups (the SQL injection essay, the JWT article, the ten OWASP Top 10 pieces, and the SSRF writeup), and PortSwigger Academy progress visible. Do not wait for curriculum completion."))
    add(B("<b>Target the titles that fit an entry:</b> Security Engineer I or II, Product Security Engineer, Junior Application Security Engineer, and DevSecOps Engineer, alongside Application Security Engineer. Many postings with the last title ask for three or more years of security experience; five years of production development plus this portfolio is relevant experience, so apply."))
    add(B("<b>Pin your best AppSec work:</b> set your GitHub pinned repositories to the key new artifacts \u2014 the <a href=\"#art_juiceshop\" color=\"#3A7AB8\">Juice Shop assessment report</a>, your <a href=\"#art_semgrep\" color=\"#3A7AB8\">custom Semgrep rule</a>, and the <a href=\"#art_threatmodel\" color=\"#3A7AB8\">threat model</a> \u2014 so a reviewer sees application-security work first, not the older web-dev projects."))
    add(B("<b>Make LinkedIn application-ready:</b> list BSCP and Security+ under licenses and certifications as each is passed; link your portfolio projects and published write-ups; and carry the application-security transition narrative in the About section. Publish as you work through the plan, so you have work to discuss at local cyber security community meetups."))
    add(B("<b>Frame the transition:</b> in cover letters and interviews, lead with the narrative \u2014 five years of full-stack software engineering, then a deliberate move into application security in August 2026. Point to this plan and portfolio as the evidence."))

    # ════════════════════════════════════════════════════════════════════════
    #  PHASE IX — EXPECTED FIRST DAYS ON THE JOB
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())
    add(banner("IX", "Expected First Days on the Job", "Week 35+"))
    add(SP(6))
    add(P("You will arrive knowing the vulnerability classes and tooling. You will be slower on internal tooling, company-specific security policies, and the organizational dynamics of working with development teams at varying security maturity. The plan budgets 4\u20138 weeks for that ramp.", S["body"]))
    add(SP(2))
    SS("First Two Weeks")
    add(P("Read the existing security documentation the way you read a codebase — understand what "
          "is there before suggesting what should change. Ask about the current vulnerability "
          "backlog before proposing new tooling. Understand what development teams build and how "
          "they ship before inserting yourself into their process.", S["body"]))
    add(B("What is the current SAST setup, if any? What do developers receive as output?"))
    add(B("What does the existing pentest methodology look like? How are findings tracked?"))
    add(B("Who are the key development team contacts? What are their current security concerns?"))
    add(B("What does the incident response process look like? Has it been tested?"))
    add(SP(4))
    add(nb("The question to ask in the first week is not ‘what should we add?’ It is ‘what is "
           "already here, and why is it the way it is?’ The answer tells you everything about the "
           "organizational constraints you are working within."))
    add(SP(6))
    SS("Your Immediate Differentiators")
    concept("Developer empathy",
            "You understand why developers write vulnerable code because you wrote it too. That "
            "shared experience makes conversations with development teams direct and credible.")
    concept("API security depth",
            "REST API security is a central AppSec domain. Hands-on API security "
            "knowledge built throughout this plan means arriving on day one prepared for the "
            "work.")
    concept("Automation instinct",
            "Semgrep rule development, CI/CD integration, and tooling scripting reuse skills from engineering work.")
    concept("Full-stack deployment",
            "You can own the deployment of security tooling from writing the Semgrep rule to integrating it into GitHub Actions to triaging the results.")
    add(SP(4))
    SS("The Gap and How Long It Takes to Close", reserve=0.6*inch)   # short closing section; keep Phase IX to one page
    add(P("The distance between ‘knows the vulnerability classes and tooling’ and ‘productive AppSec team member who moves fast with developers’ is the ramp this plan budgets 4–8 weeks for. You already speak the language of the teams you will be working with. You will be a junior with a steep learning curve ahead.", S["body"]))

    # ════════════════════════════════════════════════════════════════════════
    #  APPENDIX
    # ════════════════════════════════════════════════════════════════════════
    add(PageBreak())                  # the Appendix is a chapter too (user skim 2026-09-17)
    add(banner("", "Appendix", "Reference Material \u00b7 Philadelphia AppSec Community"))

    # ════════════════════════════════════════════════════════════════════════
    #  PHILADELPHIA APPSEC COMMUNITY  (subsection of the Appendix)
    # ════════════════════════════════════════════════════════════════════════
    add(SP(8))
    add(P('<a name="philly_appsec"/>Philadelphia AppSec Community', S["sshead"]))
    adds(rule())
    add(P("Security networking operates differently from general tech networking. The community "
          "is smaller, more tight-knit, and more willing to help people who show genuine "
          "curiosity. Attending events before you are employed builds relationships with local "
          "practitioners. Show up, ask good questions, and bring something to demonstrate \u2014 even "
          "a completed PortSwigger lab that taught you something surprising.", S["body"]))
    add(SP(4))
    add(P("<b>Core Groups</b>", S["body"]))
    grp = [
        ("OWASP Philadelphia Chapter", "owasp.org/chapters/philadelphia \u00b7 events on meetup.com/owasp-philadelphia-chapter \u00b7 Free",
         "The most directly relevant group for AppSec networking in Philadelphia. OWASP (Open Web "
         "Application Security Project) is the professional organization for web application "
         "security globally. The Philadelphia chapter holds regular meetings with technical "
         "presentations on vulnerability classes, tooling, and real-world AppSec work. The people "
         "in this room are AppSec practitioners at companies across the region \u2014 exactly the "
         "referral network you are building toward."),
        ("DC215 \u2014 Philadelphia DEF CON Group", "dc215.org \u00b7 events on meetup.com/dc_215 \u00b7 Free",
         "DEF CON Groups are local offshoots of DEF CON, the largest hacker conference in the "
         "world. DC215 holds regular meetups with technical talks, CTF practice, and informal "
         "knowledge sharing. Builder-focused and practitioner-dense. The format rewards people "
         "who bring something to show. Attend when Phase III work (vulnerability classes) is "
         "underway."),
        ("BSides Philadelphia", "bsidesphilly.org \u00b7 Annual \u00b7 December 11, 2026 \u00b7 $80 early bird",
         "Community-organized security conference with talks across offensive, defensive, and "
         "AppSec tracks. Affordable, full-day, attended by local practitioners from the companies "
         "you will apply to. Volunteer if possible \u2014 it is how you get face time with "
         "organizers and speakers."),
        ("Philly 2600", "philly2600.net \u00b7 First Friday monthly \u00b7 Free",
         "Philadelphia\u2019s oldest hacker meetup \u2014 running since the early 1990s and one of "
         "the first 2600 meetings ever listed in 2600 Magazine. Meets the first Friday of every "
         "month at Iffy Books starting at 6pm. No set agenda, no presentations, "
         "no gatekeeping \u2014 a casual hangout where people bring things to hack on or show off. "
         "Open to anyone. Around 8pm the group typically moves to a nearby bar. The lowest-"
         "pressure entry point into the Philly security community and a good place to show up "
         "early in the plan before you have polished work to present."),
        ("PhillySec", "x.com/phillysec \u00b7 Second Wednesday monthly \u00b7 Free",
         "Monthly security meetup, second Wednesday of each month. More structured than Philly "
         "2600 \u2014 presentations and technical discussions rather than open hangout format. "
         "Good mid-plan target once Phase II or III is underway and you have something to "
         "contribute to conversations."),
        ("OWASP Delaware Chapter", "meetup.com/owasp-delaware-chapter \u00b7 Wilmington, DE \u00b7 Monthly \u00b7 Free",
         "The OWASP chapter an hour south. Runs a monthly MetaCTF flash CTF night, hands-on "
         "exercises, and secure-coding presentations. A second AppSec-specific room when the Philadelphia calendar is quiet."),
        ("Ex Machina Parlor", "exmachinaparlor.org \u00b7 319 N 11th St, Room 5D \u00b7 Philadelphia",
         "A hackerspace specifically aimed at people interested in cybersecurity. Workshop and collaborative hacking space "
         "rather than a meetup. Worth knowing it exists as a physical space to work alongside "
         "practitioners. Check their calendar for events and open nights."),
    ]
    for name, meta, desc in grp:
        parts = [x.strip() for x in meta.split("·")]
        if _re.match(_DOM + r'$', parts[0]):
            name = _lnk(name, parts[0]); parts = parts[1:]
        parts = [_re.sub(r'events on (' + _DOM + r')', lambda mm: "events on " + _lnk("Meetup", mm.group(1)), x) for x in parts]
        add(B(f"<b>{name}</b> ({' · '.join(parts)}) — {desc}"))
    add(SP(2))
    add(SP(4))
    add(P("<b>Conferences</b>", S["body"]))
    add(B("<b><a href=\"https://owasp.org/events\" color=\"#3A7AB8\">OWASP Global AppSec USA</a></b> (Annual \u00b7 autumn, "
          "rotating US city; 2026 is San Francisco) \u2014 The flagship AppSec-specific conference in the US, with tracks for "
          "builders, breakers, defenders, and OWASP "
          "projects. This is the single most "
          "targeted conference in the plan \u2014 the audience is exactly the community you are "
          "entering and the talks directly map to the skills in every phase. Attend once Phase IV "
          "or V is complete."))
    add(B("<b><a href=\"https://owasp.org\" color=\"#3A7AB8\">OWASP BASC \u2014 Boston</a></b> (Annual \u00b7 April) \u2014 The OWASP "
          "Boston Application Security Conference. Regional, practitioner-dense, focused on AppSec "
          "engineering and secure development. Lower-cost than Global AppSec USA. "
          "Strong emphasis on hands-on content and OWASP standards \u2014 the audience overlaps "
          "heavily with who you will work alongside in the role."))
    add(B("<b><a href=\"https://thotcon.org\" color=\"#3A7AB8\">Thotcon \u2014 Chicago</a></b> (next event June 11\u201312, 2027) \u2014 A mid-sized "
          "hacker conference: more intimate than DEF CON, technically dense, practitioner-"
          "focused. Falls after this plan ends; a target for your first year in the role."))
    add(B("<b><a href=\"https://jawncon.org\" color=\"#3A7AB8\">JawnCon \u2014 Glenside, PA</a></b> (Annual \u00b7 October) \u2014 "
          "Philadelphia\u2019s own security and technology conference, held at Arcadia University just outside the city. Covers a wide range of "
          "security and tech topics with a deliberately approachable, community feel. Worth "
          "attending as a local conference where you will run into the same practitioners from "
          "OWASP and DC215."))
    add(B("<b><a href=\"https://bsidesdelaware.com\" color=\"#3A7AB8\">BSides Delaware \u2014 Newark, DE</a></b> (Annual \u00b7 November 13\u201314, 2026 \u00b7 $25) \u2014 "
          "The nearest BSides after Philadelphia, at the University of Delaware, about an hour away. "
          "Talks, villages, and a CFP; the same regional practitioner crowd as BSides Philly. Falls in "
          "Week 14, so a realistic first conference with Phase III work in hand."))
    add(B("<b><a href=\"https://defcon.org\" color=\"#3A7AB8\">DEF CON \u2014 Las Vegas</a></b> (Annual \u00b7 August) \u2014 the flagship "
          "hacker conference. Within it, the <a href=\"https://appsecvillage.com\" color=\"#3A7AB8\">AppSec Village</a> is a 100% volunteer-run "
          "space specifically for application security \u2014 attacker-minded talks, live demos, hands-on "
          "workshops, and an AppSec-focused CTF, "
          "the most directly relevant part of DEF CON for this career path. A larger, costlier "
          "trip to Las Vegas than the regional events \u2014 treat it as a target for a future year, once "
          "you are established in the field, rather than something to attend during this plan."))

