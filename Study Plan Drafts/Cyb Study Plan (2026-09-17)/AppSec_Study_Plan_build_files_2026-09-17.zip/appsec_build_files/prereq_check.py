#!/usr/bin/env python3
"""
prereq_check.py — verifies the plan is FOLLOWABLE, not just internally consistent.

The earlier suite (timeline/partition/audit/mentor/month) checked that the doc
agreed with ITSELF. It never checked whether a learner walking the steps in order
would hit a task requiring a tool or skill the plan had not taught yet. That gap
let the "Burp used before it's taught" bug ship. This suite closes that class.

Every check prints PASS/FAIL. At the end a COVERAGE manifest lists exactly what
is and is NOT checked, so the suite's own completeness is visible instead of
assumed. Exit 1 if any check fails.
"""
import re, sys
raw = open("appsec_content.py", encoding="utf-8").read()
ORDER = ["0","I","II","III","IV","V","VI","VII","VIII","IX"]
oi = {p:i for i,p in enumerate(ORDER)}

# ---- extract steps: (phase, num, fulltext, position) ------------------------
phases = [(m.start(), m.group(1)) for m in re.finditer(r'banner\("([0IVX]+)",', raw)]
def phase_of(pos):
    cur = "?"
    for s,ph in phases:
        if s <= pos: cur = ph
        else: break
    return cur
STEPS = []
for m in re.finditer(r'step\(', raw):
    i=m.end(); d=1; j=i
    while j < len(raw) and d>0:
        d += (raw[j]=='(') - (raw[j]==')'); j+=1
    q = re.findall(r'"((?:[^"\\]|\\.)*)"', raw[i:j-1])
    STEPS.append({"phase":phase_of(m.start()), "num":q[0] if q else "?",
                  "text":" ".join(q).lower(), "pos":m.start()})

def key(s): return (oi.get(s["phase"],99), s["num"])

results = []
def check(name, ok, detail=""):
    results.append((name, ok, detail))

# =====================================================================
# CATEGORY A — a tool/skill must be TAUGHT before any step USES it.
#   REQUIRES: resource substring -> capability it silently needs
#   TAUGHT:   capability -> (substring that marks where it's taught)
# =====================================================================
REQUIRES = {
    "portswigger":        "burp",
    "web-security/":      "burp",
    "web security academy":"burp",
    "burp collaborator":  "burp_pro",
    "collaborator":       "burp_pro",
    "zap ":               "zap",
    "semgrep":            "semgrep",
    "bandit":             "bandit",
    "snyk":               "snyk",
}
TEACH_MARKERS = {  # a step teaches the tool if its text has tool-name AND a marker
    "burp":     (["burp"], ["the basics","basics","proxy","repeater","getting started","intercept"]),
    "burp_pro": (["burp"], ["buy burp","professional now","pro-only","buy at"]),
    "zap":      (["zap"],  ["install","set up","getting started","baseline","docs","dast basics","learn","against dvwa"]),
    "semgrep":  (["semgrep"], ["install","first rule","write","docs","getting started","registry"]),
    "bandit":   (["bandit"], ["install","run bandit","docs","getting started"]),
    "snyk":     (["snyk"], ["install","set up","getting started","account","docs"]),
}
def taught_at(tool):
    names, markers = TEACH_MARKERS[tool]
    cands = [s for s in STEPS
             if any(n in s["text"] for n in names) and any(mk in s["text"] for mk in markers)]
    return min(cands, key=key) if cands else None

viol = []
for s in STEPS:
    extra=[]
    if any(t in s["text"] for t in ("webgoat","juice shop")) and any(v in s["text"] for v in ("exploit","lesson","attack","idor","assessment","injection lab")):
        extra=[("app(exploited)","burp")]
    for res, tool in list(REQUIRES.items())+extra:
        if res in s["text"] or res=="app(exploited)":
            t = taught_at(tool)
            if t is None:
                viol.append((s, tool, "never taught anywhere"))
            elif key(s) < key(t):
                viol.append((s, tool, f"taught later at Phase {t['phase']} step {t['num']}"))
# one check per (step,tool) violation
seen=set()
for s,tool,why in viol:
    k=(s["phase"],s["num"],tool)
    if k in seen: continue
    seen.add(k)
    check(f"A: Phase {s['phase']} step {s['num']} — needs '{tool}' before it's taught",
          False, why)
if not viol:
    check("A: every tool taught before any step that requires it", True)

# =====================================================================
# CATEGORY B — cross-references to phases must be valid.
# =====================================================================
badrefs = [p for p in re.findall(r'Phase ([0IVX]+)', raw) if p not in ORDER]
check("B: all prose 'Phase X' references name a real phase (0–IX)",
      not badrefs, f"invalid: {set(badrefs)}" if badrefs else "")

# 're-read your Phase II SQL injection notes' — SQLi must actually be in Phase II
sqli_phaseII = any(s["phase"]=="II" and "sql injection" in s["text"] for s in STEPS) \
    or ("sql injection" in raw.lower().split('banner("III"')[0].split('banner("II"')[-1])
check("B: Phase III's 'Phase II SQL injection notes' back-ref is real",
      sqli_phaseII, "Phase II has no SQL injection content" if not sqli_phaseII else "")

# =====================================================================
# CATEGORY C — key resources present before the step that needs them.
# =====================================================================
low = raw.lower()
# Security+ study material must appear before the Security+ exam step
def appears_by(term, target="VII"):
    return any(oi.get(phase_of(m.start()),99) <= oi[target]
               for m in re.finditer(re.escape(term), low))
secplus = appears_by("professor messer") or appears_by("sy0-701") or appears_by("get certified get ahead")
check("C: Security+ study resource exists before/at the cert phase (VII)",
      secplus, "no Security+ study resource found at/before Phase VII" if not secplus else "")

# flaws.cloud (AWS wargame) should sit in the cloud phase (V), not before AWS intro
flaws_ph = phase_of(low.find("flaws.cloud")) if "flaws.cloud" in low else None
check("C: flaws.cloud used in the Cloud phase (V), not earlier",
      flaws_ph in (None,"V"), f"appears in Phase {flaws_ph}" if flaws_ph not in (None,"V") else "")

# =====================================================================
# CATEGORY D — structural sanity the earlier suites already imply,
#   re-asserted here so this file stands alone.
# =====================================================================
check("D: at least one step parsed in every content phase 0–VIII",
      all(any(s["phase"]==p for s in STEPS) for p in ORDER[:-1]),
      "")
REAL = [s for s in STEPS if s["phase"] != "?" and s["num"].isdigit()]
check("D: step count is the known 63 (real steps, excluding the step() definition)", len(REAL)==63, f"got {len(REAL)}")

# =====================================================================
# CATEGORY E — CONCEPT prerequisites (from manual read of all steps).
#   HARD: a concept USED AT DEPTH (practitioner labs / audit / article) must be
#         formally TAUGHT (learning path / foundational notes) at or before it.
#   Phase I intro exposure on self-teaching platforms (PortSwigger skim, WebGoat
#         lessons) is INTENTIONAL and reported advisory, not failed.
# =====================================================================
def pos(marker):
    i = raw.find(marker) if 'raw' in globals() else RAW.find(marker)
    return None if i<0 else (phase_of(i), i)
RAW = open("appsec_content.py",encoding="utf-8").read()
# strip html tags AND collapse whitespace so split-across-literal text matches
import re as _re
CLEAN = _re.sub(r"\\u2013","-", _re.sub(r"<[^>]+>","", RAW))
CLEAN = _re.sub(r'"\s*"', "", CLEAN)          # join adjacent string literals
CLEAN = _re.sub(r"\s+"," ", CLEAN)
# phase boundaries in CLEAN
_cph=[(m.start(),m.group(1)) for m in _re.finditer(r'banner\("([0IVX]+)",', CLEAN)]
def _phase_clean(pos):
    c="?"
    for st,ph in _cph:
        if st<=pos: c=ph
        else: break
    return c
def find(marker):
    i = CLEAN.find(marker)
    return None if i<0 else (_phase_clean(i), i)
def before(a,b):
    A,B=find(a),find(b)
    if not A or not B: return None
    if oi[A[0]]<oi[B[0]]: return True
    if oi[A[0]]>oi[B[0]]: return False
    return A[1]<=B[1]

HARD_CONCEPTS = [
 ("JWT learning path taught before FastAPI JWT audit",
    "Complete the JWT learning path", "it implements JWT authentication"),
 ("SQLi foundational (II) taught before SQLi practitioner (III)",
    "Read the PortSwigger SQL injection learning path", "Re-read your Phase II SQL injection notes"),
 ("Access control apprentice (II) before practitioner (III)",
    "Access control and API testing learning paths", "Review your Phase II Access control notes"),
 ("API testing apprentice (II) before API deep-dive (III)",
    "Access control and API testing learning paths", "Review your Phase II API testing notes"),
 ("Authentication learning path taught before auth checklist audit",
    "Complete the PortSwigger Authentication learning path", "Write a 1-2 page authentication audit checklist"),
]
for name, teach, use in HARD_CONCEPTS:
    r = before(teach, use)
    if r is None:
        check(f"E: {name}", False, "marker text not found (edit may have changed wording)")
    else:
        check(f"E: {name}", r, "used at depth before it is taught" if not r else "")

# advisory: Phase I intentional intro exposure (report, never fail)
intros=[]
for concept in ("SQL Injection (intro)","Cross Site Scripting","Insecure Direct Object References","Authentication Bypasses"):
    f=find(concept)
    if f and f[0]=="I": intros.append(concept)
check(f"E: Phase I intentional intro exposure (advisory: {len(intros)} concepts pre-taught on self-teaching platforms)", True)

# ---- report -----------------------------------------------------------
fails = [r for r in results if not r[1]]
print("="*72)
print("PREREQUISITE / FOLLOWABILITY CHECKS")
print("="*72)
for name, ok, detail in results:
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}")
    if detail and not ok: print(f"         -> {detail}")

print("\n" + "="*72)
print("COVERAGE MANIFEST  (what this suite DOES and DOES NOT verify)")
print("="*72)
print("  CHECKED:")
print("   • tool-taught-before-used for: burp, burp_pro, zap, semgrep, bandit, snyk")
print("   • resources that silently require a tool:", ", ".join(sorted(set(REQUIRES))))
print("   • prose Phase-X cross-references resolve to real phases")
print("   • Phase III's SQL-injection back-reference to Phase II")
print("   • Security+ study resource precedes the exam; flaws.cloud in cloud phase")
print("   • structural: 63 steps, every phase populated")
print("  NOT CHECKED (known gaps — do NOT read a pass as 'fully verified'):")
print("   • tools/skills I did not enumerate (any resource not in REQUIRES)")
print("   • skill prerequisites that aren't a named tool (e.g. 'needs OAuth2")
print("     understanding' before an OAuth lab) — semantic, not yet encoded")
print("   • whether each lab's difficulty/scope is realistic for the timing")
print("   • correctness of the JUDGMENT (cert choice, phase emphasis) — unprovable by script")
print("   • book chapter references point to content that exists in those books")

print("\n" + "="*72)
print(f"RESULT: {len(results)-len(fails)}/{len(results)} passed, {len(fails)} FAILED")
print("="*72)
sys.exit(1 if fails else 0)
