#!/usr/bin/env python3
"""
month_consistency_check.py — validates every plan-DURATION month reference.

Why this exists: the timeline checks validated the digit-form pace line
(`6 months`, `8 months`) and the phase boundaries, but NOT prose that states the
total duration in spelled-out words. That blind spot let an overview sentence say
the plan runs "eight to nine months" while the calibrated range is 6-8 — an
inconsistency no existing check could see. This test closes that gap by matching
month durations in BOTH digit form ("6-8 months", "7 months") AND word form
("six to eight months", "seven months"), then asserting each falls within the
allowed plan range.

Allowed plan duration: 6-8 months inclusive (optimistic 6 / realistic 7 / outer 8).
Non-duration month references are excluded (market stats, cert retake windows,
recurring cadence like "monthly" or "per month", the "weeks, not months" idiom).

Exit 0 if all in range, 1 otherwise.
"""
import re, sys

ALLOWED = {6, 7, 8}          # months a plan-duration claim may state
TEXT = open("appsec_content.py", encoding="utf-8").read()
flat = re.sub(r"<[^>]+>", " ", TEXT)                 # strip html tags
flat = flat.replace("\\u2013", "-").replace("\\u2014", "-").replace("\u2013", "-").replace("\u2014", "-")
flat = re.sub(r"\s+", " ", flat)

WORD = {"one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,
        "eight":8,"nine":9,"ten":10,"eleven":11,"twelve":12}
def to_int(tok):
    tok = tok.strip().lower()
    return int(tok) if tok.isdigit() else WORD.get(tok)

# a month-duration phrase: <num>[ to/-/– <num>] month(s)
NUM = r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)"
PHRASE = re.compile(rf"{NUM}(?:\s*(?:-|to)\s*{NUM})?\s+months?\b", re.I)

# contexts that are NOT plan-duration claims → excluded by nearby keywords
EXCLUDE_NEAR = ("past", "prior year", "retake", "cannot retake", "within",
                "per month", "/month", "a month", "each month")

def excluded(span_text, before):
    b = before.lower()
    if any(k in b for k in EXCLUDE_NEAR):
        return True
    # cadence words like "monthly" are handled by \b (months? won't match "monthly")
    return False

problems = []
for m in PHRASE.finditer(flat):
    nums = [to_int(g) for g in m.groups() if g]
    before = flat[max(0, m.start()-40):m.start()]
    whole  = flat[max(0, m.start()-45):m.end()+5]
    # exclude known non-duration month references
    if 12 in nums or "twelve" in m.group(0).lower():
        continue                                   # market stat / cert retake window
    if excluded(whole, before):
        continue
    bad = [n for n in nums if n not in ALLOWED]
    if bad:
        problems.append((m.group(0).strip(), bad, whole.strip()))

if problems:
    print(f"MONTH CONSISTENCY FAILED — {len(problems)} out-of-range duration reference(s):")
    print(f"   allowed plan duration months: {sorted(ALLOWED)}")
    for phrase, bad, ctx in problems:
        print(f"   ✗ '{phrase}'  (out-of-range: {bad})")
        print(f"        …{ctx}…")
    sys.exit(1)

print(f"PASS - all plan-duration month references within {sorted(ALLOWED)} "
      f"(digit and spelled-out forms checked).")
sys.exit(0)
