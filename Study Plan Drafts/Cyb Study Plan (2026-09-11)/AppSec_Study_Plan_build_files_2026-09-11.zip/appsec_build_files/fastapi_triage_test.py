#!/usr/bin/env python3
"""
fastapi_triage_test.py  —  validates fastapi_triage.py against the requirements.

Runs EVERY section (all 44) through a battery of predicates, each derived from
one of the stated requirements. A section PASSES only if its assigned outcome
(TRANSCRIBE / TRANSCRIBE+IMPLEMENT / SKIP) is consistent with every predicate.
Any contradiction is a FAIL naming the requirement it violates — so a wrong
score or a wrong skip/implement call surfaces instead of hiding.

The predicates are the requirements, made executable:

  R1  don't-skip-security   — security is table stakes (2026 market). If a
                              section is security-relevant (sec >= 2) it must
                              NOT be skipped.
  R2  don't-skip-gap        — learner's own goal: close foundational gaps. If a
                              section closes a gap (gap >= 2) it must not skip.
  R3  don't-skip-signal     — interviewer buys interview signal. If signal == 3
                              it must not skip.
  R4  implement-is-transcribe — you cannot build a section you skip; implement
                              implies a transcribe outcome.
  R5  build-the-mechanisms  — interviewer rewards hands-on depth ("why not
                              implement each transcribe?"). A TRANSCRIBE section
                              that is a buildable in-app mechanism MUST implement.
  R6  transcribe-only-is-justified — the inverse: a TRANSCRIBE-only section
                              (no implement) must NOT be a buildable mechanism
                              (else R5 would want it built). Only non-buildable
                              deployment/concept sections may be transcribe-only.
  R7  skip-is-justified     — finite time: a SKIP must be low on ALL of
                              gap/security/signal (< 2, < 2, < 3). If it isn't,
                              it was skipped despite real value.
  R8  transcribe-earns-cost — transcription is slow; a TRANSCRIBE section must
                              clear the score cutoff (i.e. earn its cost).

BUILDABLE_MECHANISM below is the ONE piece of independent judgment the test
adds: can this section be wired into the practice API as running code you learn
from building?  It is deliberately encoded here, separate from the triage's
scores, so R5/R6 are a genuine cross-check rather than a restatement.
"""

import importlib.util, sys, pathlib

# import the triage module
spec = importlib.util.spec_from_file_location(
    "ft", str(pathlib.Path(__file__).with_name("fastapi_triage.py")))
ft = importlib.util.module_from_spec(spec); spec.loader.exec_module(ft)

# ── independent judgment: is the section a mechanism you can BUILD in the API? ──
# True  = wiring it into the app as running code teaches the "why".
# False = deployment concern, pure concept, or reference — nothing to build.
BUILDABLE_MECHANISM = {
 "Simple OAuth2 (Password + Bearer)": True,  "OAuth2 + hashing + JWT": True,
 "Middleware": True,   "CORS": True,   "SQL (Relational) Databases": True,
 "Bigger Applications (APIRouter)": True,     "Stream JSON Lines": True,
 "Server-Sent Events (SSE)": True,            "Background Tasks": True,
 "Metadata and Docs URLs": True,   "Frontend": False,   "Static Files": True,
 "Testing": True,   "Debugging": True,   "Stream Data": True,   # Debugging = follow-along (run the debugger attach hands-on)
 "Path Op Advanced Configuration": True,      "Additional Status Codes": True,
 "Return a Response Directly": True,          "Custom Response (HTML/File/…)": True,
 "Additional Responses in OpenAPI": True,     "Response Cookies": True,
 "Response Headers": True,   "Response - Change Status Code": True,
 "Advanced Dependencies": True,
 "Advanced Security → OAuth2 scopes": True,
 "Advanced Security → HTTP Basic Auth": True,
 "Using the Request Directly": True,          "Using Dataclasses": True,
 "Advanced Middleware": True,   "Sub Applications - Mounts": True,
 "Behind a Proxy": False,       # deployment config (nginx/traefik + fwd headers)
 "Templates": True,   "WebSockets": True,   "Lifespan Events": True,
 "Testing WebSockets": True,    "Testing Events": True,
 "Testing Dependencies w/ Overrides": True,   "Async Tests": True,
 "Settings & Environment Variables": True,    "OpenAPI Callbacks": True,
 "OpenAPI Webhooks": True,   "Including WSGI (Flask/Django)": True,
 "Generating SDKs": True,    "Advanced Python Types": False,
 "JSON with Bytes as Base64": True,           "Strict Content-Type Checking": True,
}

def predicates(name, size, gap, sec, sig, use, impl, why, out):
    """Return list of (req_id, ok, message) for one section."""
    is_skip       = (out == "SKIP")
    is_transcribe = out.startswith("TRANSCRIBE")
    is_implement  = ("IMPLEMENT" in out)
    mech          = BUILDABLE_MECHANISM[name]
    P = []
    # "must not skip" applies to CORE (maxed, level-3) criteria only. Level-2 is
    # secondary relevance and is a legitimate finite-time cutoff decision — else
    # R1 would force transcribing every section with any security angle, which
    # contradicts the finite-time requirement.
    P.append(("R1 don't-skip-core-security", not (sec >= 3 and is_skip),
              f"CORE security (sec={sec}) but SKIP"))
    P.append(("R2 don't-skip-major-gap",     not (gap >= 3 and is_skip),
              f"major gap (gap={gap}) but SKIP"))
    P.append(("R3 don't-skip-top-signal",    not (sig >= 3 and is_skip),
              f"top interview signal (sig={sig}) but SKIP"))
    P.append(("R4 implement⇒transcribe", not (is_implement and not is_transcribe),
              "implement flag on a non-transcribe outcome"))
    P.append(("R5 build-the-mechanisms", not (is_transcribe and mech and not is_implement),
              "TRANSCRIBE + buildable mechanism but NOT implement"))
    P.append(("R6 transcribe-only-ok",   not (is_transcribe and not is_implement and mech),
              "TRANSCRIBE-only but IS a buildable mechanism (should implement)"))
    P.append(("R7 skip-is-justified",    not (is_skip and (sec >= 3 or gap >= 3 or sig >= 3)),
              f"SKIP despite CORE value (gap={gap},sec={sec},sig={sig})"))
    P.append(("R8 transcribe-earns-cost",not (is_transcribe and ft.score(gap,sec,sig,use) < ft.TRANSCRIBE_MIN),
              "TRANSCRIBE below the score cutoff"))
    return P

def main():
    total_fail = 0; n = 0
    print("="*80)
    print(f"  VALIDATING each section against 8 requirement-predicates")
    print("="*80)
    for row in ft.SECTIONS:
        name, size, gap, sec, sig, use, impl, why = row
        n += 1
        sc  = ft.score(gap, sec, sig, use)
        out = ft.outcome(sc, impl)
        results = predicates(name, size, gap, sec, sig, use, impl, why, out)
        fails = [(rid, msg) for rid, ok, msg in results if not ok]
        status = "PASS" if not fails else "FAIL"
        if fails:
            total_fail += 1
            print(f"\n[{status}] {name}  →  {out}  (score {sc:.1f})")
            for rid, msg in fails:
                print(f"        ✗ {rid}: {msg}")
    print("\n" + "="*80)
    print(f"  {n} sections tested   |   {n-total_fail} pass   |   {total_fail} FAIL")
    print("="*80)
    sys.exit(1 if total_fail else 0)

if __name__ == "__main__":
    main()
