#!/usr/bin/env python3
"""
step_actions_check.py  —  semantic repetition + prerequisite analyzer.

Unlike a keyword matcher, this works on MEANING. Each step is hand-encoded as a
normalized ACTION LIST (what the step actually has you DO) plus the RESOURCES it
touches. A separate REQUIREMENTS map holds the hidden facts a keyword scan can't
see (e.g. "doing PortSwigger labs requires Burp installed"). Then, across all
step pairs, it reports:

  REPETITION : the same normalized action appears in two different steps
               (catches duplicates even when the wording differs, because both
                map to the same action token — e.g. "install Burp" and
                "learn Burp Suite: The Basics" both -> set_up:burp).

  PREREQ     : a step needs something (via REQUIREMENTS) that is only set up in a
               LATER step (used-before-available).

The ACTION LISTS below are a human reading of each step (mine), encoded so you
can correct any you disagree with — edit the ACTIONS table and re-run.

Runs on every build (invoked by build_appsec.py). Read-only: never edits the plan.
Exit code is always 0 (informational); it prints findings for you to judge.
"""
import sys

# ─────────────────────────────────────────────────────────────────────────────
# ACTION VOCABULARY (normalized tokens)
#   set_up:X      = install / configure / first-time learn-the-tool X
#   learn:X       = read/learn a topic or tool's usage (not first-time setup)
#   labs:X        = do PortSwigger labs for vuln class X
#   exploit:X     = hands-on exploit X on a target app (WebGoat/JuiceShop/etc)
#   read_book:X   = read chapters of book X
#   write:X       = produce a written artifact X
#   run_tool:X    = run/use tool X against something
#   account:X     = create an account on platform X
#   exam:X        = sit exam X
#   drill:X       = timed reinforcement of X
# ─────────────────────────────────────────────────────────────────────────────
# (phase, step): { "actions":[...], "resources":[...] }
ACTIONS = {
 ("0","01"):  {"actions":["set_up:github","account:linkedin","set_up:git-repo"],"resources":["git","github","linkedin"]},
 ("0","02"):  {"actions":["learn:http","learn:cookies","learn:sql"],"resources":["mdn"]},
 ("0","03"):  {"actions":["learn:fastapi","build:fastapi-app"],"resources":["fastapi"]},
 ("0","04"):  {"actions":["set_up:docker","exploit-setup:webgoat"],"resources":["docker","webgoat"]},

 ("I","01"):  {"actions":["set_up:burp","learn:http"],"resources":["tryhackme","burp"]},
 ("I","02"):  {"actions":["account:portswigger","labs:sqli","labs:xss"],"resources":["portswigger"]},
 ("I","03"):  {"actions":["read_book:rwbh"],"resources":["book"]},
 ("I","04"):  {"actions":["exploit:webgoat","write:writeup"],"resources":["webgoat","docker"]},

 ("II","01"): {"actions":["read_book:wahh","learn:burp","learn:http-headers"],"resources":["wahh","burp"]},
 ("II","02"): {"actions":["read_book:wahh","labs:auth","labs:jwt","labs:oauth"],"resources":["wahh","portswigger"]},
 ("II","03"): {"actions":["write:auth-checklist","audit:fastapi-app"],"resources":["fastapi","github"]},
 ("II","04"): {"actions":["read_book:wahh","labs:access-control","labs:api"],"resources":["wahh","portswigger"]},
 ("II","05"): {"actions":["labs:sqli"],"resources":["portswigger"]},
 ("II","06"): {"actions":["read_book:alicebob"],"resources":["book"]},
 ("II","07"): {"actions":["learn:crypto","run_tool:hashcat","build:bcrypt"],"resources":["hashcat","owasp"]},
 ("II","08"): {"actions":["learn:networking","learn:ssrf-prevention"],"resources":["tryhackme","owasp"]},
 ("II","09"): {"actions":["write:linkedin-article"],"resources":["linkedin"]},

 ("III","01"):{"actions":["set_up:burp-pro","labs:sqli","labs:oscmd","labs:ssti","write:writeup"],"resources":["burp-pro","portswigger","collaborator"]},
 ("III","02"):{"actions":["write:owasp-top10-series"],"resources":["owasp"]},
 ("III","03"):{"actions":["labs:xss","write:writeup"],"resources":["portswigger"]},
 ("III","04"):{"actions":["labs:csrf","labs:ssrf","labs:xxe","write:writeup"],"resources":["portswigger"]},
 ("III","05"):{"actions":["labs:access-control","labs:business-logic","write:writeup"],"resources":["portswigger"]},
 ("III","06"):{"actions":["labs:deserialization","labs:file-upload","labs:path-traversal","write:writeup"],"resources":["portswigger","burp-pro"]},
 ("III","07"):{"actions":["read_book:hackingapis","labs:api","learn:owasp-api-top10"],"resources":["book","portswigger","owasp"]},
 ("III","08"):{"actions":["labs:web-llm"],"resources":["portswigger"]},
 ("III","09"):{"actions":["learn:owasp-llm-top10"],"resources":["owasp"]},

 ("IV","01"): {"actions":["learn:burp-decoder-comparer","labs:sqli","labs:auth"],"resources":["burp"]},
 ("IV","02"): {"actions":["drill:bscp-practice"],"resources":["burp-pro"]},
 ("IV","03"): {"actions":["set_up:semgrep","set_up:bandit","run_tool:semgrep","run_tool:bandit","write:semgrep-rule"],"resources":["semgrep","bandit"]},
 ("IV","04"): {"actions":["set_up:trufflehog","set_up:gitleaks","run_tool:trufflehog","run_tool:gitleaks"],"resources":["trufflehog","gitleaks"]},
 ("IV","05"): {"actions":["set_up:zap","run_tool:zap"],"resources":["zap","webgoat"]},
 ("IV","06"): {"actions":["apply:jobs"],"resources":[]},
 ("IV","07"): {"actions":["labs:blind-oob","drill:collaborator"],"resources":["burp-pro","collaborator","portswigger"]},
 ("IV","08"): {"actions":["labs:request-smuggling","labs:host-header","labs:cache-poisoning"],"resources":["portswigger"]},
 ("IV","09"): {"actions":["write:poc-notes"],"resources":["burp"]},
 ("IV","10"): {"actions":["learn:burp-scanner","labs:scanning"],"resources":["burp-pro"]},
 ("IV","11"): {"actions":["drill:reinforcement-labs"],"resources":["portswigger","burp-pro"]},
 ("IV","12"): {"actions":["drill:resolve-cold"],"resources":["portswigger"]},
 ("IV","13"): {"actions":["drill:mystery-labs"],"resources":["portswigger"]},
 ("IV","14"): {"actions":["drill:exam-stamina"],"resources":["portswigger","burp-pro","collaborator"]},
 ("IV","15"): {"actions":["exam:bscp"],"resources":["burp-pro"]},
 ("IV","16"): {"actions":["set_up:snyk","run_tool:snyk"],"resources":["snyk"]},
 ("IV","17"): {"actions":["run_tool:burp","run_tool:zap","run_tool:semgrep","run_tool:bandit","run_tool:snyk","run_tool:trufflehog","exploit:juiceshop","write:assessment-report"],"resources":["juiceshop","burp","zap","semgrep","bandit","snyk","trufflehog"]},
 ("IV","18"): {"actions":["build:llm-endpoint","exploit:own-api","write:writeup"],"resources":["fastapi"]},

 ("V","01"):  {"actions":["learn:aws-iam"],"resources":["aws"]},
 ("V","02"):  {"actions":["set_up:aws-cli","exploit:flaws-cloud","write:writeup"],"resources":["aws-cli","flaws.cloud"]},
 ("V","03"):  {"actions":["exploit:flaws2-cloud","learn:aws-defender"],"resources":["flaws2.cloud"]},

 ("VI","01"): {"actions":["read_book:owasp-cr-guide","review:opensource-code"],"resources":["owasp","github"]},
 ("VI","02"): {"actions":["learn:asvs","write:asvs-checklist"],"resources":["owasp"]},
 ("VI","03"): {"actions":["read_book:threatmodeling","write:threat-model","apply:stride"],"resources":["threatdragon","fastapi"]},
 ("VI","04"): {"actions":["drill:code-review-timed"],"resources":["github"]},

 ("VII","01"):{"actions":["read_book:secplus","write:secplus-cards"],"resources":["secplus-book"]},
 ("VII","02"):{"actions":["drill:secplus-practice-exam"],"resources":["messer"]},
 ("VII","03"):{"actions":["exam:secplus"],"resources":["pearson-vue"]},
 ("VII","04"):{"actions":["apply:jobs"],"resources":[]},

 ("VIII","01"):{"actions":["rehearse:behavioral"],"resources":[]},
 ("VIII","02"):{"actions":["write:interview-cards"],"resources":["github"]},
 ("VIII","03"):{"actions":["drill:code-review-verbal"],"resources":["github"]},
 ("VIII","04"):{"actions":["drill:scripting","apply:stride"],"resources":[]},
 ("VIII","05"):{"actions":["drill:mock-interview"],"resources":["exponent"]},
}

# ─────────────────────────────────────────────────────────────────────────────
# REQUIREMENTS map: an action REQUIRES a capability that must be set up earlier.
#   capability -> the action token that SETS IT UP
# ─────────────────────────────────────────────────────────────────────────────
SETUP_FOR = {
 "burp":       "set_up:burp",
 "burp-pro":   "set_up:burp-pro",
 "docker":     "set_up:docker",
 "aws-cli":    "set_up:aws-cli",
 "semgrep":    "set_up:semgrep",
 "bandit":     "set_up:bandit",
 "zap":        "set_up:zap",
 "snyk":       "set_up:snyk",
 "trufflehog": "set_up:trufflehog",
 "gitleaks":   "set_up:gitleaks",
}
# which actions REQUIRE which capability (the hidden facts)
REQUIRES = {
 "labs:sqli":"burp", "labs:xss":"burp", "labs:auth":"burp", "labs:jwt":"burp",
 "labs:oauth":"burp", "labs:access-control":"burp", "labs:api":"burp",
 "labs:csrf":"burp", "labs:ssrf":"burp", "labs:xxe":"burp",
 "labs:business-logic":"burp", "labs:deserialization":"burp",
 "labs:file-upload":"burp", "labs:path-traversal":"burp", "labs:web-llm":"burp",
 "labs:request-smuggling":"burp", "labs:host-header":"burp",
 "labs:cache-poisoning":"burp", "labs:scanning":"burp-pro",
 "labs:oscmd":"burp", "labs:ssti":"burp", "labs:blind-oob":"burp-pro",
 "exploit:webgoat":"docker", "exploit:juiceshop":"docker",
 "drill:collaborator":"burp-pro", "drill:reinforcement-labs":"burp",
 "drill:resolve-cold":"burp", "drill:mystery-labs":"burp",
 "drill:exam-stamina":"burp-pro", "exam:bscp":"burp-pro",
 "run_tool:semgrep":"semgrep", "run_tool:bandit":"bandit",
 "run_tool:zap":"zap", "run_tool:snyk":"snyk",
 "run_tool:trufflehog":"trufflehog", "run_tool:burp":"burp",
 "run_tool:hashcat":"hashcat", "exploit:flaws-cloud":"aws-cli",
}

ORDER=["0","I","II","III","IV","V","VI","VII","VIII","IX"]
def key(pn): return (ORDER.index(pn[0]), int(pn[1]))

def main():
    # ---- REPETITION: same action token in >1 step ----
    where={}
    for pn,d in ACTIONS.items():
        for a in d["actions"]:
            where.setdefault(a,[]).append(pn)
    reps={a:sorted( v,key=key) for a,v in where.items() if len(v)>1}

    # split into set_up (real duplicate concern) vs other repeats
    setup_reps={a:v for a,v in reps.items() if a.startswith("set_up:")}
    other_reps={a:v for a,v in reps.items() if not a.startswith("set_up:")}

    print("="*70)
    print("SEMANTIC REPETITION  (same action in more than one step)")
    print("="*70)
    print("\n-- SET-UP done more than once  (likely REAL duplicates) --")
    if setup_reps:
        for a,v in sorted(setup_reps.items()):
            locs=", ".join(f"P{p}.{s}" for p,s in v)
            print(f"  {a:22} -> {locs}")
    else:
        print("  none")
    print("\n-- other repeated actions  (often intentional: reuse / harder level) --")
    for a,v in sorted(other_reps.items()):
        locs=", ".join(f"P{p}.{s}" for p,s in v)
        print(f"  {a:26} -> {locs}")

    # ---- PREREQ: action needs a capability set up only later ----
    setup_at={}
    for pn,d in ACTIONS.items():
        for a in d["actions"]:
            if a.startswith("set_up:"):
                setup_at.setdefault(a, []).append(pn)
    print("\n"+"="*70)
    print("PREREQUISITE  (a step needs a tool set up only in a LATER step)")
    print("="*70)
    problems=[]
    for pn,d in sorted(ACTIONS.items(),key=lambda x:key(x[0])):
        for a in d["actions"]:
            cap=REQUIRES.get(a)
            if not cap: continue
            setup_tok=SETUP_FOR.get(cap)
            if not setup_tok: continue
            locs=setup_at.get(setup_tok,[])
            earlier=[x for x in locs if key(x)<=key(pn)]
            later=[x for x in locs if key(x)>key(pn)]
            if not earlier:
                if later:
                    first=min(later,key=key)
                    problems.append((pn,a,cap,f"set up later in P{first[0]}.{first[1]}"))
                else:
                    problems.append((pn,a,cap,f"'{cap}' is never set up anywhere"))
    if problems:
        for pn,a,cap,why in problems:
            print(f"  P{pn[0]}.{pn[1]}  action '{a}' needs '{cap}' -- {why}")
    else:
        print("  none")

    print("\n"+"="*70)
    print("NOTE: action lists are a human reading of each step, encoded above.")
    print("Edit ACTIONS / REQUIRES and re-run if any is wrong.  (read-only, exit 0)")
    print("="*70)
    sys.exit(0)

if __name__ == "__main__":
    main()
