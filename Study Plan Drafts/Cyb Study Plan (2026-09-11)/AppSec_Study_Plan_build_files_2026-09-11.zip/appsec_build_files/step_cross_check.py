#!/usr/bin/env python3
"""
step_cross_check.py  —  READ-ONLY.  Never edits the plan; only reports.

Compares every step against every other step (N x N). With 60 steps that is
60 x 59 = 3540 ordered comparisons. For each ordered pair (A, B) it reports:

  REPETITION : A and B share a meaningful VERB+NOUN action
               (e.g. "install burp" in two steps, "write checklist" twice,
                the same named resource/room/book, the same lab set).
               ALL repetition is flagged — intentional or not — for you to judge.

  PREREQ     : B USES a tool/skill that A TEACHES, but B comes before A
               (used-before-taught, cross-phase or same-phase earlier step).

Matching keys on VERBS and NOUNS, not raw prose, so shared filler
("the", "PortSwigger", "notes") does not cause false hits. What it keys on and
what it cannot see are printed in the COVERAGE block at the end — a pass here is
"nothing keyed matched", not "the plan is proven clean".
"""
import re, sys
from itertools import permutations

RAW = open("appsec_content.py", encoding="utf-8").read()
ORDER = ["0","I","II","III","IV","V","VI","VII","VIII","IX"]
oi = {p:i for i,p in enumerate(ORDER)}
phases = [(m.start(), m.group(1)) for m in re.finditer(r'banner\("([0IVX]+)",', RAW)]
def phase_of(pos):
    cur="?"
    for s,ph in phases:
        if s<=pos: cur=ph
        else: break
    return cur

# ---- extract steps: phase, num, title, cleaned text -------------------------
def clean(t):
    t = re.sub(r"<[^>]+>", " ", t)
    t = t.replace("\\u2013","-").replace("\\u2014","-").replace("\\u2019","'").replace("\\u00b7"," ")
    t = re.sub(r'"\s*"', "", t)          # join adjacent string literals
    return re.sub(r"\s+", " ", t).lower()

STEPS = []
for m in re.finditer(r'step\("(\d+)"', RAW):
    st=m.start(); d=1; j=m.end()
    while d>0: d += (RAW[j]=='(')-(RAW[j]==')'); j+=1
    q = re.findall(r'"((?:[^"\\]|\\.)*)"', RAW[st:j])
    title = q[1] if len(q)>1 else ""
    STEPS.append({"phase":phase_of(m.start()), "num":q[0] if q else "?",
                  "title":clean(title).strip(), "text":clean(RAW[st:j]), "key":None})
for s in STEPS:
    s["key"] = (oi.get(s["phase"],99), s["num"])
def label(s): return f"Phase {s['phase']} step {s['num']}"

# ---- vocabularies (nouns/verbs the comparison keys on) ----------------------
TOOLS = ["burp suite","burp","zap","semgrep","bandit","snyk","hashcat","nmap",
         "wireshark","webgoat","juice shop","portswigger","tryhackme","docker",
         "git","flaws.cloud","collaborator","ffuf","gobuster","postman","linkedin"]
CONCEPTS = ["sql injection","cross-site scripting"," xss","csrf","ssrf","xxe",
            "idor","access control","business logic","deserialization","file upload",
            "path traversal","os command injection","server-side template injection",
            "jwt","oauth","authentication","authorization","cors","api testing",
            "web llm","threat model","stride","secrets","cryptography","networking"]
SETUP_VERBS = ["install","set up","setup","create a","create an","sign up","register",
               "download","configure"]
LEARN_VERBS = ["read ","complete the","work through","work the","study","review ",
               "learn","skim"]
DO_VERBS    = ["write","publish","build","exploit","scan","audit","deploy","draft",
               "record","present","apply","crack","map"]
NAMED = [ r"burp suite: the basics", r"http in detail", r"real-world bug hunting",
          r"alice and bob", r"wahh", r"web application hacker", r"hacking apis",
          r"pre-security", r"owasp top 10", r"professor messer", r"sy0-701",
          r"juice shop", r"webgoat" ]

SPECIFIC_TOOLS=["burp suite","burp","zap","semgrep","bandit","snyk","hashcat","nmap","wireshark","collaborator"]
def feats(text):
    tools    = {t for t in TOOLS if re.search(r"\b"+re.escape(t)+r"\b", text)}
    concepts = {c.strip() for c in CONCEPTS if re.search(r"\b"+re.escape(c.strip())+r"\b", text)}
    named    = {n for n in NAMED if re.search(n, text)}
    # actions: a verb with a tool/concept noun within ~35 chars AFTER it
    actions=set()
    for v in SETUP_VERBS+LEARN_VERBS+DO_VERBS:
        for mv in re.finditer(re.escape(v), text):
            window = text[mv.end():mv.end()+35]
            for n in tools|concepts:
                if re.search(r"\b"+re.escape(n)+r"\b", window):
                    actions.add((v.strip(), n))
    # setups: setup verb adjacent to a tool
    setups={(v.strip(),n) for (v,n) in actions if v.strip() in [x.strip() for x in SETUP_VERBS]}
    engaged={t for t in SPECIFIC_TOOLS if re.search(r"\b"+re.escape(t)+r"\b",text)
             and any(v in text for v in SETUP_VERBS+LEARN_VERBS)}
    return {"tools":tools,"concepts":concepts,"named":named,"setups":setups,"actions":actions,"engaged":engaged}

for s in STEPS: s["f"]=feats(s["text"])

# teach vs use, per tool/concept, for the prereq pass
def teaches(s, thing):
    return thing in s["f"]["tools"]|s["f"]["concepts"] and \
           any(v in s["text"] for v in SETUP_VERBS+LEARN_VERBS)
def uses(s, thing):
    # "uses" = referenced in a DO action or a lab/exploit context
    return thing in s["f"]["tools"]|s["f"]["concepts"] and \
           any(v in s["text"] for v in DO_VERBS+["lab","labs"])

rep_hits=[]; pre_hits=[]
seen_pair=set()
for a, b in permutations(STEPS, 2):
    pairid = tuple(sorted([label(a),label(b)]))
    if pairid not in seen_pair:
        shared_setup   = a["f"]["setups"] & b["f"]["setups"]
        shared_named   = a["f"]["named"]  & b["f"]["named"]
        shared_action  = a["f"]["actions"]& b["f"]["actions"]
        shared_engage  = a["f"]["engaged"] & b["f"]["engaged"]
        if shared_setup or shared_named or shared_action or shared_engage:
            seen_pair.add(pairid)
            why=[]
            if shared_setup:  why.append("same setup: "+", ".join(f"{v} {n}" for v,n in sorted(shared_setup)))
            if shared_named:  why.append("same resource: "+", ".join(sorted(shared_named)))
            if shared_action: why.append("same action: "+", ".join(f"{v} {n}" for v,n in sorted(shared_action))[:120])
            if shared_engage: why.append("both set up/learn same tool: "+", ".join(sorted(shared_engage)))
            rep_hits.append((pairid, why))

# PREREQ done per using-step, not per pair: a thing is a violation only if it is
# taught ONLY later (no step at or before the using step teaches it).
for b in STEPS:
    for thing in b["f"]["tools"]|b["f"]["concepts"]:
        if not uses(b, thing): continue
        taught_before = any(teaches(x,thing) and x["key"]<=b["key"] for x in STEPS)
        taught_after  = [x for x in STEPS if teaches(x,thing) and x["key"]>b["key"]]
        if not taught_before and taught_after:
            first_after=min(taught_after,key=lambda x:x["key"])
            pre_hits.append((label(b), label(first_after), thing))

# ---- report -----------------------------------------------------------------
print("="*74)
print(f"STEP CROSS-CHECK  —  {len(STEPS)} steps, {len(STEPS)*(len(STEPS)-1)} ordered comparisons")
print("="*74)

print(f"\n---- REPETITION  ({len(rep_hits)} step-pairs share a verb+noun action) ----\n")
for (x,y), why in sorted(rep_hits):
    print(f"  {x}  <->  {y}")
    for w in why: print(f"       - {w}")

print(f"\n---- PREREQ: used-before-taught  ({len(set(pre_hits))} found) ----\n")
for b,a,thing in sorted(set(pre_hits)):
    print(f"  {b}  USES '{thing}'  but it is taught later in {a}")
if not pre_hits: print("  none")

print("\n"+"="*74)
print("COVERAGE  (keys on these; blind to the rest)")
print("="*74)
print("  keyed VERBS : setup(install/set up/create/download/configure), learn(read/")
print("                complete/work/study/review/skim), do(write/build/exploit/scan/")
print("                audit/deploy/crack/map/...)")
print("  keyed NOUNS : tools, vuln/skill concepts, named books/rooms (lists in-file)")
print("  BLIND TO    : repetition phrased with words not in these lists; intent")
print("                (all repetition flagged, incl. deliberate practice); whether a")
print("                repeat is bad or fine (that judgment is yours); prose nuance")
print("  NOTE        : a pair listed under REPETITION may be intentional. Judge each.")
