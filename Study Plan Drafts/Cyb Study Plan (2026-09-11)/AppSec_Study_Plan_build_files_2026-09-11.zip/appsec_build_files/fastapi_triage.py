#!/usr/bin/env python3
"""
fastapi_triage.py  —  part of the AppSec study-plan build toolkit.

Decides, for every remaining FastAPI docs section, exactly ONE of two outcomes:

    TRANSCRIBE   — read the section in full and transcribe it into note cards.
                   Some TRANSCRIBE sections are additionally flagged IMPLEMENT
                   (build it in the practice API), because for those the only
                   way to own the "why" is to wire it up. IMPLEMENT is not a
                   separate tier — it is a TRANSCRIBE section with a build step.
    SKIP         — do not study now; reference material, looked up if ever needed.

There is deliberately NO middle "skim / read-but-don't-note" tier. The learner
transcribes everything worth reading and skips everything else. Anything that
would only merit a skim is not worth the transcription cost, so it is a SKIP.

────────────────────────────────────────────────────────────────────────────────
INPUTS ENCODED (all discussed and agreed with the learner — nothing invented):

  • INTERVIEWER EXPECTATIONS — tests the SEAMS of the system: layer boundaries,
    request flow, failure modes; can you answer what / why / where-it-bites and
    articulate trade-offs both directions. Buys depth + honesty over coverage.
  • INTERVIEWER EXPERIENCE — senior dev, strong on architecture/design, DDD,
    testing-in-CI, framework-vs-custom judgment; has seen many mid-levels who
    "forgot how to code from too much code."
  • LEARNER'S EXPECTATIONS OF SELF — close the foundational gaps a 4.5-yr dev
    should have but skipped as a pattern-matcher: DI internals, testing, layer
    design, request flow. "I don't want to leave with missing knowledge."
  • LEARNER'S STATED VIEWPOINT — transcription is non-negotiable and slow; wants
    a real three-way... no — a real TWO-way split (transcribe / skip), no skim;
    won't skip things genuinely worth learning; doesn't have infinite time.
  • INTERVIEWER PERSONALITY — hard-but-fair, allergic to cargo-culting, direct,
    warm underneath, rewards honesty about the edges of knowledge.
  • BEST USE OF TIME — every TRANSCRIBE section must earn its transcription cost;
    total must fit the learner's real tracked pace.
  • ACTUAL MID-LEVEL EXPECTATIONS (2026 market research) — security is table
    stakes (auth, authz/scopes, CORS, secrets, headers, injection); testing with
    mocked dependencies is an explicit interview question; the #1 differentiator
    is trade-off articulation ("go deep on a few, name failure modes + cost").

────────────────────────────────────────────────────────────────────────────────
METHOD:
  Each section scored 0-3 on four criteria, weighted, summed (max 30). A single
  cutoff splits TRANSCRIBE from SKIP. An IMPLEMENT flag (set per section, not by
  score) marks TRANSCRIBE sections where building it is the point. Time is then
  costed against the learner's tracked pace so the plan fits finite time.
"""

# ─────────────────────────────────────────────────────────────────────────────
# LEARNER PACE  (from the study tracker — edit if the real cadence changes)
# ─────────────────────────────────────────────────────────────────────────────
HRS_PER_DAY         = 5     # sustainable focused hours/day (post-rescale target)
DAYS_PER_WEEK       = 5     # study days/week  → 25 h/wk target
DEMONSTRATED_HRS_WK = 20    # actual logged average from the tracker (full weeks
                            # ran 17-24 h; ~20 is the honest sustained rate)

# ─────────────────────────────────────────────────────────────────────────────
# RUBRIC  (each criterion 0-3; weights favor security / gaps / signal over
#          raw usage frequency, per the interviewer lens above)
# ─────────────────────────────────────────────────────────────────────────────
W_GAP, W_SEC, W_SIGNAL, W_USE = 3.0, 3.0, 2.5, 1.5
MAX = 3 * (W_GAP + W_SEC + W_SIGNAL + W_USE)      # = 30.0

TRANSCRIBE_MIN = 14.0   # score >= → TRANSCRIBE ;  below → SKIP.  (single cutoff)

# time model (hours). transcription roughly doubles plain reading; sizes S/M/L.
T_READ_TRANSCRIBE = {"S": 1.0, "M": 2.0, "L": 3.5}
T_IMPLEMENT       = {"S": 1.0, "M": 1.5, "L": 2.0}

# ─────────────────────────────────────────────────────────────────────────────
# SECTIONS  (name, size, gap, sec, signal, use, implement?, why)
#   Only sections from the learner's current position (Simple OAuth2) onward.
#   scores 0-3.  implement=True ⇒ TRANSCRIBE section that also gets built.
# ─────────────────────────────────────────────────────────────────────────────
S, M, L = "S", "M", "L"
SECTIONS = [
 # ---- Tutorial (remaining) --------------------------------------------------
 ("Simple OAuth2 (Password + Bearer)",   L,3,3,3,3,True,  "the login flow that issues the token; core auth seam"),
 ("OAuth2 + hashing + JWT",              L,3,3,3,3,True,  "password hashing + signed tokens; foundation of the JWT article & Phase III attacks"),
 ("Middleware",                          M,2,3,2,2,True,  "request/response interception; its own finding category"),
 ("CORS",                                S,1,3,2,2,True,  "misconfigured CORS is a constant real-world finding"),
 ("SQL (Relational) Databases",          L,3,3,3,3,True,  "session lifecycle + where injection enters; ties DB work to the framework"),
 ("Bigger Applications (APIRouter)",     M,3,1,3,3,True,  "app structure & layer responsibility — the design gap you named"),
 ("Stream JSON Lines",                   S,0,0,0,0,False, "niche streaming format; reference only"),
 ("Server-Sent Events (SSE)",            S,0,0,1,0,False, "niche real-time transport; out of scope"),
 ("Background Tasks",                    S,1,1,1,2,False, "common pattern; not gap-closing or security-critical enough to transcribe"),
 ("Metadata and Docs URLs",              S,0,1,1,1,False, "small; look up when locking down docs in prod"),
 ("Frontend",                            S,0,0,0,0,False, "not relevant to a back-end/AppSec path"),
 ("Static Files",                        S,0,1,1,1,False, "small serving surface; reference"),
 ("Testing",                             M,3,2,3,3,True,  "you flagged this yourself; a 4.5-yr dev is expected to own it"),
 ("Debugging",                           S,1,1,2,2,True,  "follow the debugger attach in terminal/VSCode hands-on; a real skill to run"),
 # ---- Advanced --------------------------------------------------------------
 ("Stream Data",                         S,0,0,0,0,False, "niche streaming; reference"),
 ("Path Op Advanced Configuration",      S,0,0,1,1,False, "rare OpenAPI tuning"),
 ("Additional Status Codes",             S,0,1,1,1,False, "minor extension of what you know"),
 ("Return a Response Directly",          S,1,1,1,1,False, "escape hatch past serialization; look up if needed"),
 ("Custom Response (HTML/File/…)",       S,0,1,1,1,False, "know the response types exist; reference"),
 ("Additional Responses in OpenAPI",     S,0,0,0,0,False, "docs-cosmetic"),
 ("Response Cookies",                    S,1,3,2,2,True,  "the SETTING half of cookies; auth-relevant, pairs with cookie reading"),
 ("Response Headers",                    S,1,3,2,2,True,  "where security headers (HSTS, CSP) live"),
 ("Response - Change Status Code",       S,0,0,1,1,False, "small mechanism; reference"),
 ("Advanced Dependencies",               S,2,1,2,1,True,  "parameterized deps; extends your DI gap-closing"),
 ("Advanced Security → OAuth2 scopes",   M,2,3,3,2,True,  "authorization / least-privilege — the layer above authentication"),
 ("Advanced Security → HTTP Basic Auth", S,0,1,1,1,False, "obsolete scheme; know it exists & why it's weak — real auth already done via OAuth2/JWT"),
 ("Using the Request Directly",          S,1,2,1,1,False, "raw-request escape hatch; reference"),
 ("Using Dataclasses",                   S,0,0,0,0,False, "you'll use Pydantic, not dataclasses"),
 ("Advanced Middleware",                 S,1,2,1,1,False, "the extra middleware page; reference"),
 ("Sub Applications - Mounts",           S,0,0,1,0,False, "uncommon architecture; reference"),
 ("Behind a Proxy",                      S,1,2,2,1,False, "X-Forwarded-For spoofing; real-deploy security concern"),
 ("Templates",                           S,0,2,1,1,False, "SSTI/XSS surface if you touch server-side rendering"),
 ("WebSockets",                          S,0,0,1,0,False, "different protocol; out of scope now"),
 ("Lifespan Events",                     S,1,0,1,1,False, "startup/shutdown hooks; reference"),
 ("Testing WebSockets",                  S,0,0,0,0,False, "depends on WebSockets"),
 ("Testing Events",                      S,0,0,0,0,False, "narrow testing edge case"),
 ("Testing Dependencies w/ Overrides",   S,3,1,3,3,True,  "mocking deps in tests — the exact 2026 interview question"),
 ("Async Tests",                         S,0,0,1,1,False, "reach for it only when you have async to test"),
 ("Settings & Environment Variables",    M,2,3,2,3,True,  "secrets management — market table-stakes & your own repo gap"),
 ("OpenAPI Callbacks",                   S,0,0,0,0,False, "rare integration feature"),
 ("OpenAPI Webhooks",                    S,0,0,0,0,False, "rare integration feature"),
 ("Including WSGI (Flask/Django)",       S,0,0,0,0,False, "migration/interop; not your case"),
 ("Generating SDKs",                     S,0,0,0,0,False, "tooling nicety; reference"),
 ("Advanced Python Types",               S,1,0,1,1,False, "sharpens typing; not worth transcription"),
 ("JSON with Bytes as Base64",           S,0,0,0,0,False, "narrow edge case"),
 ("Strict Content-Type Checking",        S,1,3,2,2,True,  "content-type confusion is a real API attack; hardening you can exercise in code"),
]

# Reference-only doc trees (never study material, listed for completeness)
REFERENCE = ["Deployment (all)", "How-To / Recipes (all)", "Reference (all)",
             "Resources (all)", "About (all)"]

# ─────────────────────────────────────────────────────────────────────────────
def score(gap, sec, sig, use):
    return W_GAP*gap + W_SEC*sec + W_SIGNAL*sig + W_USE*use

def outcome(sc, impl):
    if sc >= TRANSCRIBE_MIN:
        return "TRANSCRIBE + IMPLEMENT" if impl else "TRANSCRIBE"
    return "SKIP"

def cost(out, size, impl):
    if out == "SKIP":
        return 0.0
    h = T_READ_TRANSCRIBE[size]
    if impl:
        h += T_IMPLEMENT[size]
    return h

def main(done=None):
    done = set(done or [])
    rows = []
    for name, size, gap, sec, sig, use, impl, why in SECTIONS:
        if name in done:
            continue
        sc  = score(gap, sec, sig, use)
        out = outcome(sc, impl)
        rows.append((out, sc, name, size, cost(out, size, impl), why))

    order = {"TRANSCRIBE + IMPLEMENT": 0, "TRANSCRIBE": 1, "SKIP": 2}
    rows.sort(key=lambda r: (order[r[0]], -r[1]))
    bucket = {}
    for out, sc, name, size, h, why in rows:
        bucket.setdefault(out, []).append((sc, name, size, h, why))

    print("=" * 80)
    print("  FASTAPI SECTION TRIAGE  —  from current position (Simple OAuth2) onward")
    print(f"  two outcomes only: TRANSCRIBE (score >= {TRANSCRIBE_MIN:.0f}) or SKIP.  max score {MAX:.0f}")
    print(f"  '+ IMPLEMENT' = a TRANSCRIBE section you also build in the API.")
    if done:
        print(f"  already completed (excluded): {', '.join(sorted(done))}")
    print("=" * 80)

    labels = {
        "TRANSCRIBE + IMPLEMENT": "TRANSCRIBE + IMPLEMENT  (read fully, note cards, build it in the API)",
        "TRANSCRIBE":             "TRANSCRIBE              (read fully, note cards)",
        "SKIP":                   "SKIP                    (reference only, not studied now)",
    }
    for out in ("TRANSCRIBE + IMPLEMENT", "TRANSCRIBE", "SKIP"):
        items = bucket.get(out, [])
        th = sum(i[3] for i in items)
        head = f"\n── {labels[out]}   [{len(items)} sections"
        head += f", ~{th:.1f} h] " if out != "SKIP" else "] "
        print(head + "─" * 6)
        for sc, name, size, h, why in items:
            tag = f"{h:.1f}h" if h else " —  "
            print(f"   [{sc:4.1f}] {tag:>5}  {name}")
            print(f"                 └ {why}")

    print("\n── REFERENCE ONLY (look-up, never studied front-to-back) " + "─" * 12)
    for r in REFERENCE:
        print(f"          {r}")

    total = sum(i[3] for out in ("TRANSCRIBE + IMPLEMENT", "TRANSCRIBE")
                       for i in bucket.get(out, []))
    ti = sum(i[3] for i in bucket.get("TRANSCRIBE + IMPLEMENT", []))
    tr = sum(i[3] for i in bucket.get("TRANSCRIBE", []))
    nskip = len(bucket.get("SKIP", []))
    print("\n" + "=" * 80)
    print("  TIME BUDGET  (remaining FastAPI only)")
    print("=" * 80)
    print(f"   transcribe + implement : {ti:5.1f} h")
    print(f"   transcribe             : {tr:5.1f} h")
    print(f"   ───────────────────────────────")
    print(f"   TOTAL                  : {total:5.1f} h")
    wk = HRS_PER_DAY * DAYS_PER_WEEK
    print(f"\n   at target pace  ({HRS_PER_DAY} h/day x {DAYS_PER_WEEK} d/wk = {wk} h/wk):"
          f"  {total/HRS_PER_DAY:.1f} study-days  (~{total/wk:.1f} wks)")
    print(f"   at tracked pace ({DEMONSTRATED_HRS_WK} h/wk actual):"
          f"          ~{total/DEMONSTRATED_HRS_WK:.1f} wks")
    print(f"\n   sections skipped entirely: {nskip}  (zero transcription cost)")
    print("=" * 80)

if __name__ == "__main__":
    # sections already finished — excluded from the remaining budget
    ALREADY_DONE = ["Simple OAuth2 (Password + Bearer)", "OAuth2 + hashing + JWT"]
    main(done=ALREADY_DONE)
