#!/usr/bin/env python3
"""
mentor_check.py — asserts the plan contains NO mentor references, direct or not.

The plan dropped paid 1:1 mentorship (community/events cover networking instead).
A plain grep for "mentor" is not enough: the old section also described a mentor
*without* the word — "someone to tell you whether your findings are right", "mock
code review sessions", the MentorCruise platform/URL, per-month mentorship cost,
etc. This test checks the literal token AND those indirect fingerprints, so a
future edit can't reintroduce the concept under different wording.

Exit 0 if clean, 1 if any reference survives.
"""
import re, sys

TEXT = open("appsec_content.py", encoding="utf-8").read()
flat = re.sub(r"\s+", " ", TEXT)          # collapse whitespace for phrase matching
low  = flat.lower()

# 1) literal token (mentor, mentorship, mentoring, MentorCruise, ...)
literal = [m.start() for m in re.finditer(r"(?i)mentor", TEXT)]

# 2) the platform, by URL/brand even if "mentor" were obfuscated
brand = []
for pat in (r"mentorcruise", r"mentor\s*cruise", r"mentor-cruise"):
    brand += [m.start() for m in re.finditer(pat, low)]

# 3) indirect fingerprints — phrases from the old mentorship section that
#    describe a paid human mentor WITHOUT using the word "mentor".
INDIRECT = [
    "someone to tell you whether your",          # "...findings are the right findings"
    "ships appsec work professionally",
    "mock code review session",
    "one session upfront to review this plan",
    "monthly check-ins at phase transitions",
    "7-day trial lets you test fit",
    "highest-roi expenditure in the plan",
    "human mentorship",
    "$100-$150/month",                            # the mentorship cost line
]
indirect_hits = [phrase for phrase in INDIRECT if phrase in low]

fails = []
if literal:
    ctx = TEXT[literal[0]:literal[0]+40].replace("\n", " ")
    fails.append(f"literal 'mentor' x{len(literal)} (first: …{ctx}…)")
if brand:
    fails.append(f"MentorCruise brand/URL x{len(brand)}")
if indirect_hits:
    fails.append("indirect mentor phrasing: " + "; ".join(repr(p) for p in indirect_hits))

if fails:
    print("MENTOR CHECK FAILED:")
    for f in fails:
        print("   ✗ " + f)
    sys.exit(1)

print("PASS - no mentor references (literal, brand, or indirect phrasing).")
sys.exit(0)
