#!/usr/bin/env python3
"""
phase_partition_check.py — enforces that the plan's phases are STRICTLY
SEQUENTIAL with no two phases ever sharing a week, and no gaps.

This exists because a study plan is a calendar: if week 2 appears in both
Phase 0 and Phase I, the reader cannot tell which phase they should be in.
Phases must partition the timeline — each week belongs to exactly one phase,
and the phases run back-to-back (phase N ends on the week before phase N+1
begins).

Checks, against BOTH the phase banners and the individual step tags:
  1. no week is claimed by more than one phase   (no overlap)
  2. phase week-ranges are contiguous            (no gap)
  3. every step's week falls inside its phase     (steps stay in their phase)

Exit 0 if the partition is clean, 1 otherwise.
"""
import re, sys

ORDER = ['0','I','II','III','IV','V','VI','VII','VIII','IX']

def weeks(tag):
    """Set of week numbers named in a timing string. 'Day N' tags return empty
       (day-level parallel tracks inside a phase are not week claims)."""
    t = tag.replace('\\u2013','-').replace('\u2013','-')
    out = set()
    for m in re.finditer(r'\bWeeks?\s+(\d+)(?:\s*-\s*(\d+))?', t):
        a = int(m.group(1)); b = int(m.group(2)) if m.group(2) else a
        out |= set(range(a, b+1))
    return out

def load(path="appsec_content.py"):
    L = open(path, encoding="utf-8").read().split("\n")
    ph = None; banner = {}; steps = {}
    for l in L:
        m = re.search(r'banner\("([0IVX]+)", "[^"]*", "([^"]*)"', l)
        if m:
            ph = m.group(1); banner[ph] = m.group(2)
        s = re.search(r'step\("(\d+)", (?:"[^"]*"|\'.*?\'), "([^"]+)",', l)
        if s and ph is not None:
            steps.setdefault(ph, []).append((s.group(1), s.group(2)))
    return banner, steps

def main():
    banner, steps = load()
    fails = []

    # 1 + 2: banner partition
    owner = {}
    ranges = {}
    for p in ORDER:
        w = weeks(banner.get(p, ""))
        ranges[p] = w
        for wk in w:
            if wk in owner:
                fails.append(f"week {wk} claimed by BOTH phase {owner[wk]} and phase {p}")
            owner[wk] = p
    if owner:
        lo, hi = min(owner), max(owner)
        missing = [w for w in range(lo, hi+1) if w not in owner]
        if missing:
            fails.append(f"gap in coverage — weeks not owned by any phase: {missing}")

    # 3: each step inside its phase's banner range (skip phases whose banner has
    #    no week range, e.g. a purely Day-N phase, and skip Day-N step tags)
    for p in ORDER:
        pr = ranges.get(p, set())
        if not pr:
            continue
        lo, hi = min(pr), max(pr)
        for num, tag in steps.get(p, []):
            sw = weeks(tag)
            outside = [w for w in sw if not (lo <= w <= hi)]
            if outside:
                fails.append(f"phase {p} step {num}: week(s) {outside} fall outside phase range {lo}-{hi}")

    if fails:
        print(f"PARTITION FAILED — {len(fails)} issue(s):")
        for f in fails:
            print("  " + f)
        sys.exit(1)

    span = f"{min(owner)}-{max(owner)}" if owner else "?"
    print(f"PASS - phases partition weeks {span} with no shared week and no gap.")
    for p in ORDER:
        r = sorted(ranges.get(p, []))
        lbl = f"{r[0]}" if len(r)==1 else (f"{r[0]}-{r[-1]}" if r else "—")
        print(f"    Phase {p:<4} weeks {lbl}")
    sys.exit(0)

if __name__ == "__main__":
    main()
