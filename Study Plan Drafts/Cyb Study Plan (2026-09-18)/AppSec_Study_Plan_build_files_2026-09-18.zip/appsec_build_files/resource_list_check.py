"""V115 rule (user, 2026-09-18): a resource linked in a step bullet must also be in that phase's resource list.
Report-only for now: prints step-link hosts that no res() entry of the same phase mentions."""
import re,sys
s=open("appsec_content.py",encoding="utf-8").read()
# phases start at each PHASE heading call; split on the first res( after a phase banner
marks=[m.start() for m in re.finditer(r'\n    SS\("Learning Resources"\)',s)]
assert len(marks)>=7,len(marks)
marks.append(len(s)); miss=0
for i in range(len(marks)-1):
    blk=s[marks[i]:marks[i+1]]
    resblk=blk[:blk.find("step(")]
    steps=" ".join(re.findall(r'step\((.*?)\]\)',blk,re.S))
    hosts=set(re.findall(r'href=\\"https?://(?:www\.)?([^/\\"]+)',steps))
    for h in sorted(hosts):
        if h not in resblk:
            miss+=1; print(f"phase block {i}: step links {h}, no resource entry mentions it")
print("resource_list_check:",miss,"host(s) missing")
