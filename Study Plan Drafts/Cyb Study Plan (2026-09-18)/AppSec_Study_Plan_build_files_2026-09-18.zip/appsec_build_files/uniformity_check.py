"""uniformity_check.py - the same kind of thing is written the same way everywhere (built 2026-09-18).

Why it exists: fixes were checked one bullet at a time, so a new insert could differ from how the rest of the plan
writes the same thing (lab lists, lab-notes instructions). This gate reads the WHOLE source after every change.

  U1  a PortSwigger lab is always a title link (never an italic or plain title) and sits in a lab list
      (a nested [[li]] list, or an inline list introduced by "the following lab(s)").
  U2  every step sentence that mentions lab notes links to the Lab Notes Format entry.
  U3  a nested list has a lead that ends with ":"; an inline lab list of 4+ labs should be nested.
  INFO  the distinct wordings used for list leads and for lab-notes instructions, with counts, so drift is visible.
Exit 1 on any U1-U3 finding.  Usage: python3 uniformity_check.py [appsec_content.py]
"""
import re, sys, collections
src = open(sys.argv[1] if len(sys.argv) > 1 else "appsec_content.py", encoding="utf-8").read()
src1 = re.sub(r'"\s*\n\s*"', "", src)                       # join adjacent string literals
LAB = r'href=\\"(https://portswigger\.net/web-security/[^"\\]*/lab-[^"\\]*)\\"'
flat = lambda t: re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", t.replace('\\"', '"').replace("\\u2014", "\u2014").replace("\\u2019", "\u2019"))).strip()
items = re.findall(r'^\s*"(.*)",?\s*$', src1, flags=re.M)
bad = []; leads = collections.Counter(); notes = collections.Counter()
for it in items:
    n = len(re.findall(LAB, it)); f = flat(it)
    if n:
        listed = "[[li]]" in it or re.search(r"following labs?\b", it)
        if not listed: bad.append(("U1", "lab link outside a lab list", f[:150]))
        if "[[li]]" not in it and n >= 4: bad.append(("U3", f"inline list of {n} labs should be nested", f[:150]))
        m = re.search(r"(then|the)\s+((?:\w+\s+){0,3}?the following labs?)", f)
        if m: leads[m.group(2)] += 1
    if "[[li]]" in it and not re.search(r":\s*$", flat(it.split("[[")[0])): bad.append(("U3", "nested list lead does not end with ':'", f[:150]))
    for m in re.finditer(r"<i>([^<]{12,})</i>", it):
        if re.search(r"^(Blind |Exploiting |SQL injection|SSRF |Web |Reflected |Stored |DOM |Forced |Brute-forcing |Discovering |HTTP request )", m.group(1)):
            bad.append(("U1", "lab title in italics with no link", m.group(1)[:90]))
    if re.search(r"\blab notes\b", f, flags=re.I) and "lab_notes_format" not in it and 'a name=' not in it:
        bad.append(("U2", "lab notes mentioned without the Lab Notes Format link", f[:150]))
    for m in re.finditer(r"(write|update|check that the) lab notes[^.,;]*", f, flags=re.I): notes[m.group(0).strip()[:70]] += 1
print("uniformity_check")
for b in bad: print("  FAIL", b[0], "|", b[1], "|", b[2])
print("  INFO list leads:", dict(leads))
print("  INFO lab-notes wordings:", dict(notes))
print(f"RESULT: {len(bad)} finding(s)")
sys.exit(1 if bad else 0)
