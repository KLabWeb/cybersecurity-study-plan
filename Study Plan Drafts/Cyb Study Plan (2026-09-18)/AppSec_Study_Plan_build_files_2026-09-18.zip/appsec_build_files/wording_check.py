"""wording_check.py - wording rules for PROPOSED plan text (built 2026-09-18).

Why it exists: render and link checks passed text that still broke the plan's wording rules (singular "note",
"reuse", a written reference beside a hyperlink, file formats in parentheses, a link missing on one of several
mentions). Those rules lived only in a checklist; a checklist can be skipped, a gate cannot.

Use:  check(new_text, old_text="", new_source="")  ->  list of (rule, where, message)
      NEW words (in new_text, not in old_text) get every rule. KEPT words get the "whole bullet" rules,
      because a fix that touches a bullet owns the whole bullet.
      consistency(texts) -> warnings when the same term is linked in some proposed texts and not in others.
A warning is cleared by changing the text, or by an explicit acknowledgement string "RULE:word" passed in ok=.
Run on its own:  python3 wording_check.py "<new text>" ["<old text>"]
"""
import re, sys

# term -> what it must link to when it is mentioned in step or intro text
LINK_TERMS = {
    r"lab notes": "#lab_notes_format",
    r"Lab Notes Format": "#lab_notes_format",
    r"Application Strategy": "#application_strategy",
}
NEW_RULES = [
 ("NOTE-SINGULAR", r"\bnote\b(?!\s+cards?)(?!-)", 'write "notes" / "lab notes", never the singular'),
 ("REUSE",         r"\breus(e|es|ed|ing)\b", 'notes belong to a lab; a repeat "updates the notes if needed", nothing is "reused"'),
 ("REF-BESIDE-LINK", r"\b(in|from) the (Appendix|appendix|intro|introduction)\b|\bsee (the )?(Appendix|section|step|above|below)\b", "the hyperlink is the reference; drop the written pointer"),
 ("FORMAT-DETAIL", r"\((?:[^)]*\b(Markdown|plain text|PDF|\.md|\.odt|\.txt|spreadsheet)\b[^)]*)\)", "file formats are detail nobody needs (cut first)"),
 ("REMOVED-PHRASE", r"ready to paste|ready to use|\bquick(ly)?\b|\d+-minute|start to finish|slow down|sanity|\bmagic\b", "phrase the user already had removed elsewhere"),
 ("COUNT",         r"\b(two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|twenty|\d+)\b(?!\s*(?:\u2013|-)\s*\d)", "no exact counts unless the count is the instruction"),
 ("ABSOLUTE",      r"\b(each|every|all|any|only|most|always|never|exact|exactly|fully|complete|completely|entire|entirely|best|ideal|the main|the key|the primary)\b", "quiet absolute or uniqueness claim"),
 ("YOU",           r"\b(you|your|yours|you\u2019ll|you\u2019re)\b", "new text should not add you/your (V105)"),
 ("DASH",          r"\u2014| - ", "no dash used as punctuation in new text (V69)"),
 ("ADJECTIVE",     r"\b(short|simple|simply|just|really|very|basic|core|actual|actually|real|deep|deeply|focused|solid|key)\b", "adjective or adverb that may add nothing"),
 ("WHEEL",         r"\bfrom scratch\b|\bno templates?\b|\b(your|the plan\u2019s) own (format|structure|template)\b", "do not reinvent the wheel: use the standard form a resource teaches"),
 ("POINTER",       r"\((?:[^)]*\b(?:Phase [IVX0]+|step \d+)\b[^)]*)\)|\bfollows? in Phase [IVX]+|\bThe \w+ labs follow\b", "a pointer to another phase or step is detail nobody needs (cut first)"),
 ("WEEK",          r"\bWeeks?\s+\d", "no weeks in prose; name the phase or step"),
 ("VAGUE-QTY",     r"\b(some of|several|a few|a number of|various|roughly|about \d|approximately)\b", "vague quantity (V107)"),
 ("THE-OPENER",    r"(?:^|[.!?]\s+)The\s+[a-z]", '"The X" implies the only one; use a/an when it is one of several'),
 ("META-REF",      r"\b(linked|link to|links to|as mentioned|as noted|as described)\b", "talks about the link or the text instead of just linking"),
]
KEPT_RULES = ["REF-BESIDE-LINK", "FORMAT-DETAIL", "REMOVED-PHRASE", "VAGUE-QTY", "POINTER", "WHEEL"]
NON_ACTION_OPENERS = r"^(The|This|These|Those|It|A|An|There|Its|Their|Because|Since|While)\b"

def _words(t): return re.findall(r"[\w\u2019'-]+", t.lower())
def _plain(src): return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", src.replace('\\"', '"')))

def check(new_text, old_text="", new_source="", is_bullet=False, ok=()):
    out = []; oldw = set(_words(old_text))
    strip_urls = lambda t: re.sub(r'(?:https?://|\b(?:[\w-]+\.)+(?:com|org|net|io|dev)/)\S+', '', re.sub(r'\]\([^)\s]*\)', ']', t))   # rules judge WORDS, never the characters inside a URL
    full_new = new_text; new_text = strip_urls(new_text); old_text = strip_urls(old_text)
    for name, pat, msg in NEW_RULES:
        for m in re.finditer(pat, new_text, flags=re.I if name not in ("THE-OPENER",) else 0):
            hit = m.group(0).strip(); kept = hit.lower() in old_text.lower() and new_text.lower().count(hit.lower()) <= old_text.lower().count(hit.lower())   # KEPT = the old text has it at least as often
            if kept and name not in KEPT_RULES: continue
            tag = f"{name}:{hit.lower()}"
            if tag in ok: continue
            out.append((name, "KEPT TEXT" if kept else "new text", f'"{hit}" - {msg}'))
    src = new_source or new_text
    for term, target in LINK_TERMS.items():
        for m in re.finditer(term, _plain(src) if new_source else full_new):
            linked = re.search(r'<a href=\\?"' + re.escape(target) + r'[^>]*>[^<]*' + term, src) or re.search(r"\[[^\]]*" + term + r"[^\]]*\]\(" + re.escape(target), src)
            defines = re.search(r'<a name=\\?"' + re.escape(target[1:]), src)
            if not linked and not defines and f"LINK:{term.lower()}" not in ok:
                out.append(("LINK", "new text", f'"{m.group(0)}" is mentioned without a link to {target}')); break
    if is_bullet and re.search(NON_ACTION_OPENERS, new_text.strip()) and "ACTION" not in ok:
        out.append(("ACTION", "new text", f'bullet opens with "{new_text.strip().split()[0]}"; step bullets start from an action (V109)'))
    return out

def consistency(items):
    """items = [(label, new_text, new_source)]. Same term must be linked everywhere or nowhere."""
    out = []
    for term, target in LINK_TERMS.items():
        state = {}
        for label, text, src in items:
            s = src or text
            if re.search(r'<a name=\\?"' + re.escape(target[1:]), s): continue      # the text that DEFINES the anchor is exempt
            if re.search(term, _plain(s) if src else text):
                state[label] = bool(re.search(re.escape(target), s))
        if len(set(state.values())) > 1:
            out.append(("CONSISTENCY", "batch", f'"{term}" is linked in {[k for k,v in state.items() if v]} but not in {[k for k,v in state.items() if not v]}'))
    return out

if __name__ == "__main__":
    new = sys.argv[1] if len(sys.argv) > 1 else sys.stdin.read()
    old = sys.argv[2] if len(sys.argv) > 2 else ""
    w = check(new, old)
    print(f"wording_check: {len(w)} warning(s)")
    for r in w: print("  ", *r, sep=" | ")
    sys.exit(1 if w else 0)
