#!/usr/bin/env python3
"""
timeline_audit.py  --  INDEPENDENT third-party audit of the 35 hr/wk, 5-day
timeline rebuild.

Deliberately written from the OPPOSITE mindset to rebuild_timeline.py. The
rebuild script was a *forward transformer*: it assumed a 0.6 calendar factor,
a hand-built month map (SMAP), and round() for weeks. This auditor assumes
NONE of that. It never computes 0.6 or maps a single value forward. Instead it
verifies properties that must hold if the rebuild is correct, discovered from
the artifact itself and from a before/after diff against build-41:

  A. COMPRESSION RATIO COHERENCE - three independent quantities (study
     hours/wk, study days/wk, total-duration shrink) must imply the SAME
     speed-up factor. If the timeline was scaled inconsistently with the pace
     change, these disagree.
  B. CONTIGUITY / MONOTONICITY - re-derived from the phase-timeline bar alone.
  C. FOUR-WAY LABEL AGREEMENT - each phase's timing is written in four places
     (banner, schedule sub-head, phase-summary, timeline bar). All must agree;
     the rebuild touched them through four different code paths, so independent
     agreement proves none was missed or mis-scaled.
  D. STEP-IN-WINDOW - every week-tagged step must fall inside its phase's own
     month window. Catches a step scaled out of step with its phase.
  E. DIFFERENTIAL (build-41 -> now) - the don't-scale durations must be
     byte-identical old vs new; and no old-scale pace/boundary value may
     survive in the new doc.
  F. PLAN-END COHERENCE - the plan end implied by the last phase must equal
     the prose "outer bound" and the start of Phase IX; schedule days sum to 7.

Exit status: 0 if every hard check passes, 1 otherwise.
"""
import re, subprocess, sys
WEEKS_PER_MONTH = 365 / 12 / 7   # 4.345238095 calendar weeks per month (user decision 2026-09-17)

NEW = open("appsec_content.py", encoding="utf-8").read()
OLD = subprocess.run(["git", "show", "build-41:appsec_content.py"],
                     capture_output=True, text=True).stdout
if not OLD:
    print("could not load build-41 baseline"); sys.exit(2)

def norm(t):
    for a, b in (('\\u2013', '-'), ('\u2013', '-'), ('\\u2014', '-'),
                 ('\u2014', '-'), ('\\u2019', "'")):
        t = t.replace(a, b)
    return t

def span(timing):
    """Return (start_month, end_month, unit) for a timing label, or None.
       Weeks a-b -> months ((a-1)/WPM, b/WPM), WPM = 365/12/7. Months a-b -> (a, b). Day N -> None."""
    t = norm(timing)
    m = re.search(r'\b(Weeks?|Wks?)\s+([\d.]+)(?:\s*-\s*([\d.]+))?', t)
    if m:
        a = float(m.group(2)); b = float(m.group(3)) if m.group(3) else a
        return ((a - 1) / WEEKS_PER_MONTH, b / WEEKS_PER_MONTH, 'wk')
    m = re.search(r'\b(Months?|Mo)\s+([\d.]+)(?:\s*-\s*([\d.]+))?', t)
    if m:
        a = float(m.group(2)); b = float(m.group(3)) if m.group(3) else a
        return (a, b, 'mo')
    return None

FAIL, OKS = [], []
def ck(cond, msg):
    (OKS if cond else FAIL).append((("PASS " if cond else "FAIL ") + msg))

# ---- pull the four representations out of the NEW doc --------------------
banners = re.findall(r'banner\("([0IVX]+)", "[^"]*", "([^"]*)"', NEW)
summ    = re.findall(r'\((Wks?|Mo) ([^)]*)\)', NEW)
tlblock = re.search(r'weeks = \[(.*?)\]', NEW, re.S).group(1)
tlcells = re.findall(r'"([^"]*)"', tlblock)

ck(len(banners) == 10, f"exactly 10 phase banners (got {len(banners)})")
ck(len(summ)    == 10, f"exactly 10 phase-summary parentheticals (got {len(summ)})")
ck(len(tlcells) == 10, f"exactly 10 timeline-bar cells (got {len(tlcells)})")

# ---- CHECK C: four-way (here three indexed) agreement -------------------
for i, (rom, btim) in enumerate(banners):
    bs = span(btim)
    ss = span(summ[i][0] + " " + summ[i][1]) if i < len(summ) else None
    ts = span(tlcells[i]) if i < len(tlcells) else None
    ok = bool(bs and ss and ts) and \
         abs(bs[0]-ss[0]) < 0.02 and abs(bs[1]-ss[1]) < 0.02 and \
         abs(bs[0]-ts[0]) < 0.02 and abs(bs[1]-ts[1]) < 0.02
    ck(ok, f"phase {rom:>4}: banner=summary=timeline  "
           f"[{norm(btim).split(chr(183))[0].strip()} | {summ[i][0]} {summ[i][1]} | {tlcells[i]}]")

# ---- CHECK B: monotonic + contiguous ------------------------------------
sp = [span(t) for _, t in banners]
starts = [x[0] for x in sp]; ends = [x[1] for x in sp]
ck(all(starts[i] <= starts[i+1] + 0.02 for i in range(9)),
   "phase start months are monotonic non-decreasing")
ck(all(abs(ends[i] - starts[i+1]) < 0.02 for i in range(2, 9)),
   "month-based phases II->IX are contiguous (each end == next start)")

# ---- CHECK A: the CURRENT doc's pace figures are internally consistent ---
# (version-independent: hours/day may change between versions, so validate the
#  current doc against itself rather than differencing an old baseline.)
def hours_wk(x):
    m = re.search(r'at (\d+) study hours per week', x); return int(m.group(1)) if m else None
def days_wk(x):
    m = re.search(r'Long Study", S\["tc"\]\), P\("(\d+)"', x); return int(m.group(1)) if m else None
def hours_day(x):
    m = re.search(r'Long Study", S\["tc"\]\), P\("\d+", S\["tcc"\]\), P\("(\d+) hrs"', x)
    return int(m.group(1)) if m else None
def planend_weeks(x):
    cells = re.findall(r'"([^"]*)"', re.search(r'weeks = \[(.*?)\]', x, re.S).group(1))
    nums = re.findall(r'\d+', cells[-2])          # last STUDY phase (cell before IX)
    return int(nums[-1])
def outer_month(x):
    m = re.search(r'(\d+(?:\.\d+)?) months is the outer bound', x); return float(m.group(1))
hw, dw, hd = hours_wk(NEW), days_wk(NEW), hours_day(NEW)
ck(hw == dw * hd,
   f"pace internally consistent: {hw} hrs/week == {dw} days/week x {hd} hrs/day")
pe_wk = planend_weeks(NEW); ob = outer_month(NEW)
ck(abs(pe_wk/WEEKS_PER_MONTH - ob) < 0.3,
   f"plan end {pe_wk} wks (={pe_wk/WEEKS_PER_MONTH:.2f} mo) ~ stated outer bound {ob} months")
# plan-end in months (Phase IX start) — used by later boundary checks
pen = span(re.findall(r'"([^"]*)"', re.search(r'weeks = \[(.*?)\]', NEW, re.S).group(1))[-1])[0]

# ---- CHECK D: every week-tagged step inside its phase window ------------
bmap = {rom: span(t) for rom, t in banners}
ph = None; pw = None; checked = 0; viol = []
for l in NEW.split("\n"):
    b = re.search(r'banner\("([0IVX]+)"', l)
    if b: ph = b.group(1); pw = bmap[ph]
    st = re.search(r'step\("(\d+)", (?:"[^"]*"|\'[^\']*\'), "([^"]+)",', l)
    if st and pw:
        s = span(st.group(2))
        if s:
            checked += 1
            if not (pw[0] - 0.35 <= s[0] and s[1] <= pw[1] + 0.35):
                viol.append(f"{ph}/{st.group(1)} '{st.group(2)}' -> {s[0]:.2f}-{s[1]:.2f} vs phase {pw[0]:.2f}-{pw[1]:.2f}")
ck(not viol, f"all {checked} week-tagged steps fall within their phase window"
             + ("" if not viol else " :: " + "; ".join(viol)))

# ---- CHECK E: differential vs build-41 ----------------------------------
preserved = ["under 2 hours", "4 hours", "15 minutes", "30-45 minutes",
             "30 minutes"]   # "20 minutes" removed 2026-09-18 with the unverified "(about 20 minutes)" in Phase I step 04 (V85)   # "14 weeks of web dev" removed 2026-09-17 (V40 item 54); "14-day wait" removed 2026-09-18 with the Security+ Retakes bullet (V50 s16 fix 6)
for p in preserved:
    ck(p in norm(OLD) and p in norm(NEW), f"don't-scale duration preserved unchanged: '{p}'")
leftovers = ["21 study hours", "Work (Gigs)", "TOTAL STUDY",
             "7-9 months", "8 months is the realistic", "9 months is the outer bound"]
for lv in leftovers:
    ck(lv not in norm(NEW), f"no old-scale value leaked into new doc: '{lv}'")
# every month phase-timing must sit at or below the plan end
overs = [t for _, t in banners if span(t)[2] == 'mo' and span(t)[1] > pen + 0.02]
ck(not overs, f"no phase month-timing exceeds plan end {pen} ({overs})")

# ---- CHECK F: plan-end coherence ----------------------------------------
ob = re.search(r'([\d.]+) months is the outer bound', norm(NEW))
ck(bool(ob) and 0 <= float(ob.group(1)) - pen < 1.0,
   f"prose outer bound (whole months) covers plan end within one month ({ob.group(1) if ob else '?'} vs {pen:.2f})")
ck(abs(span(banners[9][1])[0] - pen) < 0.02,
   f"Phase IX begins exactly at plan end ({span(banners[9][1])[0]} vs {pen})")
so = re.search(r'Long Study", S\["tc"\]\), P\("(\d+)"', NEW)
off = re.search(r'Day Off", S\["tc"\]\), P\("(\d+)"', NEW)
ck(bool(so and off) and int(so.group(1)) + int(off.group(1)) == 7,
   f"schedule days sum to a 7-day week ({so.group(1) if so else '?'} study + {off.group(1) if off else '?'} off)")
ck(bool(so) and int(so.group(1)) == 5, "Long Study is 5 days/week")

# ---- report --------------------------------------------------------------
for line in OKS: print(" ", line)
print()
if FAIL:
    print(f"AUDIT FAILED - {len(FAIL)} issue(s):")
    for line in FAIL: print("  ", line)
    sys.exit(1)
print(f"AUDIT PASSED - {len(OKS)} independent checks, 0 failures.")
sys.exit(0)
