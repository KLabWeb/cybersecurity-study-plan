#!/usr/bin/env python3
"""V56 gate (2026-09-18): the plan's description of the user's own FastAPI application must
match the real repository, and must stay flexible.
 FAIL if the plan states an exact endpoint count ('5-6 endpoints', '30 endpoints', 'thirty endpoints').
 FAIL if the plan says 'dozens of endpoints' but the real count is under 24.
 WARN if the repository is reachable and its count differs from project_facts.json.
Exit 1 on any FAIL."""
import json, os, re, sys, glob
here = os.path.dirname(os.path.abspath(__file__))
facts = json.load(open(os.path.join(here, "project_facts.json")))["fastapi_app"]
src = open(os.path.join(here, "appsec_content.py"), encoding="utf-8").read()
src = src.replace("\\u2013", "–").replace("\\u2014", "—")
fails, warns = [], []
WORDS = r"(?:one|two|three|four|five|six|seven|eight|nine|ten|twenty|thirty|forty|fifty)"
for m in re.finditer(r"(?i)\b(?:about\s+|roughly\s+|~)?(?:\d+(?:\s*[–-]\s*\d+)?|" + WORDS + r")\s+endpoints\b", src):
    line = src.count("\n", 0, m.start()) + 1
    fails.append(f"exact endpoint count in the plan at line {line}: {m.group(0)!r} (use 'dozens of endpoints')")
count = facts["endpoint_count"]
repo = facts["repo_path"]
if os.path.isdir(repo):
    live = 0
    for f in glob.glob(os.path.join(repo, "src", "**", "*.py"), recursive=True):
        live += len(re.findall(r"@[A-Za-z_]+\.(?:get|post|put|patch|delete)\(", open(f, errors="ignore").read()))
    if live != count:
        warns.append(f"repository now has {live} endpoints; project_facts.json records {count} (update the facts file)")
    count = live
if re.search(r"(?i)dozens of endpoints", src) and count < 24:
    fails.append(f"plan says 'dozens of endpoints' but the application has {count}")
for w in warns: print("  WARN", w)
for f in fails: print("  FAIL", f)
print(f"project_facts_check: {'FAIL' if fails else 'PASS'} - {len(fails)} failure(s), {len(warns)} warning(s); endpoints counted: {count}")
sys.exit(1 if fails else 0)
