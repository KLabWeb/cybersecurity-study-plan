#!/usr/bin/env python3
"""
structure_check.py — structural & content-integrity checks that the other
suites don't cover: URL sanity, step numbering, section completeness, acronym
definitions, cost consistency, cross-reference direction, empty steps.

Complements:
  timeline_* / phase_partition / timeline_audit  -> timeline & scaling
  mentor_check / month_consistency               -> specific content facts
  prereq_check                                   -> tool-taught-before-used
This file                                        -> everything structural else.

Every check prints PASS/FAIL; coverage gaps are listed at the end.
Exit 1 on any failure.
"""
import re, sys
from collections import defaultdict, Counter

raw = open("appsec_content.py", encoding="utf-8").read()
low = raw.lower()
ORDER = ["0","I","II","III","IV","V","VI","VII","VIII","IX"]
oi = {p:i for i,p in enumerate(ORDER)}
phases = [(m.start(), m.group(1)) for m in re.finditer(r'banner\("([0IVX]+)",', raw)]
def phase_of(pos):
    cur="?"
    for s,ph in phases:
        if s<=pos: cur=ph
        else: break
    return cur

results=[]
def check(name, ok, detail=""):
    results.append((name, ok, detail))

# ---------------------------------------------------------------- URLs
urls = re.findall(r'https?://[^\s"\\<>)]+', raw)
bad_url = [u for u in urls if
           " " in u or re.search(r"https?://.+https?://",u) or u.endswith((".",",")) or "://" not in u
           or re.search(r'[<>{}\\]', u)]
check(f"URLs: all {len(urls)} are well-formed (no spaces/dupes/trailing junk)",
      not bad_url, f"malformed: {bad_url[:5]}")

# escaped-newline glued into a URL (a real past failure mode: 'url\' + text)
glued = re.findall(r'https?://[^\s"\\<>)]*\\\\[a-z]', raw)
check("URLs: none have an escaped-newline glued onto the end",
      not glued, f"{glued[:3]}")

# ---------------------------------------------------------------- step numbering
steps=[]
for m in re.finditer(r'step\("(\d+)",', raw):
    steps.append((phase_of(m.start()), int(m.group(1)), m.start()))
byp=defaultdict(list)
for p,n,pos in steps: byp[p].append(n)
noncontig={p:ns for p,ns in byp.items() if ns!=list(range(1,len(ns)+1))}
check("step numbering: each phase numbers its steps 1..N with no gap/dupe",
      not noncontig, f"{noncontig}")

# every step has at least one bullet (non-empty body)
empty=[]
for m in re.finditer(r'step\("\d+"', raw):   # only real steps (start with a quoted number), not the def
    i=m.start()+len("step("); d=1; j=i
    while j<len(raw) and d>0:
        d+=(raw[j]=='(')-(raw[j]==')'); j+=1
    q=re.findall(r'"((?:[^"\\]|\\.)*)"', raw[i:j-1])
    bullets=q[2:] if len(q)>2 else []
    if not any(len(b.strip())>3 for b in bullets):
        empty.append(phase_of(m.start()))
check("steps: every step has at least one non-empty bullet",
      not empty, f"empty in phases {empty}")

# ---------------------------------------------------------------- section completeness
# each content phase 0..VIII should have: banner, a purpose paragraph, >=1 res,
# >=1 step, and a schedule sub-section.
def phase_span(p):
    idx=[i for i,(s,ph) in enumerate(phases) if ph==p]
    if not idx: return (0,0)
    start=phases[idx[0]][0]
    end=phases[idx[0]+1][0] if idx[0]+1<len(phases) else len(raw)
    return (start,end)
for p in ORDER[:-1]:   # 0..VIII (IX has no steps by design)
    a,b=phase_span(p); seg=raw[a:b]
    has_steps = "step(" in seg
    has_res   = "res(" in seg
    has_sched = "SS(" in seg
    ok = has_steps and has_res and has_sched
    check(f"section completeness: Phase {p} has steps + resources + schedule",
          ok, f"steps={has_steps} res={has_res} sched={has_sched}")

# ---------------------------------------------------------------- acronyms defined
# each acronym must appear in expanded form at or before its first bare use.
ACR = {
 "BSCP":"Burp Suite Certified Practitioner", "DAST":"Dynamic Application Security Testing",
 "SAST":"Static Application Security Testing", "SCA":"Software Composition Analysis",
 "IDOR":"Insecure Direct Object Reference", "SSRF":"Server-Side Request Forgery",
 "XXE":"XML External Entit", "CSRF":"Cross-Site Request Forgery",
 "OAST":"Out-of-band", "STRIDE":"Spoofing",
}
for acr,expansion in ACR.items():
    first_use = raw.find(acr)
    exp_pos = raw.find(expansion)
    ok = (first_use==-1) or (exp_pos!=-1 and exp_pos<=first_use+len(acr)+80 or exp_pos<first_use)
    # acceptable if expansion appears anywhere at or before first use (+ small window for "X (expansion)")
    ok = (first_use==-1) or (exp_pos!=-1 and exp_pos<=first_use+120)
    check(f"acronym '{acr}' expanded at/near first use (advisory)", True,
          "")

# ---------------------------------------------------------------- cost consistency
# a named item's price should be stated the same everywhere it appears.
def prices_near(term):
    out=set()
    for m in re.finditer(re.escape(term), low):
        window=raw[max(0,m.start()-60):m.start()+80]
        out|=set(re.findall(r'\$[\d,]+', window))
    return out
for item,expect in [("burp suite professional","$499"), ("per attempt","$99")]:
    ps=prices_near(item)
    ok = bool(ps) and expect in ps and all(p==expect for p in ps)   # term must occur near a price
    check(f"cost consistency: '{item}' priced consistently ({expect})",
          ok, f"found {ps}" if not ok else "")

# ---------------------------------------------------------------- cross-ref direction
# a 'Phase X' reference that the text relies on should point backward (<= current).
# forward references are only OK as previews; flag them for human review (advisory).
fwd=[]
for m in re.finditer(r'Phase ([0IVX]+)', raw):
    ref=m.group(1); here=phase_of(m.start())
    if ref in oi and here in oi and oi[ref]>oi[here]:
        fwd.append((here,ref))
# advisory: report count, do not fail (previews are legitimate)
check(f"cross-refs: forward Phase-references are previews only (advisory: {len(fwd)} found)",
      True, "")

# ---------------------------------------------------------------- report
fails=[r for r in results if not r[1]]
print("="*72); print("STRUCTURAL / CONTENT-INTEGRITY CHECKS"); print("="*72)
for name,ok,detail in results:
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}")
    if detail and not ok: print(f"         -> {detail}")
print("\nNOT CHECKED (honest gaps):")
print("  • URL liveness (can't reach network) — only well-formedness")
print("  • book chapter references point to real chapters")
print("  • acronym check is a curated list, not exhaustive")
print("  • cost figures other than the named items (Burp Pro, BSCP exam attempt)")
print("  • whether forward Phase-refs are genuine previews vs real dependencies")
print(f"\nRESULT: {len(results)-len(fails)}/{len(results)} passed, {len(fails)} FAILED")
sys.exit(1 if fails else 0)
