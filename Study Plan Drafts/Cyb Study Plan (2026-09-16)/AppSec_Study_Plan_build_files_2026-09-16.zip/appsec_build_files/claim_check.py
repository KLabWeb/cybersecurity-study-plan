#!/usr/bin/env python3
"""
claim_check.py — CLAIM-LEVEL checks: does each sentence that asserts something
about another part of the plan (or about a named tool/target) actually hold?

The existing suites check the plan against ITSELF structurally (timeline,
numbering, links, taught-before-used). None of them check that a sentence's
CLAIM is true — e.g. "(reinforces step 03)" pointing at a Semgrep step, a
Python-only tool aimed at a Java codebase, a resource listed for a phase that
no step in that phase ever uses, or an intro saying "two weeks" for a
one-week phase. This suite closes that class. Every check prints PASS/FAIL
with the source line; a COVERAGE block lists what it cannot see. Exit 1 on fail.
"""
import re, sys

RAW = open("appsec_content.py", encoding="utf-8").read()
LINES = RAW.split("\n")
ORDER = ["0","I","II","III","IV","V","VI","VII","VIII","IX"]
oi = {p:i for i,p in enumerate(ORDER)}

def clean(t):
    t = t.replace("\\u2013","-").replace("\\u2014","--").replace("\\u00b7","·") \
         .replace("\\u2019","'").replace("\\u201c",'"').replace("\\u201d",'"')
    t = re.sub(r"<[^>]+>", " ", t)
    return re.sub(r"\s+", " ", t).strip()

def lineno(pos): return RAW[:pos].count("\n") + 1

# ---- phases / steps ---------------------------------------------------------
phases = [(m.start(), m.group(1)) for m in re.finditer(r'banner\("([0IVX]+)",', RAW)]
def phase_of(pos):
    cur = "?"
    for s, ph in phases:
        if s <= pos: cur = ph
    return cur

STEPS = []
for m in re.finditer(r'step\(', RAW):
    i = m.end(); d = 1; j = i
    while d > 0:
        d += (RAW[j] == '(') - (RAW[j] == ')'); j += 1
    body = RAW[i:j-1]
    q = re.findall(r'"((?:[^"\\]|\\.)*)"', body)
    if not q: continue
    STEPS.append({"phase": phase_of(m.start()), "num": q[0],
                  "text": clean(" ".join(q)), "line": lineno(m.start()),
                  "start": m.start(), "end": j})
by_key = {(s["phase"], s["num"]): s for s in STEPS}

results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))

# ============================================================================
# A. "(step NN)" / "step NN" references resolve to a step in the SAME phase
#    whose text shares a keyword with the referring sentence.
# ============================================================================
for s in STEPS:
    for m in re.finditer(r'\(?\b(?:reinforces |see )?step (\d{2})\)?', s["text"]):
        if re.search(r'Phase [0IVX]+ $', s["text"][:m.start()]): continue  # cross-phase ref, qualified
        tgt = by_key.get((s["phase"], m.group(1)))
        sent = s["text"][max(0, m.start()-120):m.start()]
        # keywords: capitalised tool/topic words in the referring sentence
        kws = set(w.lower() for w in re.findall(r"\b[A-Za-z]{6,}\b", sent))
        kws -= {"phase","weeks","already","against","before","finding","remaining","including"}
        hit = tgt is not None and any(k in tgt["text"].lower() for k in kws)
        check(f"step-ref: Phase {s['phase']} step {s['num']} -> 'step {m.group(1)}' "
              f"(L{s['line']})", hit,
              f"target={'missing' if not tgt else tgt['text'][:60]!r}; sentence keys={sorted(kws)[:6]}")

# ============================================================================
# B. Tool ↔ target language. A tool that only handles language X must not be
#    aimed at a target whose codebase is language Y.
# ============================================================================
TARGET_LANG = {"webgoat": "java", "juice shop": "javascript", "dvwa": "php",
               "fastapi app": "python", "fastapi project": "python"}
TOOL_LANG = {"bandit": {"python"}}          # python-only tools
for s in STEPS:
    low = s["text"].lower()
    for tool, langs in TOOL_LANG.items():
        if tool not in low: continue
        for tgt, lang in TARGET_LANG.items():
            if tgt in low and lang not in langs:
                check(f"tool/target language: Phase {s['phase']} step {s['num']} "
                      f"aims {tool} (python-only) at {tgt} ({lang}) (L{s['line']})", False,
                      "step text names both")
# explicit language claims about a target
for m in re.finditer(r'(webgoat|juice shop)[^.]{0,120}?\b(python|java|node|typescript)\b', RAW, re.I):
    tgt = m.group(1).lower(); claimed = m.group(2).lower()
    actual = TARGET_LANG[tgt]
    ok = (claimed == actual) or (tgt == "juice shop" and claimed in ("node","typescript"))
    check(f"language claim: '{tgt}' described as {claimed} (L{lineno(m.start())})", ok,
          f"actual codebase language: {actual}")

# ============================================================================
# C. Orphan resources: every res(...) entry in a phase should be named by at
#    least one step of that phase (or a later one it explicitly previews).
# ============================================================================
STOP = {"the","and","for","web","docs","documentation","official","guide","owasp","learn",
        "learning","application","security","project","platforms","resources","using","with"}
for m in re.finditer(r'res\("([^"]+)"[^)]*?"([^"]*)"', RAW):
    ph = phase_of(m.start()); name = clean(m.group(1)); desc = clean(m.group(2))
    dom = re.search(r'([a-z0-9-]+)\.(?:com|org|net|dev|io|cloud|sh)', desc.lower())
    cands = set(w for w in re.findall(r"[a-z0-9+]{3,}", name.lower()) if w not in STOP)
    if dom: cands.add(dom.group(1))
    ALIAS = {"hacker": "wahh", "handbook": "wahh"}
    cands |= {ALIAS[c] for c in cands if c in ALIAS}
    cands = {c for c in cands if not re.fullmatch(r"v?\d[\d.]*", c)}
    steps_txt = " ".join(RAW[st["start"]:st["end"]].lower() for st in STEPS if st["phase"] == ph)
    hits = [c for c in cands if c in steps_txt]
    check(f"resource used: Phase {ph} resource '{name[:40]}' named by a step in its phase "
          f"(L{lineno(m.start())})", bool(hits), f"looked for any of {sorted(cands)}")

# ============================================================================
# D. Reverse orphan: a named target/tool used in a step should appear in SOME
#    Learning Resources entry (DVWA-style: used but never introduced).
# ============================================================================
INTRO_REQUIRED = ["dvwa", "juice shop", "webgoat", "hashcat", "bcrypt", "semgrep",
                  "bandit", "snyk", "trufflehog", "gitleaks", "zap", "threat dragon",
                  "pwning owasp juice shop"]
res_text = " ".join(clean(m.group(0)).lower() for m in re.finditer(r'res\((?:[^()]|\([^()]*\))*\)', RAW))
for tool in INTRO_REQUIRED:
    used_in = [f"{s['phase']}.{s['num']}" for s in STEPS if tool in s["text"].lower()]
    if used_in:
        check(f"tool introduced: '{tool}' has a Learning Resources entry (used in {', '.join(used_in[:4])})",
              tool in res_text)

# ============================================================================
# E. Writeup-format consistency: every sentence that defines what a writeup /
#    "standard documentation" contains should name the SAME element set.
#    Works on the literal-joined text (string literals split across source lines
#    are re-joined) so a definition is read whole.
# ============================================================================
_pieces = []; _map = []   # JOINED offset -> RAW offset
for m in re.finditer(r'"\s*\n\s*"|[^"]+|"', RAW):
    t = m.group(0)
    if t.startswith('"') and "\n" in t: continue      # literal boundary: drop
    _map.append((sum(len(x) for x in _pieces), m.start())); _pieces.append(t)
JOINED = "".join(_pieces)
def jline(joff):
    roff = max(r for j, r in _map if j <= joff) + (joff - max(j for j, r in _map if j <= joff))
    return lineno(roff)
CANON = {"finding","cvss","risk rating","summary","technical details","evidence","impact",
         "remediation","code-review pattern","code review pattern"}
OFFSET = ["why,","how you identified","how identified","proof-of-concept","proof of concept","what it is,",", fix,"]
# every sentence that defines the format must use only canonical elements and none of the retired ones
n_defs = 0
for m in re.finditer(r'[^.]*(standard documentation|document a finding|writeup format|write it up|report format)[^.]*\.', JOINED, re.I):
    sent = clean(m.group(0)).lower()
    found = {w for w in CANON if w in sent}
    stray = [w for w in OFFSET if w in sent]
    if len(found) + len(stray) < 2: continue
    n_defs += 1
    check(f"writeup format: definition at L{jline(m.start())} uses only the canonical seven elements",
          not stray, f"retired elements present: {stray}")
check("writeup format: at least one full definition exists (>=6 canonical elements in one sentence)",
      any(len({w for w in CANON if w in clean(m.group(0)).lower()}) >= 6
          for m in re.finditer(r'[^.]*(writeup format|report format|document a finding)[^.]*\.', JOINED, re.I)))

# ============================================================================
# F. Duration prose vs banner: "N weeks"/"two weeks" inside a phase's intro
#    must not exceed the phase's banner span.
# ============================================================================
WORDNUM = {"one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,"eight":8}
def span_of(ph):
    for p, x in phases:
        if x == ph:
            head = RAW[p:p+300]
            mm = re.search(r'Weeks? (\d+)(?:\\u2013|–|-)?(\d+)?', head)
            if mm:
                a = int(mm.group(1)); b = int(mm.group(2)) if mm.group(2) else a
                return b - a + 1
    return None
for i, (p, ph) in enumerate(phases):
    end = phases[i+1][0] if i+1 < len(phases) else len(RAW)
    seg = RAW[p:end]
    span = span_of(ph)
    if span is None: continue
    for m in re.finditer(r'\b(one|two|three|four|five|six|seven|eight|\d+) weeks?\b', seg, re.I):
        n = WORDNUM.get(m.group(1).lower()) or int(m.group(1))
        ctx = clean(seg[max(0,m.start()-70):m.end()+30])
        # skip non-schedule uses (exam validity, job-search estimates, past anecdotes, ranges elsewhere)
        if re.search(r'(valid|retake|weeks of web dev|4.8 weeks|3.4 weeks|hired at|employment|on the job|first two weeks)', ctx, re.I): continue
        if re.search(r'\d\s*[-–]\s*' + re.escape(m.group(1)), ctx): continue  # part of a range "1-3 weeks"
        check(f"duration prose: Phase {ph} says '{m.group(0)}' but banner span is {span} wk (L{lineno(p+m.start())})",
              n <= span, ctx[:100])

# ============================================================================
# G. "end of Week N" milestones must equal the enclosing phase's last week.
# ============================================================================
for m in re.finditer(r'[Bb]y (?:the )?end of Week (\d+)', RAW):
    ph = phase_of(m.start())
    host = next((st for st in STEPS if st["start"] <= m.start() < st["end"]), None)
    if host:
        wk = re.findall(r"Weeks? (\d+)(?:[-–](\d+))?", host["text"])
        last_wk = max(int(b or a) for a, b in wk) if wk else None
        check(f"milestone: Phase {ph} step {host['num']} 'by end of Week {m.group(1)}' within step's weeks {wk} (L{lineno(m.start())})",
              last_wk is not None and int(m.group(1)) <= last_wk)
        continue
    head = next(RAW[p:p+300] for p, x in phases if x == ph)
    mm = re.search(r'Weeks? (\d+)(?:\\u2013|–|-)?(\d+)?', head)
    last = int(mm.group(2) or mm.group(1)) if mm else None
    check(f"milestone: Phase {ph} 'by end of Week {m.group(1)}' == phase last week {last} (L{lineno(m.start())})",
          last is not None and int(m.group(1)) == last)

# ============================================================================
# H. Phase Summary "Achievement:" claims must be backed by a step in that phase.
# ============================================================================
ACH_KEYS = {"writeup": r"write|writeup|document", "published": r"publish",
            "bscp": r"bscp", "security[+]": r"security[+]", "threat model": r"threat model",
            "code review": r"code review", "juice shop": r"juice shop", "checklist": r"checklist"}
for m in re.finditer(r'<b>Phase ([0IVX]+)[^<]*</b>.*?Achievement:</b>\s*([^"]*?)(?:"|\\")', RAW, re.S):
    ph, ach = m.group(1), clean(m.group(2)).lower()
    seg = [(p, x) for p, x in phases if x == ph][0][0]
    nxt = [p for p, x in phases if p > seg]
    steps_txt = clean(RAW[seg: nxt[0] if nxt else len(RAW)]).lower()
    for k, pat in ACH_KEYS.items():
        if re.search(k, ach):
            check(f"summary claim: Phase {ph} achievement mentions '{k}' -> Phase {ph} steps/prose match /{pat}/ (L{lineno(m.start())})",
                  re.search(pat, steps_txt) is not None)

# ============================================================================
# I. Price sanity for the exam itself (BSCP exam is per-attempt, not $499).
# ============================================================================
for m in re.finditer(r'exam[^.]{0,60}\$(\d+)', RAW):
    ctx = clean(RAW[max(0,m.start()-80):m.end()+20]).lower()
    if "bscp" in ctx or "burp suite certified" in ctx:
        check(f"price: BSCP exam attempt priced (L{lineno(m.start())})", m.group(1) != "499", ctx[:90])

# ---- report -----------------------------------------------------------------
fails = [r for r in results if not r[1]]
for name, ok, det in results:
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"\n         {det}" if det and not ok else ""))
print("\nCOVERAGE — this suite checks:")
print("  A. '(step NN)' references resolve to a same-phase step sharing a keyword")
print("  B. python-only tools not aimed at Java/JS targets; language claims about WebGoat/Juice Shop")
print("  C. every Learning Resources entry is used by a step/prose in its phase")
print("  D. every named tool/target in a step has a Learning Resources entry somewhere")
print("  E. every writeup-format definition uses only the canonical seven elements; one full definition exists")
print("  F. 'N weeks' prose inside a phase does not exceed its banner span")
print("  G. 'by end of Week N' equals the phase's last week")
print("  H. Phase Summary 'Achievement' claims are backed by a step in that phase")
print("  I. BSCP exam price is per-attempt, not the Burp Pro price")
print("NOT CHECKED: whether a title matches its bullets; whether a lab/room/chapter exists")
print("             or has the described content; pedagogical fit. Those are manual (see LINE_BY_LINE_AUDIT.md).")
print(f"\nRESULT: {len(results)-len(fails)}/{len(results)} passed, {len(fails)} FAILED")
sys.exit(1 if fails else 0)
