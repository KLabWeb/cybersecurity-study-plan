# LINE-BY-LINE AUDIT — Study_Plan_-_2026-09-13.pdf (build-60 + 09-13 commits)

Method: every step (61), every Learning Resources block (10), every Projects &
Writings block (4), every phase intro (10), the Phase Summary, Methodology, and
Application Strategy were read against a fixed question list. Each row records
PASS / FAIL / J (judgment — not pass/fail, flagged for you). Page numbers are
from the rendered PDF. Scripted checks live in `appsec_build_files/claim_check.py`
(87 checks; 13 failed on build-60 source, 5 remain after the mechanical fixes — all awaiting your decisions).

Question key (per step) — note: the original prereq_check step-count assertion (61) was failing on a parser miscount (62, it counted the step() definition); fixed to exclude the definition.

Question key (per step):
- T  title/type matches the bullets
- R  every named resource exists
- L  resource is in the form/language the step assumes
- X  every cross-reference ("previous step", "Phase 0 app", "step NN", "first…") resolves to a step that says that
- W  week tag inside its phase (also enforced by phase_partition_check)
- P  nothing used before it is taught (also enforced by prereq_check)
- S  no claim contradicting your actual setup (five repos, 25 hrs/wk, tools you own)
- $  price stated if it is a purchase

What this audit could NOT do: reach the network (bash has no egress), so
"resource exists" is from memory of PortSwigger/TryHackMe/book tables of contents
as of mid-2026, and the WebGoat source you uploaded. Rows marked R? are ones I am
not certain of and could not verify. URL liveness is unchecked (structure_check
already says the same).

---------------------------------------------------------------------------------
## FAILURES FIRST (new — not in the 113–124 changelist)

| # | Where | What is wrong | Evidence |
|---|---|---|---|
| F1 | p.16 Phase 0 intro | "By the end of Week 4, AppSec content starts immediately." Phase 0 is Weeks 1–3; Phase I begins Week 4. | claim_check G |
| F2 | p.19 Phase I intro | "not to become a penetration tester in two weeks." Phase I is one week (Week 4). Stale from the 2-week version. | claim_check F |
| F3 | p.14 Phase Summary, Phase I | "Achievement: first labs and **published lab writeups**." No Phase I step publishes anything; the SQLi essay is in Projects prose only, and the WebGoat reports are being removed (item 119). | claim_check H |
| F4 | p.28 III.01 and p.40 V.02 | "write your standard documentation **(what, why, fix, code review pattern)**" — a second format definition. The plan now defines the format in I.04 as finding / CVSS / summary / details+evidence / impact / remediation. p.12 Methodology defines a third (what / how identified / PoC / remediation / code-review pattern, 800–1,200 words). Three formats; steps disagree on which one "standard" means. | claim_check E + manual |
| F5 | p.34–35 IV.11 | "(reinforces step 03)" after the XSS cookie-steal lab. Phase IV step 03 is Semgrep & Bandit. The XSS lab is Phase III step 03. Wrong phase. | claim_check A |
| F6 | p.35 IV.11 | "Discovering vulnerabilities quickly with targeted scanning (step 09)". Targeted scanning is step **10**; step 09 is Save Exam-Ready PoCs. | claim_check A |
| F7 | p.37 IV.17 | Juice Shop assessment tooling list includes "Semgrep + Bandit (SAST)". Bandit is Python-only; Juice Shop is Node/TypeScript. Same class as items 115/116 but a third location. | claim_check B |
| F8 | p.27 Phase III resources | *Alice and Bob Learn Application Security* "Ch. 6–8 cover common pitfalls, securing modern applications, and building an AppSec program." (a) No Phase III step assigns any chapter of this book — orphan resource. (b) Ch. 6 is *Testing and Deployment*; common pitfalls is Ch. 5, which Phase II already assigned. Description wrong. | claim_check C + book TOC |
| F9 | p.33 IV.05 | "Run OWASP ZAP against **DVWA** or WebGoat." DVWA is never introduced anywhere — no resource entry, no install/run step. | claim_check D |
| F10 | p.37 IV.17 | "official companion guide **Pwning OWASP Juice Shop**" is load-bearing for the step (it structures the whole assessment) but has no Learning Resources entry and no link. | claim_check D |
| F11 | *withdrawn* | II.01's reading list links each item (MDN, OWASP cheat sheet, PortSwigger) inside the bullet; my check ignored hrefs. Check fixed; no plan change. | — |
| F12 | p.24 II.01 | Type is "READ + LABS" but the four bullets contain no labs — read WAHH, read Burp docs, read headers, take notes. Title/type mismatch. | manual T |
| F13 | p.28 III.02 | Top 10 writeups must include "how you identified it in a lab." Phase III has no lab for A04 Insecure Design, A05 Security Misconfiguration, A06 Vulnerable Components (Snyk is Phase IV), A08 Software/Data Integrity, A09 Logging Failures. Five of ten categories cannot satisfy the stated structure as written. (Also: the writeup series is Weeks 8–11 but the classes keep landing through Week 14.) | manual X |
| F14 | p.29 III.08 | "and the AI-powered scanner labs" — PortSwigger's Web LLM attacks path has four labs (excessive agency, vulnerabilities in LLM APIs, indirect prompt injection, insecure output handling). I know of no "AI-powered scanner" lab in that path. Unverified name; likely refers to Burp AI features, not a lab. | R? |
| F15 | p.43 VI.03 vs p.43 Projects | Step says threat-model "the API built during pre-study." Projects block says "A strong target is an LLM-integrated agent that calls tools." Two different targets for one deliverable. | manual X |
| F16 | p.46 VII.04 | "2–4 applications a day… 1–2 hours per application" = 2–8 hrs/day, inside a 5 hr/day plan that is also running Phase VIII prep in the same weeks. Arithmetic doesn't fit the schedule table. | J → flagged as fail |
| F17 | structure_check.py L115 | Existing gate asserts BSCP is "priced consistently ($499)". The BSCP **exam** is ~$99/attempt (p.32, p.36); $499 is Burp Pro. The test passes only because "$99" falls outside its 80-char window. Wrong assertion in the test suite. | manual |
| F18 | p.19 Phase I resources | TryHackMe entry says the Web Fundamentals path "covers HTTP in Detail, Burp Suite: The Basics, and OWASP Top 10." build-55 removed the OWASP Top 10 room from I.01 (locked); the resource description still advertises it. | manual R |
| F19 | p.28 III.06 | "the expert web-shell-via-race-condition lab **(Burp Pro)**." The lab is Expert-tier, but the race is normally done with Turbo Intruder, a free extension; Pro is not required for it. Minor overclaim. | J |
| F20 | p.16 Phase 0 resources | DigitalOcean guide is the Ubuntu **22.04** version; you run Linux Mint 22 (Ubuntu 24.04 base). Commands are the same; the title is off. | J |

Previously logged and still open: 113–124 (see changelist).

---------------------------------------------------------------------------------
## PER-STEP TABLE

Legend: ✓ pass · ✗ fail (see F-number) · J judgment note · – not applicable

### Phase 0 — p.16–18
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 0.01 Git & GitHub Hygiene | ✓ | ✓ | – | ✓ | ✓ | ✓ | J | – | Says "create a new repository for the FastAPI project" — consistent with your five-repo setup; p.12 Methodology ("one repository") is the one that isn't (item 117). |
| 0.02 HTTP & Cookies | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| 0.03 FastAPI Docs | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | J | – | Item 118 (start-from-beginning vs resume-from-Request-Body). "Three years of adding to others' APIs" — you told me ~2.5 years of FastAPI; résumé is Oct 2020–Jun 2024. Your number to set. Step is complete. |
| 0.04 Docker | ✓ | ✓ | J | ✓ | ✓ | ✓ | ✓ | – | F20. WebGoat container: Dockerfile present in the source you uploaded. |
| Resources | – | ✓ | – | – | – | – | – | – | All five named by a step. |
| Projects & Writings | ✓ | – | – | ✓ | – | – | ✓ | – | "5–6 endpoints, JWT auth, dependency-injected auth checks, SQL database" — matches what you built. |
| Intro | – | – | – | ✗ | – | – | – | – | F1. |

### Phase I — p.19–21
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| I.01 TryHackMe Orientation | ✓ | R? | ✓ | ✓ | ✓ | ✓ | ✓ | – | HTTP in Detail and Burp Suite: The Basics exist; whether both sit in the "Web Fundamentals" path today I can't verify offline. Resource text F18. |
| I.02 PortSwigger Orientation | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Free account; apprentice SQLi/XSS labs exist. |
| I.03 Real-World Bug Hunting Ch. 1–5 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Chapter map correct (1 basics, 2 open redirect, 3 HPP, 4 CSRF, 5 HTML injection). |
| I.04 Writing Pentest Reports | ✓ | ✓ | ✓ | J | ✓ | ✓ | ✓ | – | Room verified live per 09-13 commit. Last bullet's "first use" target moves per items 119/124. |
| I.05 WebGoat | ✓ | ✓ | ✓ | J | ✓ | ✓ | ✓ | – | Five lessons exist (verified from source). Writeup bullet being reworded (item 119). |
| Resources | – | ✗ | – | – | – | – | – | – | F18. |
| Projects & Writings | – | – | – | J | – | – | – | – | "First evidence of hands-on work" — item 120. |
| Intro | – | – | – | ✗ | – | – | – | – | F2. |

### Phase II — p.22–26
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| II.01 HTTP Deep Dive | ✗ | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | – | F12 (no labs), F11 (reading has no named source). WAHH Ch. 1–3 titles correct. |
| II.02 Auth & Session | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | WAHH Ch. 6/7 correct. JWT labs named all exist (unverified sig, flawed sig, weak key, jwk, jku, alg confusion). OAuth labs named all exist. |
| II.03 Auth Audit Checklist | ✓ | ✓ | ✓ | J | ✓ | ✓ | J | – | Item 124 pending (your decision to not audit the app in Week 5). |
| II.04 Access Control & APIs | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | WAHH Ch. 8 correct. API testing path has one apprentice lab; fine. |
| II.05 Input Handling | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| II.06 Alice and Bob | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Ch. 1–5 + 7 correct. Bullet omits Ch. 4 (Secure Code) from its description of 1–5; harmless. |
| II.07 Cryptography | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | hashcat wiki + bcrypt PyPI both in resources. |
| II.08 Networking | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | THM Network Fundamentals module and Putting It All Together room exist. SSRF cheat sheet has a DNS-rebinding section. |
| II.09 JWT LinkedIn Article | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | – | Item 123 (title claims a code review that didn't happen). |
| Resources | – | ✓ | – | ✗ | – | – | – | – | F11 (MDN listed, not named by a step). |
| Intro | ✓ | – | – | ✓ | – | – | – | – | |

### Phase III — p.27–30
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| III.01 Injection | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | F4 (second format definition). Burp Pro $499 stated. OS-command and SSTI labs named exist. |
| III.02 Top 10 Writeup Series | ✓ | ✓ | – | ✗ | J | ✓ | ✓ | – | F13. Weeks 8–11 vs classes running to Week 14 — J. |
| III.03 XSS | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| III.04 CSRF/SSRF/XXE | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | The two SSRF expert labs named (Shellshock, whitelist filter) are the real expert ones. |
| III.05 Access Control & Logic | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| III.06 Deser/Upload/Traversal | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | J | – | F19. |
| III.07 API Deep Dive | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Hacking APIs Ch. 1–3, 6–9 correct. Topics assigned (BOLA, mass assignment) are the book's Ch. 10–11, which are not assigned — J. |
| III.08 Web LLM Attacks | ✓ | R? | ✓ | ✓ | J | ✓ | ✓ | – | F14. Three weeks for four labs plus reading — J (generous). |
| III.09 OWASP LLM Top 10 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | LLM01/02/05/06 IDs match the 2025 list. |
| Resources | – | ✗ | – | ✗ | – | – | – | – | F8 (Alice and Bob orphan + wrong chapter description). OWASP Testing Guide listed; no step names it — advisory only, it's a methodology reference. |
| Intro | ✓ | – | – | ✓ | – | – | – | – | "Complete every Apprentice and Practitioner lab" vs steps that say "skip the long tail" (III.03) — J, steps win. |

### Phase IV — p.31–38
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| IV.01 Burp Mastery | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Three labs named exist. |
| IV.02 BSCP Prep | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | $499 Pro + ~$99 exam stated. |
| IV.03 Semgrep & Bandit | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | – | Items 115/116. |
| IV.04 Secrets Scanning | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| IV.05 ZAP | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | – | F9 (DVWA). |
| IV.06 Begin Applications | ✓ | – | – | ✗ | ✓ | – | ✓ | – | Item 114 (writeup count). |
| IV.07 OOB Collaborator | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | Pro requirement restated. Labs named exist. |
| IV.08 Remaining BSCP Topics | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Smuggling / Host header / cache poisoning labs named all exist. |
| IV.09 Save PoCs | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| IV.10 Targeted Scanning | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Both labs exist; Pro noted. |
| IV.11 Reinforcement Labs | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | – | F5, F6. Other refs (07, 01, 08, Phase II) correct. |
| IV.12 Re-Solve Cold | ✓ | – | – | ✓ | ✓ | ✓ | ✓ | – | |
| IV.13 Mystery Labs | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Mystery lab feature exists. |
| IV.14 Exam Stamina | ✓ | – | – | ✓ | ✓ | ✓ | ✓ | – | |
| IV.15 BSCP Exam | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | $99/attempt. |
| IV.16 Snyk | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | Week 19, overlapping the exam window — J. |
| IV.17 Juice Shop Assessment | ✓ | ✗ | ✗ | ✓ | ✓ | ✓ | ✓ | – | F7 (Bandit on Node), F10 (guide unlisted). |
| IV.18 Secure LLM API | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | J | – | Target is the Phase 0 FastAPI app — your open question. LLM IDs consistent with III.09. Hosted-model API cost not stated — J. |
| Resources | – | ✗ | ✗ | – | – | – | – | – | Item 115 (WebGoat "Python source"). DVWA / Pwning guide absent (F9, F10). |
| Intro | ✓ | – | – | ✓ | – | – | – | – | |

### Phase V — p.39–41
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| V.01 AWS Foundations | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| V.02 flaws.cloud | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | J | F4 (format). AWS free-tier account needed; cost not stated ($0 if free tier). |
| V.03 flaws2.cloud | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| Resources / Intro | ✓ | ✓ | – | ✓ | – | – | – | – | |

### Phase VI — p.42–44
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| VI.01 Code Review Methodology | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| VI.02 ASVS | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | v5.0.0, 17 chapters — correct. |
| VI.03 Threat Modeling | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | J | – | F15. Target is the FastAPI app — your open question. |
| VI.04 Time-Pressure Review | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| Projects & Writings | – | – | – | ✗ | – | – | ✓ | – | F15. Billing-system essay references ActiveCampaign — matches résumé. |
| Resources / Intro | ✓ | ✓ | – | ✓ | – | – | – | – | Threat Dragon used in VI.03. |

### Phase VII — p.45–47
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| VII.01 Study Guide | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | J | Book price not stated; Professor Messer exams "paid," price not stated. |
| VII.02 Practice Exams | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | – | |
| VII.03 Sec+ Exam | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | $404. |
| VII.04 Main Application Push | ✓ | – | – | ✓ | ✓ | – | ✗ | – | F16. |

### Phase VIII — p.48–49
| Step | T | R | L | X | W | P | S | $ | Notes |
|---|---|---|---|---|---|---|---|---|---|
| VIII.01–05 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | J | Exponent / interviewing.io are paid; price not stated. Resources all used. |
| Application Strategy | – | – | – | ✗ | – | – | ✗ | – | Item 113 (BSCP "acquired" at Week 15). |

### Phase IX — p.50–51
No steps. "First Two Weeks" refers to the job, not the plan — correct. "hired at 14 weeks of web dev self-study" is your history — not checked.

### Front matter — p.3–15
| Section | Finding |
|---|---|
| p.9 Compensation / market tables | Figures are Opus web-search output from June–July 2026; not re-verified here. |
| p.10 Schedule overview | 25 hrs, 5×5, 6–8 months — consistent with the banner spans (33 weeks ≈ 8 months). |
| p.12 Methodology, writeup format | Third format definition (F4). "Keep one repository" (item 117). "At least two published writeups" (item 114). |
| p.14 Phase Summary | F3 (Phase I "published lab writeups"). Other phases' Achievement lines are backed by steps. |

---------------------------------------------------------------------------------
## Existing test suite — findings about the tests themselves

- `structure_check.py` L115: asserts BSCP costs $499 (F17). Should assert the exam is
  $99 and Burp Pro is $499, separately.
- No suite checked claim-level facts (cross-ref targets, tool/target language, orphan
  resources, format definitions, intro durations, summary claims). `claim_check.py`
  adds those; it is not yet wired into `build_appsec.py`.

## Coverage summary

- Steps read: 61/61. Resource blocks: 10/10. Projects blocks: 4/4. Intros: 10/10.
- Manual checks recorded: 61 steps × 8 = 488, plus 38 resource/prose rows.
- New scripted checks: 88 (13 failing on current source, all confirmed true positives above).
- Not verified: URL liveness; exact current names of TryHackMe paths (F18, I.01 R?);
  existence of an "AI-powered scanner" PortSwigger lab (F14); market/salary figures.
