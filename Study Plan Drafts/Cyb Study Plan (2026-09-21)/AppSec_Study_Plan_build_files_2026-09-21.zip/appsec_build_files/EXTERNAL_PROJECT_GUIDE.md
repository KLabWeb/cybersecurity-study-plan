# External project guide: how this project was run, what worked, what failed

Written 2026-09-21 by Claude, at the user's request, for a Claude that starts a DIFFERENT project with the same user.
This file is not about the Study Plan's content. It is about the working method. Read it, then read the live files it
points to, because they are newer than this guide and they are the real record.

Note on paths: `appsec_build_files/` ships in the public build zip. `inventory/` and `tools/` ship only in the private
backup zip, which the user can hand over directly.

## 1. Why this file exists: the user's own words

> "This Project has been going really well so far. Way better than anything else with Claude. Next time I start a
> project with Claude, I'm just going to hand it one of the Build Zips and say, 'Read this. What can you discern from
> how we did this project? What were the key sucesses? What were the key failures? Do you see how the versioning
> system separated concerns properly?'"

So those are the four questions this guide answers. Sections 3 to 6 take them in order. Section 7 is the short list of
things to set up on day one of a new project. Section 8 says what NOT to copy.

## 2. What to read in this zip, and in what order

1. `appsec_build_files/CLAUDE.md`: the contract for every session. Note how short the core is: a primary objective, a
   change contract, a delivery definition.
2. `inventory/memory_backup/feedback_primary_objective.md` and `feedback_study_plan_rules.md`: the ONE rules file.
   Every working rule lives there, numbered, with the date and the user's words that created it.
3. The handoff file in `inventory/` (its name starts with the word HANDOFF and a date): it opens with a dated state block. Newer blocks sit on top of older ones and say
   what they supersede.
4. `inventory/ROUND4_V_INDEX.txt`: the versioning record. One entry per V, a running log under each, and every
   "LEAD ERROR" written down with its cause.
5. `appsec_build_files/CHANGELOG_APPLIED.md`: what each delivered build changed, in plain words.
6. `tools/`: the gates and checks. Read `precheck.py`, `proofcheck.py`, `stop_gate.py`, `pregate.py` and one V-specific
   tool such as `v130_exact.py`. They show the pattern: a rule that a tool can check is checked by a tool.
7. `inventory/proofs/`: what evidence for a single decision looks like.

## 3. What can be discerned from how the project was done

**The user is the editor. Claude is the careful assistant.** Every change to the product follows one contract:
propose the old text and the new text, apply only on an explicit yes, then run every gate. Claude never decides a
content question alone, and never runs git. "Commit" means deliver to files (changelog, render, copies, two zips).

**One decision per message.** The user reads and rules quickly when a message holds one decision, the evidence for it,
Claude's view stated once, and one question. Walls of text, option tables and stacked questions were all rejected,
more than once.

**The primary objective sits above every other rule:** read the thing itself before judging, proposing, describing or
calling anything verified. If it cannot be read, ask for it with the link. Never claim an action that no tool call in
the same turn performed. Most of the project's failures are violations of this one sentence (section 5).

**State lives in files, not in the conversation.** Conversations were summarised and restarted many times. Nothing was
lost, because the handoff file, the V index, the rules file and the private zip are written as the work happens, not
at the end.

**The working folder is volatile; the zip is the backup.** A private zip holds everything and is verified by checksum.
A public zip is built from an allow-list, never a deny-list, with a leak scan and a list of forbidden file kinds.

## 4. The key successes

1. **The V system (section 6).** It is the main reason the project stayed steerable.
2. **Gates written as code.** Thirteen build gates, a message gate (`precheck.py`), a proof gate (`proofcheck.py`), a
   name gate (`namecheck.py`), and finally a Stop hook (`stop_gate.py`) that refuses to end a turn when a reply breaks
   a checkable rule. Rules that lived only in prose were broken repeatedly. Rules enforced by a tool were not.
3. **Proof files.** A proposal needs a small TSV: place, claim, source file, exact quote. The checker fails if the
   quote is not literally in the saved source. This turned "I think this page teaches X" into something testable.
4. **Sandbox, then apply.** Copy the build, run the fix script there, run all gates, then apply to the real file and
   compare byte for byte.
5. **Measuring instead of estimating (V130).** Word counts cut at true chapter lines, with the first and last words
   printed for checking; the user's own logged minutes; the user's own notes word counts. The user's rule:
   "The current velocity building work is essentially math. You don't guess at math."
6. **Asking the user for what Claude cannot read.** Pages behind a login were saved by the user into a Temp folder.
   Claude never received a cookie or a credential, and never fetched the site.
7. **Writing errors down.** Every lead error is logged with its cause and the fix. Several became new tool checks.
8. **Changing a view in the open.** When new evidence reversed Claude's advice, the message said so and said why.
   The user accepted reversals. The user did not accept silent drift.

## 5. The key failures (all Claude's, all recorded in the V index)

1. **Judging a source without reading it.** Describing a room from its title; placing a source from its name; calling
   material "mostly review" when a quiz showed it was not; advising on a whole room after reading one task.
2. **Claiming an action that did not happen** ("I added this to the index" with no tool call in the turn).
3. **Partial scans presented as full scans.** The user had to ask several times for "100%".
4. **Generic numbers where the user's own data existed.** A textbook reading speed was used while the user's study
   logs sat in the working folder. The real figure was eight times slower, and it changed the conclusion.
5. **Estimates inside a calculation.** Page-number ratios and a guessed "menu factor" were used as inputs. Both were
   wrong when measured.
6. **Conflicting logic.** Nesting every tool under one folder, then minutes later proposing to move two tools out.
   The user caught it. The fix was to state the rule first, then apply it without exceptions.
7. **Raising a settled point again**, and listing "weak points" the user had already answered.
8. **Format drift:** long replies, several questions, artifacts nobody asked for, and reprinting a blocked message so
   the user saw it twice.
9. **Tool patches without reading the output.** Two chapter counts were wrong because a running page header was
   matched as a chapter title. Reading the printed first and last words of each cut caught it.

The pattern under all nine: moving on an assumption when a read, a count or a question was available.

## 6. How the versioning system separated concerns

- A **V** is one point the user raised, given a number, a one-line definition and its own running log. It is never a
  bundle. "One V per user point."
- A V is **opened by the user or with the user's word**, worked one decision at a time, and **closed by the user**.
  Closing with "no plan change" is a valid result and is recorded as such.
- **Findings inside a V get their own ids** (NP-51, NP-52 ...), each with the evidence, the candidate fix, and the
  ruling in the user's words. A ruling is recorded when made and applied later, in the V that owns the text.
- **Vs can pause and nest.** V115 paused for V124, which paused for V129, then V130. Each pause is written into the
  handoff with the exact resume point. Nothing is "in progress in my head".
- **Discovering is separate from changing.** V129 and V130 changed no product text. They produced rulings. The
  text changes queue up for the V whose job is editing (V115), where each is shown as old and new text.
- **Delivery is separate from both.** A build is delivered when the user says so: changelog entry, all gates,
  render, copies, zips. The build label and the V numbers never mix.
- **A fix must not create a defect another V owns.** When work in one V touches another V's subject, it is logged
  there and left alone.

The effect: the user could always answer three questions from the index alone. What is open? What was decided, and
in whose words? What is delivered?

## 7. Day one of a new project: set these up before the first real task

1. A **contract file** at the repo root: the primary objective; the change contract (propose, approve, gate);
   what "commit" means; who runs git.
2. **One rules file.** New rule = new numbered line with the date and the user's words. Never scatter rules.
3. A **V index** and a **handoff file**, both written during the work.
4. A **message gate** run on every draft before sending, and if the harness allows it, a **Stop hook** with an on/off
   switch file that fails open.
5. A **proof convention** for any claim about a source, checked by a tool.
6. A **backup** the user controls, verified by checksum, with a strict public/private split if anything is published.
7. Agree the **reply format** early and save it: verdict first; short labels; bullets; what was read and how much;
   the proposed change; verification; Claude's view once; one question; a closing line that says whether anything
   is still running.
8. Ask what the user's **own data** already says before using any outside number.

## 8. What not to copy

- The Study Plan's wording rules (section 6 of the rules file) are about that document. They do not transfer.
- The gate list is specific to that build. The idea transfers: every recurring review comment becomes a check.
- The Stop hook's word patterns are tuned to this user's rules. Rebuild them from the new project's rules.
- Do not import decisions. Import the way decisions were reached and recorded.

## 9. A caution for the Claude reading this

This guide is a summary written from inside the project, and summaries drift. Where it disagrees with the rules file,
the V index or the handoff in the same zip, those files are right. Read them.
